#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec 8>queue.lock
flock -n 8 || exit 0
export PYTHONNOUSERSITE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8 MKL_NUM_THREADS=8
PY=/home/waas/mambavision_stage22/env/bin/python
"$PY" -u prepare.py
for arm in uper64 sdi_weak16 swin_local16; do
  mkdir -p "$arm"
  echo "$(date -Is) $arm"
  if [[ -s "$arm/test_result.json" ]]; then continue; fi
  runner=train_ham.py
  if [[ "$arm" == swin_local16 ]]; then runner=train_swin.py; fi
  "$PY" -u "$runner" "$arm" >> "$arm/train.log" 2>&1
  test -s "$arm/test_result.json"
done
echo "$(date -Is) all complete"
