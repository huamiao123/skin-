"""Collect only verified, target-trained, validation-selected test macro Dice."""
from pathlib import Path
import json, csv, hashlib, io
import statistics
from prepare_matched import BASE,sha
HAM=BASE.parent/'ham10000_window16_20g_20261119'
rows=[]
for ds in ['ISIC2018','PH2','Waterloo','HAM10000']:
    root=HAM if ds=='HAM10000' else BASE/ds
    for arm in ('uper64','sdi_weak16','swin_local16'):
        d=root/arm
        row=dict(dataset=ds,model=arm,status='queued',n_test='',test_macro_dice_percent='',best_epoch='',epochs_trained='')
        if (d/'test_result.json').is_file():
            final=json.loads((d/'test_result.json').read_text())
            lock=json.loads((d/'fit_complete.json').read_text())
            assert lock['best_sha256']==final['best_sha256']
            assert lock['split_sha256']==sha(root/'split.csv')
            with (root/'split.csv').open() as f:ids=[r['image_id'] for r in csv.DictReader(f) if r['split']=='test']
            with (d/'test_per_image.csv').open() as f:cases=list(csv.DictReader(f))
            assert [r['image_id'] for r in cases]==ids and len(ids)==final['n']
            avg=statistics.mean(float(r['foreground_dice']) for r in cases)
            assert abs(avg-final['test_macro_dice'])<1e-12
            row.update(status='tested',n_test=len(ids),test_macro_dice_percent=f'{100*avg:.4f}',best_epoch=final['best_epoch'],epochs_trained=final['epochs_trained'])
        elif (d/'config.json').exists():row['status']='started'
        rows.append(row)
buf=io.StringIO();w=csv.DictWriter(buf,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
tmp=BASE/'matched_test_dice.csv.tmp';tmp.write_text(buf.getvalue());tmp.replace(BASE/'matched_test_dice.csv')
