#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec 8>queue.lock
flock -n 8 || exit 0
export PYTHONNOUSERSITE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8 MKL_NUM_THREADS=8
PY=/home/waas/mambavision_stage22/env/bin/python
exec 7>../ham10000_window16_20g_20261119/gpu.lock
flock 7
test -s ../ham10000_window16_20g_20261119/swin_local16/test_result.json
"$PY" -u prepare_matched.py PH2 Waterloo ISIC2018
"$PY" -u collect.py
for ds in PH2 Waterloo ISIC2018; do
  for arm in uper64 sdi_weak16 swin_local16; do
    if [[ -s "$ds/$arm/test_result.json" ]]; then continue; fi
    mkdir -p "$ds/$arm"
    echo "$(date -Is) start $ds $arm"
    "$PY" -u fit_matched.py "$ds" "$arm" >> "$ds/$arm/train.log" 2>&1
    test -s "$ds/$arm/test_result.json"
    "$PY" -u collect.py
    echo "$(date -Is) tested $ds $arm"
  done
done
echo "$(date -Is) all 12 results verified"
