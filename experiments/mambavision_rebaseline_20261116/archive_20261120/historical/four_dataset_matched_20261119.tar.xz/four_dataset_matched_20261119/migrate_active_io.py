import json,os,shutil,signal,sys,time,subprocess
from pathlib import Path
import torch
from prepare_matched import BASE,SCRATCH
src=BASE/'PH2/uper64'
if (src/'test_result.json').exists():print('Completed already');sys.exit()
assert not Path('/proc/93371').exists()
local=SCRATCH/'training/PH2/uper64';local.mkdir(parents=True,exist_ok=True)
def cp(name):
 tmp=local/(name+'.transition');shutil.copyfile(src/name,tmp);os.replace(tmp,local/name)
cp('resume.pth')
st=torch.load(str(local/'resume.pth'),map_location='cpu',mmap=True,weights_only=False)
h=st['history'];br=max(h,key=lambda r:r['val_macro_dice'])
best=f"best_epoch_{br['epoch']}.pth"
cp(best);cp('config.json');cp('first_update.json')
assert torch.load(str(local/best),map_location='cpu',weights_only=True,mmap=True)['epoch']==br['epoch']
print('resuming original run at next epoch after',len(h),'best',br['epoch'],flush=True)
with (BASE/'queue.log').open('a') as out:
 subprocess.Popen(['bash','queue.sh'],cwd=BASE,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
