#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec 8>queue.lock
flock -n 8
exec 7>../ham10000_window16_20g_20261119/gpu.lock
flock 7
export PYTHONNOUSERSITE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8 MKL_NUM_THREADS=8
PY=/home/waas/mambavision_stage22/env/bin/python
for ds in Waterloo ISIC2018; do
    if [[ -s "$ds/uper64/test_result.json" ]]; then continue; fi
    mkdir -p "$ds/uper64"
    echo "$(date -Is) start $ds uper64 epochs=100 patience=25"
    "$PY" -u baseline_100.py "$ds" >>"$ds/uper64/train.log" 2>&1
    test -s "$ds/uper64/test_result.json"
    "$PY" -u collect.py
    echo "$(date -Is) verified $ds uper64"
done
echo "$(date -Is) finished baselines"
