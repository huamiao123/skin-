#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
while kill -0 81609 2>/dev/null && [[ ! -s test_result.json ]]; do sleep 7; done
[[ -s test_result.json ]]
exec env OMP_NUM_THREADS=8 PYTHONNOUSERSITE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8 /home/waas/mambavision_stage22/env/bin/python -u generalization.py
