"""Validate legacy mask provenance against official ISIC2018 Task1 archives."""
from pathlib import Path
import io,json,hashlib,urllib.request,zipfile,csv,collections,time,concurrent.futures
import numpy as np
from PIL import Image
try:import cv2
except ImportError:cv2=None
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'diagnostics/stageC_20261117/data_provenance'
P=Path('/home/waas/mambavision_stage22/source/referring_image_segmentation')
def dump(name,s):
 p=OUT/name;q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(s,indent=2)+'\n');q.replace(p)
def h(a):return hashlib.sha256(a.tobytes()).hexdigest()
def main():
 OUT.mkdir(parents=True,exist_ok=True);records=[];official={}
 for split in ['Training','Validation']:
  fname='ISIC2018_Task1_'+split+'_GroundTruth.zip'
  url='https://isic-archive.s3.amazonaws.com/challenges/2018/'+fname
  p=OUT/fname
  if not p.exists():
   tmp=p.with_suffix('.zip.partial')
   with urllib.request.urlopen(url,timeout=45) as r,tmp.open('wb') as f:
    while True:
     chunk=r.read(1024*1024)
     if not chunk:break
     f.write(chunk)
   tmp.replace(p)
  rec=dict(url=url,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   members=[n for n in z.namelist() if n.endswith('_segmentation.png')]
   rec['mask_count']=len(members)
   for name in members:
    im=Image.open(io.BytesIO(z.read(name))).convert('L')
    a=np.asarray(im);assert set(np.unique(a)).issubset({0,255}),name
    sid=Path(name).stem.removesuffix('_segmentation')
    official[sid]=(a.copy(),split)
  records.append(rec);dump('ACQUISITION.json',records)
  print(json.dumps(dict(downloaded=split,masks=rec['mask_count'])),flush=True)
 assert len(official)==2694
 index={};small={};modes={}
 def add(key,sid,method):
  index.setdefault(key,[]).append((sid,method))
 for sid,(a,split) in official.items():
  im=Image.fromarray(a)
  for method,resample in [('PIL_nearest',Image.Resampling.NEAREST),('PIL_bilinear',Image.Resampling.BILINEAR),('PIL_bicubic',Image.Resampling.BICUBIC),('PIL_lanczos',Image.Resampling.LANCZOS)]:
   b=np.asarray(im.resize((256,256),resample));add(h(b),sid,method)
  if cv2 is not None:
   for method,flag in [('cv2_nearest',cv2.INTER_NEAREST),('cv2_linear',cv2.INTER_LINEAR),('cv2_cubic',cv2.INTER_CUBIC),('cv2_area',cv2.INTER_AREA),('cv2_lanczos4',cv2.INTER_LANCZOS4)]:
    b=cv2.resize(a,(256,256),interpolation=flag);add(h(b),sid,method)
  b=np.asarray(im.resize((64,64),Image.Resampling.NEAREST))>=128;small[sid]=b.reshape(-1)
 print('OFFICIAL_HASH_INDEX_READY',len(index),flush=True)
 legacy=[];mapping=[]
 for split in ['train','val']:
  for p in sorted((P/'data/isic2018'/split/'masks').glob('*.png')):
   a=np.asarray(Image.open(p).convert('L'));im=Image.fromarray(a)
   matches=index.get(h(a),[])
   row=dict(split=split,id=p.stem,raw_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),unique_values=int(len(np.unique(a))),gray_fraction=float(((a>0)&(a<255)).mean()),matched_official_masks=matches)
   legacy.append(row)
   if matches:mapping.append(dict(split=split,id=p.stem,official_id=matches[0][0],resize_method=matches[0][1],all_matches=matches))
 dump('MASK_PROVENANCE_MAPPING.json',mapping)
 dump('LEGACY_MASK_AUDIT.json',legacy)
 suspicious=['126','511','136','536']
 sidlist=list(small);matrix=np.stack([small[s] for s in sidlist]).astype(np.float32)
 candidates={}
 for sid in suspicious:
  q=np.asarray(Image.open(P/'data/isic2018/val/masks'/(sid+'.png')).convert('L').resize((64,64),Image.Resampling.NEAREST))>=128
  v=q.reshape(-1).astype(np.float32);tp=matrix@v;dice=2*tp/np.maximum(matrix.sum(1)+v.sum(),1)
  top=np.argsort(-dice)[:5]
  candidates[sid]=[dict(official_id=sidlist[i],mask_shape_dice64=float(dice[i])) for i in top]
 dump('SUSPICIOUS_MASK_CANDIDATES.json',candidates)
 dump('SUMMARY.json',dict(complete=True,legacy_n=len(legacy),official_n=len(official),exact_raw_resize_matches=len(mapping),official_archives_binary=True,nonbinary_legacy_masks=sum(r['unique_values']>2 for r in legacy),suspicious_candidates=candidates,interpretation='Mask-shape matching alone does not verify image-mask pairing. No labels or splits modified. Gray resize values are not proof of corruption.'))
 print(json.dumps(dict(complete=True,exact_matches=len(mapping),legacy_n=len(legacy),suspicious=candidates)),flush=True)
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  OUT.mkdir(parents=True,exist_ok=True);dump('FAILURE.json',dict(traceback=traceback.format_exc()));raise
