"""Fixed-checkpoint validation-only branch sensitivity, not causal retraining."""
from pathlib import Path
import csv,json,gc,hashlib,time,datetime,concurrent.futures
import numpy as np
import torch
from PIL import Image,ImageDraw
from scipy.ndimage import binary_erosion
from model import PROJECT,SegmentationSystem,load_pretrained_encoder,sha256
from train_mb64 import reference,atomic_json
from evaluate_stageA import profile,stratify,bootstrap
from evaluation import summarize_rows
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'diagnostics/stageC_20261117'
MODES=['intact','f1_zero','f1_spatial_mean','f4_zero','f4_spatial_mean','ppm_zero','identity_repeat']
SPECS={'control':('stageB_color_20261117/control','A-64-noaux','stageB_color_20261117/control'),'C512aux':('formal_mb64/C-512-aux','C-512-aux','stageA_20261117/C-512-aux')}
def writecsv(p,rows):
 with p.open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def main():
 protocol=json.loads((ROOT/'reports/STAGEC_SENSITIVITY_PROTOCOL.json').read_text())
 assert protocol['validation_only'] and not protocol['test_read']
 assert sha256(Path(__file__))==protocol['source_sha256']
 if (OUT/'SENSITIVITY_SUMMARY.json').exists():raise FileExistsError('existing completed sensitivity')
 reference.setup();torch.set_num_threads(8);torch.use_deterministic_algorithms(True,warn_only=True)
 data,partition=reference.load_data()
 ids=partition['splits']['val'];assert len(ids)==762
 y=(data.masks['val'][:,0]>=.5).cpu().numpy()
 cuts=np.quantile(y.sum((1,2)),[.25,.5,.75])
 cache=reference.cache_new(762)
 results={}
 for name,(run,arm,oldval) in SPECS.items():
  p=ROOT/'results'/run/'best_dice.pth';expected=protocol['checkpoints'][name]
  assert sha256(p)==expected['sha256']
  state=torch.load(p,map_location='cpu',weights_only=False)
  model=SegmentationSystem(load_pretrained_encoder(),arm,42).cuda()
  model.load_state_dict(state['model'],strict=True);model.requires_grad_(False).eval()
  with torch.no_grad():reference.fill_cache(model,data,'val',cache)
  rows={mode:[] for mode in MODES};bits={mode:[] for mode in MODES}
  probs=[];identity_exact=True;logit_range=[1e9,-1e9]
  tick=time.perf_counter();torch.cuda.reset_peak_memory_stats()
  with torch.no_grad(),concurrent.futures.ThreadPoolExecutor(8) as pool:
   for start in range(0,len(ids),64):
    end=min(start+64,len(ids))
    with torch.autocast('cuda',dtype=torch.bfloat16):
     f3,f4=model.suffix(cache['mid'][start:end])
    features=[cache['features'][0][start:end],cache['features'][1][start:end],f3,f4]
    original=None
    for mode in MODES:
     fs=list(features);handle=None
     if mode.startswith('f1_'):
      fs[0]=torch.zeros_like(fs[0]) if mode=='f1_zero' else fs[0].mean((-2,-1),keepdim=True).expand_as(fs[0])
     if mode.startswith('f4_'):
      fs[3]=torch.zeros_like(fs[3]) if mode=='f4_zero' else fs[3].mean((-2,-1),keepdim=True).expand_as(fs[3])
     if mode=='ppm_zero':
      handle=model.probe.decode_head.psp_modules.register_forward_hook(lambda module,args,output:[torch.zeros_like(v) for v in output])
     try:
      with torch.autocast('cuda',dtype=torch.bfloat16):logits=model.probe(fs,(256,256))['main']
     finally:
      if handle is not None:handle.remove()
     assert torch.isfinite(logits).all()
     if mode=='intact':
      original=logits.clone();logit_range[0]=min(logit_range[0],float(logits.min()));logit_range[1]=max(logit_range[1],float(logits.max()))
     if mode=='identity_repeat':
      identity_exact=identity_exact and torch.equal(logits,original)
      assert identity_exact,'non-identity hook or numerical forward variation'
     probability=logits.float().sigmoid()[:,0].cpu().numpy()
     rows[mode].extend(pool.map(profile,zip(ids[start:end],probability,y[start:end])))
     bits[mode].append(np.packbits((probability>=.5).reshape(end-start,-1),axis=1))
     if mode=='intact':probs.append(probability)
    print(json.dumps(dict(model=name,processed=end,total=762)),flush=True)
  assert all(torch.equal(v.detach().cpu(),state['model'][k]) for k,v in model.state_dict().items()),'fixed state changed'
  old=json.loads((ROOT/'evaluations'/oldval/'METRICS.json').read_text())['validation']
  actual=summarize_rows(rows['intact'])
  assert abs(actual['macro']['dice']-old['macro']['dice'])<1e-5,'unexpected baseline replay drift'
  dest=OUT/'sensitivity'/name;dest.mkdir(parents=True,exist_ok=True)
  modelresult=dict(checkpoint=expected,baseline=actual,baseline_replay_dice_delta=actual['macro']['dice']-old['macro']['dice'],baseline_counts_exact=actual['counts']==old['counts'],identity_repeat_exact=identity_exact,logit_range=logit_range,seconds=time.perf_counter()-tick,peak_allocated_bytes=torch.cuda.max_memory_allocated(),modes={})
  for mode in MODES:
   summary=summarize_rows(rows[mode])
   modelresult['modes'][mode]=dict(metrics=summary,validation_area_groups=stratify(rows[mode],cuts),paired_vs_intact=bootstrap([r['dice'] for r in rows['intact']],[r['dice'] for r in rows[mode]]))
   writecsv(dest/(mode+'_per_image.csv'),rows[mode])
   np.savez_compressed(dest/(mode+'_predictions.npz'),ids=np.array(ids),packed_bits=np.concatenate(bits[mode]),height=256,width=256,threshold=.5)
  fp32prob=np.concatenate(probs);np.save(dest/'intact_validation_probabilities_fp32.npy',fp32prob)
  controlrows=rows['intact'];chosen=[]
  for key in [lambda r:r['dice'],lambda r:-r['FN_interior_gt_distance_gt8']/max(r['GT_area_px'],1),lambda r:-r['FP_far_from_GT_gt8']]:
   for r in sorted(controlrows,key=key)[:8]:
    if r['id'] not in chosen:chosen.append(r['id'])
  chosen=chosen[:24];indices=[ids.index(sid) for sid in chosen]
  grid=Image.new('RGB',(256*4,280*len(indices)),(255,255,255));draw=ImageDraw.Draw(grid)
  for row,i in enumerate(indices):
   im=np.asarray(Image.open(PROJECT/'data/isic2018/val/images'/(ids[i]+'.png')).convert('RGB').resize((256,256)))
   pred=fp32prob[i]>=.5;target=y[i];edge=target^binary_erosion(target)
   overlay=im.copy();overlay[edge]=[0,255,0]
   err=im.copy();err[(~pred)&target]=[255,0,0];err[pred&~target]=[0,255,255]
   deep=np.unpackbits(np.concatenate(bits['f4_spatial_mean'])[i]).reshape(256,256).astype(bool)
   deepim=im.copy();deepim[(~deep)&target]=[255,0,0];deepim[deep&~target]=[0,255,255]
   for col,pic in enumerate([im,overlay,err,deepim]):grid.paste(Image.fromarray(pic),(col*256,row*280+24))
   draw.text((4,row*280+3),f"val id={ids[i]} Dice={controlrows[i]['dice']:.3f}",fill=(0,0,0))
   draw.text((260,row*280+3),"GT contour green",fill=(0,0,0))
   draw.text((516,row*280+3),"intact FN red / FP cyan",fill=(0,0,0))
   draw.text((772,row*280+3),"f4 mean FN red / FP cyan",fill=(0,0,0))
  grid.save(dest/'failure_grid.png')
  atomic_json(dest/'CASE_SELECTION.json',dict(ids=chosen,rule='Union of first8 lowestDice, highestdeepFNfraction, highestfarFP. Deterministic; validation only.',colors=dict(FN='red',FP='cyan',GT_contour='green')))
  atomic_json(dest/'METRICS.json',modelresult);results[name]=modelresult
  assert sha256(p)==expected['sha256']
  del state,model,probs,fp32prob,features,original
  gc.collect();torch.cuda.empty_cache()
 atomic_json(OUT/'SENSITIVITY_SUMMARY.json',dict(complete=True,validation_only=True,test_read=False,validation_n=762,models=results,caveat='Zero and spatial-mean interventions shift the feature distribution. They reveal sensitivity, not proof of a defective branch or the outcome of retraining.',area_cuts_px=cuts.tolist(),source_sha256=sha256(Path(__file__))))
 atomic_json(ROOT/'reports/STAGEC_STATUS.json',dict(phase='diagnosis_complete',at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),validation_only=True,training_started=False))
 print('STAGEC_DIAGNOSIS_COMPLETE',flush=True)
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  atomic_json(ROOT/'reports/STAGEC_FAILURE.json',dict(traceback=traceback.format_exc()));raise
