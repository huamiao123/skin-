#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p runs
exec 9>runs/queue.lock
flock -n 9 || { echo 'Queue already active'; exit 1; }
export PYTHONNOUSERSITE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
py=/home/waas/mambavision_stage22/env/bin/python
state() {
    printf '%s %s\n' "$(date -Is)" "$*" > runs/queue_state.tmp
    mv runs/queue_state.tmp runs/queue_state.txt
    cat runs/queue_state.txt
}
phase=initialization
trap 'rc=$?; if [[ $rc != 0 ]]; then state "failed $phase rc=$rc"; fi' EXIT
for arm in add gated_concat f3_difference; do
    phase="train $arm"
    state "$phase"
    mkdir -p "runs/$arm"
    if [[ ! -s "runs/$arm/complete.json" ]]; then
        "$py" -u train_feature.py "$arm" >>"runs/$arm/train.log" 2>&1
    fi
    [[ -s "runs/$arm/complete.json" && -s "runs/$arm/best.pth" ]]
done
for arm in gated_concat f3_difference; do
    phase="diagnose $arm"
    state "$phase"
    "$py" -u paired_diagnostics.py "$arm" --reference runs/add/best.pth >>"runs/$arm/diagnostic.log" 2>&1
    [[ -s "runs/$arm/paired_diagnostic.json" ]]
done
phase=summary
"$py" -u compare_feature_runs.py
state complete
