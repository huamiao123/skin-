from pathlib import Path
import csv,json
q=Path(__file__).resolve().parent
archive=Path('/home/featurize/work/mambavision_seg_rebaseline_20261116')/'evaluations/stageA_20261117'
def read(file):
    with file.open() as f:
        rows=list(csv.DictReader(f))
    index={r['id']:r for r in rows}
    assert len(rows)==len(index)==762
    return index
native=read(q/'cases.csv')
groups=read(q/'contrast_cases.csv')
assert set(native)==set(groups)
report={}
for file in sorted(archive.glob('*/validation_per_image.csv')):
    archive_rows=read(file)
    assert set(native)==set(archive_rows)
    counts={'over':0,'under':0}
    for key, r in archive_rows.items():
        assert int(r['GT_area_px'])==int(native[key]['gt'])
        group=groups[key]['group']
        ratio=int(r['Pred_area_px'])/int(r['GT_area_px'])
        if group=='over' and ratio>1.25 or group=='under' and ratio<.8:
            counts[group]+=1
    report[file.parent.name]=dict(same_direction_beyond_cutoff=counts,total=sum(counts.values()),mean_dice=sum(float(r['dice']) for r in archive_rows.values())/len(archive_rows))
tmp=q/'archived_strata.tmp'
tmp.write_text(json.dumps(report,indent=2));tmp.replace(q/'archived_strata.json')
print(report)
