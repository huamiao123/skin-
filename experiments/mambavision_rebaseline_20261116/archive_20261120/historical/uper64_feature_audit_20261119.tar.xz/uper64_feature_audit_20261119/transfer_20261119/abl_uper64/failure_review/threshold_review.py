"""Check whether a single global probability cutoff accounts for the Dice difference."""
import numpy as np
import torch
from review import ARM,ROOT,OUT,reference,atomic_json,load_model,saved_rows


@torch.inference_mode()
def main():
    reference.setup()
    data,_=reference.load_data()
    ids=data.ids["val"]
    thresholds=np.arange(2,39,dtype=np.float64)/40
    ix0=int(np.where(thresholds==.5)[0][0])
    permutation=np.random.default_rng(42).permutation(np.argsort(np.array(ids)))
    folds=np.array_split(permutation,5)
    output={}
    for name,folder in (("baseline",ROOT.parent/"runs/add"),("abl",ARM)):
        model=load_model(folder)
        known=saved_rows(folder)
        scores=[]
        for start in range(0,len(ids),64):
            ix=torch.arange(start,min(start+64,len(ids)),device="cuda")
            ims,y=data.batch("val",ix)
            with torch.autocast("cuda",dtype=torch.bfloat16):
                prob=model(ims)["main"][:,0].float().sigmoid().cpu().numpy()
            for j,(p,g) in enumerate(zip(prob,(y[:,0]>=.5).cpu().numpy())):
                fg=np.sort(p[g])
                bg=np.sort(p[~g])
                tp=len(fg)-np.searchsorted(fg,thresholds)
                fp=len(bg)-np.searchsorted(bg,thresholds)
                assert g.any()
                dice=2*tp/(len(fg)+tp+fp)
                assert abs(dice[ix0]-float(known[ids[start+j]]["dice"]))<1e-12
                scores.append(dice)
        mat=np.stack(scores)
        out=np.empty(len(mat))
        chosen=[]
        for fold in folds:
            other=np.ones(len(mat),dtype=bool);other[fold]=False
            means=mat[other].mean(0)
            best=min(np.flatnonzero(means==means.max()),key=lambda k:abs(thresholds[k]-.5))
            out[fold]=mat[fold,best];chosen.append(float(thresholds[best]))
        output[name]=dict(fixed=float(mat[:,ix0].mean()),out_of_fold=float(out.mean()),fold_thresholds=chosen,
                          same_validation_optimistic_max=float(mat.mean(0).max()))
        del model
        torch.cuda.empty_cache()
    result=dict(n=len(ids),thresholds=thresholds.tolist(),fold_seed=42,metrics=output,test_used=False,
                note="diagnostic only; checkpoints selected using the entire development validation split")
    atomic_json(OUT/"threshold_review.json",result)
    print(output,flush=True)


if __name__=="__main__":main()
