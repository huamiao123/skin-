"""Development-only reach and alternate-position diagnostics on UPer64 predicted contours."""
import sys
from pathlib import Path
import csv
import cv2
import numpy as np
import torch
from scipy.ndimage import binary_erosion,distance_transform_edt,gaussian_filter,map_coordinates
from torch.nn import functional as F
from repeat_control import OUT,ROOT,reference,load_model,atomic_json,write_rows,dice

OFF=np.arange(-16,17)
CENTER=16


def edge(mask):
    # Internal transitions only; the image frame is not a target interface.
    return mask & ~binary_erosion(mask,border_value=1)


def normals(mask):
    signed=distance_transform_edt(mask)-distance_transform_edt(~mask)
    y=gaussian_filter(signed,2,order=(1,0))
    x=gaussian_filter(signed,2,order=(0,1))
    n=np.hypot(x,y)
    return np.stack([y/np.maximum(n,1e-6),x/np.maximum(n,1e-6)]),n


def picks(score):
    a=score.copy()
    a[:,np.abs(OFF)<4]=-np.inf
    first=a.argmax(1)
    a[np.abs(OFF[None,:]-OFF[first,None])<4]=-np.inf
    second=a.argmax(1)
    return np.stack([np.full(len(a),CENTER),first,second],axis=1)


def count_candidates(row,g,b,metric,random):
    be,ge=edge(b),edge(g)
    row.update(total_contour=int(be.sum()),eligible_contour=0,misplaced=0)
    for k in ("reachable","fixed","fixed4","fixed8","fixed12","fixed16","random","f1","rgb","f1_shuffled","rgb_shuffled"):row[k]=0
    bands=("3to6","6to12","12plus")
    for label in bands:
        for key in ("total","reachable","fixed4","f1","rgb","rgb_shuffled"):
            row["dist_"+label+"_"+key]=0
    if not be.any() or not ge.any(): return
    pn,pnorm=normals(b);gn,_=normals(g)
    dist,nearest=distance_transform_edt(~ge,return_indices=True)
    y,x=np.where(be&(pnorm>1e-5));p=np.stack([y,x])
    n=pn[:,y,x]
    coords=p[:,:,None]+n[:,:,None]*OFF[None,None,:]
    # All methods see the same complete +/-16 px window.
    keep=(coords[0].min(1)>=0)&(coords[0].max(1)<=g.shape[0]-1)&(coords[1].min(1)>=0)&(coords[1].max(1)<=g.shape[1]-1)
    row["eligible_contour"]=int(keep.sum())
    keep &= dist[y,x]>3
    if not keep.any(): return
    coords=coords[:,keep,:]
    n=n[:,keep]
    yy,xx=np.rint(coords).astype(int)
    ny,nx=nearest[:,yy,xx]
    aligned=(gn[0,ny,nx]*n[0,:,None]+gn[1,ny,nx]*n[1,:,None])>=.5
    hits=(dist[yy,xx]<=2)&aligned
    start_dist=dist[y[keep],x[keep]]
    strata=dict(zip(bands,((start_dist<=6),(start_dist>6)&(start_dist<=12),start_dist>12)))
    def record(key,values):
        for label,mask in strata.items():
            row["dist_"+label+"_"+key]=float(values[mask].sum())
    record("total",np.ones(len(hits)))
    record("reachable",hits.any(1))
    record("fixed4",hits[:,[CENTER-4,CENTER,CENTER+4]].any(1))
    row["misplaced"]=len(hits)
    row["reachable"]=int(hits.any(1).sum())
    row["fixed"]=int(hits[:,[CENTER-11,CENTER,CENTER+11]].any(1).sum())
    for offset in (4,8,12,16):
        row["fixed"+str(offset)]=int(hits[:,[CENTER-offset,CENTER,CENTER+offset]].any(1).sum())
    row["random"]=int(np.take_along_axis(hits,picks(random.random(hits.shape)),axis=1).any(1).sum())
    for name,tensor in metric.items():
        yy2,yx2,xx2=[map_coordinates(channel,coords,order=1,mode="nearest") for channel in tensor]
        score=yy2*n[0,:,None]**2+2*yx2*n[0,:,None]*n[1,:,None]+xx2*n[1,:,None]**2
        indices=picks(score)
        chosen=np.take_along_axis(hits,indices,axis=1).any(1)
        record(name,chosen)
        row[name]=int(chosen.sum())
        # Match the offset distribution and spacing within the same image.
        shuffle=np.random.default_rng(317 + sum(map(ord,str(row["id"]))))
        shuffled=[np.take_along_axis(hits,indices[shuffle.permutation(len(indices))],axis=1).any(1) for _ in range(24)]
        shuffled_hits=np.sum(shuffled,axis=1)
        if name=="rgb":
            record("rgb_shuffled",np.mean(shuffled,axis=0))
        row[name+"_shuffled"]=float(np.mean(shuffled_hits))


@torch.inference_mode()
def run():
    reference.setup();cv2.setNumThreads(1)
    data,_=reference.load_data();model=load_model(ROOT.parent/"runs/add")
    with (OUT/"contrast_cases.csv").open() as f:groups={r["id"]:r for r in csv.DictReader(f)}
    rows=[];rand=np.random.default_rng(42)
    for start in range(0,len(data.ids["val"]),64):
        ix=torch.arange(start,min(start+64,len(data.ids["val"])),device="cuda")
        images,t=data.batch("val",ix)
        with torch.autocast("cuda",dtype=torch.bfloat16):
            f1,f2,mid=model.prefix(images)
            predicted=model.from_cache(f1,f2,mid,(256,256))["main"][:,0].float().sigmoid()>=.5
        ch=f1.float()
        # Channel-standardized directional gradient energy in the stride-4 CNN feature map.
        ch=ch/ch.std((2,3),keepdim=True,unbiased=False).clamp_min(1e-4)
        gy,gx=torch.gradient(ch,dim=(2,3))
        cov=torch.stack([(gy*gy).mean(1),(gy*gx).mean(1),(gx*gx).mean(1)],dim=1)
        cov=F.interpolate(cov,size=(256,256),mode="bilinear",align_corners=False).cpu().numpy()
        for j,(g,b) in enumerate(zip((t[:,0]>=.5).cpu().numpy(),predicted.cpu().numpy())):
            sid=data.ids["val"][start+j];known=groups[sid]
            base=dice(b,g);assert abs(base-float(known["dice"]))<1e-12
            rgb=data.images["val"][start+j].permute(1,2,0).cpu().numpy().astype(np.float32)/255
            lab=cv2.cvtColor(rgb,cv2.COLOR_RGB2Lab)
            lab=gaussian_filter(lab,sigma=(1,1,0));dy,dx=np.gradient(lab,axis=(0,1))
            color=np.stack([(dy*dy).mean(2),(dy*dx).mean(2),(dx*dx).mean(2)])
            row=dict(id=sid,group=known["group"],base=base)
            e=edge(b)|edge(~b)
            distance=distance_transform_edt(~e) if e.any() else np.full(b.shape,np.inf)
            for rad in (3,8,16):
                band=distance<=rad
                row["band_"+str(rad)]=dice(np.where(band,g,b),g)
                row["fraction_"+str(rad)]=float(band.mean())
            count_candidates(row,g,b,dict(f1=cov[j],rgb=color),rand)
            rows.append(row)
    write_rows(OUT/"candidate_cases.csv",rows)
    result={}
    idx_rng=np.random.default_rng(42)
    for group in ("all","over","under","other"):
        use=[r for r in rows if group=="all" or r["group"]==group]
        hard=[r for r in use if r["misplaced"]>0]
        rates={k:np.array([r[k]/r["misplaced"] for r in hard]) for k in ("reachable","fixed","fixed4","fixed8","fixed12","fixed16","random","f1","rgb","f1_shuffled","rgb_shuffled")}
        diff=100*(rates["f1"]-rates["fixed"])
        idx=idx_rng.integers(len(hard),size=(5000,len(hard)))
        result[group]=dict(n=len(use),with_misplaced=len(hard),n_sites_misplaced=sum(r["misplaced"] for r in hard),
           eligible_fraction=sum(r["eligible_contour"] for r in use)/sum(r["total_contour"] for r in use),
           per_image_site_recall={k:float(a.mean()) for k,a in rates.items()},
           f1_minus_fixed_pp=float(diff.mean()),image_ci95_pp=np.quantile(diff[idx].mean(1),[.025,.975]).tolist(),
           native_dice=float(np.mean([r["base"] for r in use])),
           band_oracle={rad:dict(dice=float(np.mean([r["band_"+str(rad)] for r in use])),
                   field_fraction=float(np.mean([r["fraction_"+str(rad)] for r in use]))) for rad in (3,8,16)})
        for name in ("f1","rgb"):
            diff=100*(rates[name]-rates[name+"_shuffled"])
            result[group][name+"_minus_shuffled"]=dict(pp=float(diff.mean()),paired_image_ci95=np.quantile(diff[idx].mean(1),[.025,.975]).tolist())
        breakdown={}
        for label in ("3to6","6to12","12plus"):
            prefix="dist_"+label+"_"
            subset=[r for r in hard if r[prefix+"total"]>0]
            breakdown[label]={"n_images":len(subset),"n_sites":sum(int(r[prefix+"total"]) for r in subset),
                "recall":{key:float(np.mean([r[prefix+key]/r[prefix+"total"] for r in subset])) for key in ("reachable","fixed4","f1","rgb","rgb_shuffled")}}
        result[group]["distance_breakdown"]=breakdown
    atomic_json(OUT/"candidate_summary.json",result)
    print(result,flush=True)


if __name__=="__main__":run()
