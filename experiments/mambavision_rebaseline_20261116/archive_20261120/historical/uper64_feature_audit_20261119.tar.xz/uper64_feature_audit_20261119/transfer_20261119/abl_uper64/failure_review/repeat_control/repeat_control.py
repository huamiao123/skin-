"""Compare ABL to a repeat of its unchanged backbone/decoder on the same cases."""
import csv
import json
import sys
from pathlib import Path
import numpy as np
from scipy.ndimage import distance_transform_edt
import torch

OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT.parent))
from review import ARM,ROOT,load_model,saved_rows,reference,quota_dice,atomic_json,write_rows

NAMES=("historical","current","abl")
PAIRS=(("historical","current"),("current","abl"),("historical","abl"))


def dice(p,g):
    den=int(p.sum())+int(g.sum())
    return 2*int((p&g).sum())/den if den else 1.


@torch.inference_mode()
def run():
    reference.setup()
    base_new=ROOT.parent/"runs/add"
    base_old=ROOT.parent.parent/"method1_f3_20261118/uper64"
    paths=dict(zip(NAMES,(base_old,base_new,ARM)))
    known={name:saved_rows(path) for name,path in paths.items()}
    models={name:load_model(path) for name,path in paths.items()}
    data,_=reference.load_data()
    ids=data.ids["val"]
    assert all(set(records)==set(ids) for records in known.values())
    rows=[]
    for first in range(0,len(ids),64):
        ix=torch.arange(first,min(first+64,len(ids)),device="cuda")
        x,y=data.batch("val",ix)
        with torch.autocast("cuda",dtype=torch.bfloat16):
            native={name:m(x)["main"][:,0].float() for name,m in models.items()}
            flipped={name:m(x.flip([-1]))["main"][:,0].float().flip([-1]) for name,m in models.items()}
        raw={name:v.cpu().numpy() for name,v in native.items()}
        variants={**native,**{n+"_flipped":z for n,z in flipped.items()},
            **{n+"_two_views":(native[n]+flipped[n])*.5 for n in NAMES},
            **{n+"_"+m+"_two_models":(native[n]+native[m])*.5 for n,m in PAIRS}}
        bits={n:(v.sigmoid()>=.5).cpu().numpy() for n,v in variants.items()}
        for j,g in enumerate((y[:,0]>=.5).cpu().numpy()):
            sid=ids[first+j]
            row=dict(id=sid,gt=int(g.sum()))
            for n,arr in bits.items():
                p=arr[j]
                row[n+"_dice"]=dice(p,g)
                row[n+"_area"]=int(p.sum())
                if n in NAMES:
                    conf=tuple(int(v.sum()) for v in (p&g,p&~g,~p&g))
                    assert conf==tuple(int(known[n][sid][k]) for k in ("tp","fp","fn")), (n,sid,conf)
                    assert abs(row[n+"_dice"]-float(known[n][sid]["dice"]))<1e-12
            for n,m in PAIRS:
                d0=row[n+"_dice"];d1=row[m+"_dice"]
                av=quota_dice(raw[n][j],g,row[m+"_area"])
                bv=quota_dice(raw[m][j],g,row[n+"_area"])
                row[n+"_to_"+m+"_size_pp"]=50*((av-d0)+(d1-bv))
                row[n+"_to_"+m+"_rank_pp"]=50*((bv-d0)+(d1-av))
            pp=[bits[n][j] for n in NAMES]
            for label,bad,common,region in (
                ("fp",pp[1]&~g,pp[0]&pp[1]&pp[2]&~g,distance_transform_edt(~g)>8),
                ("fn",~pp[1]&g,~pp[0]&~pp[1]&~pp[2]&g,distance_transform_edt(np.pad(g,1))[1:-1,1:-1]>8)):
                row["current_"+label]=int(bad.sum());row["all_"+label]=int(common.sum())
                row["current_far_"+label]=int((bad&region).sum());row["all_far_"+label]=int((common&region).sum())
            rows.append(row)
    assert len(rows)==762
    write_rows(OUT/"cases.csv",rows)
    def v(k):return np.array([r[k] for r in rows])
    idx=np.random.default_rng(42).integers(len(rows),size=(5000,len(rows)))
    def delta(a,b):
        diff=100*(v(a+"_dice")-v(b+"_dice"))
        return dict(delta_pp=float(diff.mean()),image_ci95_pp=np.quantile(diff[idx].mean(1),[.025,.975]).tolist(),
                    mean_absolute_paired_pp=float(np.abs(diff).mean()))
    result=dict(n=len(rows),epoch=39,seed=42,test_used=False)
    result["validation_dice"]={k[:-5]:float(v(k).mean()) for k in rows[0] if k.endswith("_dice")}
    result["run_contrasts"]={}
    for a,b in PAIRS:
        tag=a+"_to_"+b
        obj=delta(b,a)
        obj["size_pp"]=float(v(tag+"_size_pp").mean())
        obj["rank_pp"]=float(v(tag+"_rank_pp").mean())
        assert abs(obj["size_pp"]+obj["rank_pp"]-obj["delta_pp"])<1e-9
        result["run_contrasts"][tag]=obj
    result["flip_gains"]={n:delta(n+"_two_views",n) for n in NAMES}
    result["ensemble_contrast"]=delta("current_abl_two_models","historical_current_two_models")
    result["two_view_abl_vs_current"]=delta("abl_two_views","current_two_views")
    result["common_errors"]={k:int(v(k).sum()) for k in rows[0] if any(k.endswith(t) for t in ("_fp","_fn"))}
    gt=v("gt");a,b,c=[v(n+"_area")/gt for n in NAMES]
    result["size_strata"]={}
    for cutoff in (1.1,1.25,1.5):
        over=(a>cutoff)&(b>cutoff);under=(a<1/cutoff)&(b<1/cutoff)
        both=over|under
        loss=1-v("current_dice")
        result["size_strata"][str(cutoff)]=dict(over=int(over.sum()),under=int(under.sum()),
              abl_repeats=int(((over&(c>cutoff))|(under&(c<1/cutoff))).sum()),
              share_current_dice_deficit=float(loss[both].sum()/loss.sum()),
              mean_current_dice=float(v("current_dice")[both].mean()),
              mean_abl_dice=float(v("abl_dice")[both].mean()),
              mean_hist_cur_ensemble_dice=float(v("historical_current_two_models_dice")[both].mean()),
              mean_current_tta_dice=float(v("current_two_views_dice")[both].mean()))
    atomic_json(OUT/"summary.json",result)
    print(json.dumps(result),flush=True)


if __name__=="__main__":run()
