"""Replay both validation-selected models, separating predicted extent, ranking, and the ABL signal."""
import csv
import json
from pathlib import Path
import sys

import numpy as np
import torch
from PIL import Image, ImageDraw
from scipy.ndimage import binary_erosion, distance_transform_edt, label

OUT=Path(__file__).resolve().parent
ARM=OUT.parent
ROOT=ARM.parent
sys.path.insert(0,str(ROOT))
from area_oracle import quota_dice, reference, build, atomic_json, write_rows
from active_boundary import BoundaryCriterion, COEFFICIENT
from model import segmentation_loss


def saved_rows(run):
    with (run/"best_validation.csv").open() as stream:
        return {r["id"]:r for r in csv.DictReader(stream)}


def load_model(run):
    model=build("add").eval()
    ck=torch.load(run/"best.pth",map_location="cpu")
    assert ck["epoch"]==39
    model.load_state_dict(ck["model"],strict=True)
    return model.requires_grad_(False)


def correction_gradient(layer,raw,dist,valid,target):
    z=raw.detach().requires_grad_(True)
    aux=layer(z,dist,valid)
    grad=torch.autograd.grad(COEFFICIENT*aux,z)[0]
    main=torch.autograd.grad(segmentation_loss(z,target),z)[0]
    return grad[:,0].detach().cpu().numpy(),main[:,0].detach().cpu().numpy()


@torch.no_grad()
def direction_stats(layer,logits,dist,active):
    y,local,w=layer.author.get_direction_gt_predkl(dist,active,logits)
    weights=layer.author.weight_func(w)
    ce=layer.author.criterion(local,y)
    uniform=layer.author.criterion(torch.zeros_like(local),y)
    return np.array([len(w),float(weights.double().sum()),float((weights*ce).double().sum()),
                     float((weights*uniform).double().sum())])


def picture(pixels,gt,baseline,candidate):
    def ring(mask):return mask ^ binary_erosion(mask,border_value=0)
    target=pixels.copy()
    target[ring(gt)]=[39,244,186]
    def overlay(pred):
        image=target.copy()
        image[ring(pred)]=[255,171,32]
        return image
    delta=(pixels*.60).astype(np.uint8)
    changed=baseline!=candidate
    delta[changed&(candidate==gt)]=[37,225,176]
    delta[changed&(candidate!=gt)]=[242,65,132]
    return np.concatenate([target,overlay(baseline),overlay(candidate),delta],axis=1)


def main():
    reference.setup()
    base=ROOT.parent/"runs/add"
    data,_=reference.load_data()
    ids=data.ids["val"]
    truth=[saved_rows(p) for p in (base,ARM)]
    models=[load_model(p) for p in (base,ARM)]
    rank=sorted(ids,key=lambda k:float(truth[1][k]["dice"])-float(truth[0][k]["dice"]))
    selected=rank[:3]+[rank[len(rank)//2]]+rank[-2:]
    figs={}
    layer=BoundaryCriterion().cuda()
    rows=[];point_stats={}
    for first in range(0,len(ids),64):
        ix=torch.arange(first,min(first+64,len(ids)),device="cuda")
        images,target=data.batch("val",ix)
        dist,valid=layer.maps(target)
        with torch.no_grad(),torch.autocast("cuda",dtype=torch.bfloat16):
            z=[m(images)["main"].float() for m in models]
        grads,main_grads=correction_gradient(layer,z[1],dist,valid,target)
        with torch.no_grad():
            channels=[torch.cat((torch.zeros_like(x),x),1) for x in z]
            sites=[layer.candidates(c)&valid[:,None,None] for c in channels]
            for i,logits in enumerate(channels):
                for j,active in enumerate(sites):
                    key=f"logits_{i}_sites_{j}"
                    vals=direction_stats(layer,logits,dist,active)
                    point_stats[key]=point_stats.get(key,0)+vals
            masks=[(v[:,0].sigmoid()>=.5).cpu().numpy() for v in z]
            raw=[v[:,0].cpu().numpy() for v in z]
            gt=(target[:,0]>=.5).cpu().numpy()
        for j,g in enumerate(gt):
            k=ids[first+j];b,a=[v[j] for v in masks]
            zz0,zz1=[v[j] for v in raw]
            count=[int(b.sum()),int(a.sum())]
            native=[]
            for m,prediction in enumerate((b,a)):
                tp,fp,fn=[int(x.sum()) for x in (prediction&g,prediction&~g,~prediction&g)]
                assert [tp,fp,fn]==[int(truth[m][k][x]) for x in ("tp","fp","fn")]
                native.append(float(truth[m][k]["dice"]))
            bb,aa=native
            ba=quota_dice(zz0,g,count[1])
            ab=quota_dice(zz1,g,count[0])
            area=.5*((ba-bb)+(aa-ab))
            ordering=.5*((ab-bb)+(aa-ba))
            assert abs(area+ordering-(aa-bb))<1e-12
            inside=distance_transform_edt(np.pad(g,1))[1:-1,1:-1]
            outside=distance_transform_edt(~g)
            farfp=~g&(outside>8)
            added=farfp&a&~b
            removed=farfp&~a&b
            cc,num=label(a,structure=np.ones((3,3),bool))
            overlapping=np.unique(cc[g]);overlapping=overlapping[overlapping>0]
            attached=np.isin(cc,overlapping)
            ga=grads[j]
            gm=main_grads[j]
            nonzero=ga!=0
            support=(added&nonzero).sum()
            denom=np.square(ga,dtype=np.float64).sum()**.5
            direct=np.square(gm,dtype=np.float64).sum()**.5
            row=dict(id=k,base_dice=bb,abl_dice=aa,base_order_abl_area=ba,abl_order_base_area=ab,
                     area_pp=area*100,ordering_pp=ordering*100,gt_area=int(g.sum()),base_area=count[0],abl_area=count[1],
                     new_far_fp=int(added.sum()),corrected_far_fp=int(removed.sum()),new_far_fp_attached=int((attached&added).sum()),
                     new_far_fp_with_aux_grad=int(support),direct_grad_pixels=int(nonzero.sum()),pixels=g.size,
                     grad_l2_ratio=denom/direct if direct else 0.,
                     grad_cosine=float(np.multiply(ga,gm,dtype=np.float64).sum()/(denom*direct)) if denom*direct else 0.)
            rows.append(row)
            if k in selected:
                pix=data.images["val"][first+j].permute(1,2,0).cpu().numpy()
                figs[k]=picture(pix,g,b,a)
    assert len(rows)==len(set(r["id"] for r in rows))==762
    write_rows(OUT/"case_review.csv",rows)
    def mean(key):return float(np.mean([r[key] for r in rows]))
    def total(key):return int(sum(r[key] for r in rows))
    def boot(key):
        v=np.array([r[key] for r in rows]);idx=np.random.default_rng(42).integers(len(v),size=(5000,len(v)))
        return dict(mean_pp=float(v.mean()),paired_image_ci95_pp=np.quantile(v[idx].mean(1),[.025,.975]).tolist())
    guide={k:dict(n=int(v[0]),mean_weight=v[1]/v[0],raw_loss=v[2]/v[0],direction_ce_weighted=v[2]/v[1],
                  uniform_ce_weighted=v[3]/v[1]) for k,v in point_stats.items()}
    result=dict(n=len(rows),base_dice=mean("base_dice"),abl_dice=mean("abl_dice"),
                base_order_abl_area=mean("base_order_abl_area"),abl_order_base_area=mean("abl_order_base_area"),
                area_component=boot("area_pp"),ranking_component=boot("ordering_pp"),aux_point_stats=guide,
                directly_supported_pixel_fraction=total("direct_grad_pixels")/total("pixels"),
                median_aux_to_main_logit_grad_L2=float(np.median([r["grad_l2_ratio"] for r in rows])),
                median_grad_cosine=float(np.median([r["grad_cosine"] for r in rows])),
                new_far_fp=total("new_far_fp"),fixed_far_fp=total("corrected_far_fp"),
                attached_new_far_fp=total("new_far_fp_attached"),new_far_fp_with_nonzero_ABL=total("new_far_fp_with_aux_grad"),
                selected_ids=selected,test_used=False)
    atomic_json(OUT/"review.json",result)
    labels={r["id"]:r for r in rows}
    sheet=Image.new("RGB",(1024,34+len(selected)*281),"white")
    pen=ImageDraw.Draw(sheet)
    for i,name in enumerate(("Image + GT","UPer64 + GT","UPer64/ABL + GT","Changed pixels: green fixed, pink new errors")):
        pen.text((256*i+3,5),name,fill="black")
    for i,k in enumerate(selected):
        y=29+i*281;r=labels[k]
        pen.text((4,y),f"Val ID {k}   Dice {100*r['base_dice']:.2f} -> {100*r['abl_dice']:.2f}   |   GT turquoise, prediction orange",fill="black")
        sheet.paste(Image.fromarray(figs[k]),(0,y+20))
    sheet.save(OUT/"cases.jpg",quality=87)
    print(json.dumps(result),flush=True)


if __name__=="__main__":main()
