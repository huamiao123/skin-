"""Exploratory within-image contrast of the annotated and predicted contours at 256x256."""
import csv
import sys
from pathlib import Path
import cv2
import numpy as np
from scipy.ndimage import binary_erosion,distance_transform_edt,gaussian_filter,map_coordinates
from scipy.stats import rankdata,spearmanr
import torch
from repeat_control import OUT,ROOT,reference,load_model,atomic_json,write_rows


def median_contrast(lab,mask,other):
    if not mask.any() or mask.all(): return np.nan,np.nan,0
    edge=mask&~binary_erosion(mask,border_value=0)
    ed2=other&~binary_erosion(other,border_value=0)
    away=distance_transform_edt(~ed2)>8 if ed2.any() else np.ones_like(mask)
    u,v=np.where(edge)
    keep=(u>=7)&(u<mask.shape[0]-7)&(v>=7)&(v<mask.shape[1]-7)
    u,v=u[keep],v[keep]
    if len(u)==0:return np.nan,np.nan,0
    signed=distance_transform_edt(mask)-distance_transform_edt(~mask)
    du=gaussian_filter(signed,2,order=(1,0))[u,v]
    dv=gaussian_filter(signed,2,order=(0,1))[u,v]
    norm=np.hypot(du,dv)
    valid=norm>1e-5
    u,v=u[valid],v[valid];du,dv=du[valid]/norm[valid],dv[valid]/norm[valid]
    if len(u)==0:return np.nan,np.nan,0
    p=np.stack([u,v]);normal=np.stack([du,dv])
    # Sample Lab on either side of the local normal; RGB has already been lightly smoothed.
    differences=np.stack([map_coordinates(ch,p+4*normal,order=1,mode="nearest")-
                          map_coordinates(ch,p-4*normal,order=1,mode="nearest") for ch in lab],axis=0)
    dist=np.sqrt(np.square(differences).sum(0))
    bad=away[u,v]
    return float(np.median(dist)),float(np.median(dist[bad])) if bad.sum()>=10 else np.nan,int(bad.sum())


def main():
    reference.setup();cv2.setNumThreads(1)
    data,_=reference.load_data()
    model=load_model(ROOT.parent/"runs/add")
    with (OUT/"cases.csv").open() as f: established={r["id"]:r for r in csv.DictReader(f)}
    rows=[]
    for start in range(0,len(data.ids["val"]),64):
        ix=torch.arange(start,min(start+64,len(data.ids["val"])),device="cuda")
        ims,t=data.batch("val",ix)
        with torch.inference_mode(),torch.autocast("cuda",dtype=torch.bfloat16):
            masks=(model(ims)["main"][:,0].float().sigmoid()>=.5).cpu().numpy()
        for j,(g,b) in enumerate(zip((t[:,0]>=.5).cpu().numpy(),masks)):
            sid=data.ids["val"][start+j];r=established[sid]
            size=int(g.sum());assert size==int(r["gt"]) and int(b.sum())==int(r["current_area"])
            assert abs((2*int((b&g).sum())/(b.sum()+size))-float(r["current_dice"]))<1e-12
            rgb=data.images["val"][start+j].permute(1,2,0).cpu().numpy()
            lab=cv2.cvtColor(rgb.astype(np.float32)/255,cv2.COLOR_RGB2LAB).transpose(2,0,1)
            lab=gaussian_filter(lab,sigma=(0,1,1))
            gc,gfar,ng=median_contrast(lab,g,b);pc,pfar,npix=median_contrast(lab,b,g)
            ratio=np.array([int(r[k+"_area"])/size for k in ("current","historical")])
            group="over" if (ratio>1.25).all() else "under" if (ratio<.8).all() else "other"
            rows.append(dict(id=sid,group=group,gt=size,gt_contrast=gc,pred_contrast=pc,
                             gt_missed_contour=gfar,pred_displaced_contour=pfar,ng=ng,npred=npix,
                             dice=float(r["current_dice"])))
    write_rows(OUT/"contrast_cases.csv",rows)
    size=np.array([r["gt"] for r in rows])
    bins=np.minimum((rankdata(size,method="average")*10/len(size)).astype(int),9)
    gc=np.array([r["gt_contrast"] for r in rows])
    adjusted=gc.copy()
    for i in range(10):adjusted[bins==i]-=np.nanmedian(gc[bins==i])
    result={"details":"Lab distance between +/-4 pixels on contour normals, sigma1 color smoothing. Median by image. GT area decile centering is descriptive."}
    for group in ("over","under","other"):
        ix=np.array([r["group"]==group for r in rows])
        gp=np.array([r["gt_missed_contour"] for r in rows]);pp=np.array([r["pred_displaced_contour"] for r in rows]);valid=ix&np.isfinite(gp)&np.isfinite(pp)
        gap=pp[valid]-gp[valid]
        result[group]=dict(n=int(ix.sum()),usable=int(np.isfinite(gc[ix]).sum()),
                median_gt_contrast=float(np.nanmedian(gc[ix])),median_size_centered_gt_contrast=float(np.nanmedian(adjusted[ix])),
                displaced_pairs=int(valid.sum()),predicted_stronger=int((gap>0).sum()),
                median_displaced_pred_minus_gt=float(np.median(gap)) if len(gap) else None)
    dice=np.array([r["dice"] for r in rows]);ok=np.isfinite(gc)
    result["spearman_contrast_dice"]=float(spearmanr(gc[ok],dice[ok]).statistic)
    atomic_json(OUT/"contrast_summary.json",result)
    print(result,flush=True)


if __name__=="__main__":main()
