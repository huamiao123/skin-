"""Parameter-gradient probes on fixed augmented training batches; no optimizer steps."""
import gc
import json
from pathlib import Path
import sys
import numpy as np
import torch

from review import ARM,OUT,ROOT,build,reference,atomic_json
from active_boundary import BoundaryCriterion,COEFFICIENT
from model import segmentation_loss


def grouped_metrics(groups,main,aux):
    out={}
    pos=0
    for key,size in groups:
        aa=bb=ab=torch.zeros((),device="cuda",dtype=torch.float64)
        for a,b in zip(main[pos:pos+size],aux[pos:pos+size]):
            if a is None and b is None: continue
            if a is not None:aa=aa+torch.linalg.vector_norm(a.float()).double().square()
            if b is not None:bb=bb+torch.linalg.vector_norm(b.float()).double().square()
            if a is not None and b is not None:ab=ab+torch.sum(a.float()*b.float()).double()
        pos+=size
        am,bm,dot=[float(x) for x in (aa.sqrt(),bb.sqrt(),ab)]
        out[key]=dict(main_norm=am,weighted_aux_norm=bm,ratio=bm/am,cosine=dot/(am*bm) if am*bm else None)
    return out


def main():
    layer=BoundaryCriterion().cuda()
    reference.setup()
    data,_=reference.load_data()
    result={}
    for stamp,src,date in (("init",None,1),("best",ARM/"best.pth",40),("last",ARM/"latest.pth",100)):
        reference.setup()
        model=build("add")
        if src:
            state=torch.load(src,map_location="cpu")
            model.load_state_dict(state["model"],strict=True)
            del state
        order,geometry=data.geometry(date)
        model.train()
        a=[p for p in model.probe.parameters() if p.requires_grad]
        b=[p for p in model.encoder.parameters() if p.requires_grad]
        groups=[("decoder",len(a)),("encoder",len(b))]
        records=[]
        # Same 4 batch positions at each state; geometric augmentation follows the indicated epoch.
        for start in (0,448,896,1344):
            ids=order[start:start+64]
            ims,target=data.batch("train",ids,geometry)
            dist,valid=layer.maps(target)
            with torch.autocast("cuda",dtype=torch.bfloat16):
                out=model(ims)["main"].float()
            main_loss=segmentation_loss(out,target)
            extra=layer(out,dist,valid)*COEFFICIENT
            gp=torch.autograd.grad(main_loss,a+b,retain_graph=True,allow_unused=True)
            gx=torch.autograd.grad(extra,a+b,allow_unused=True)
            rec=dict(start=start,main_loss=float(main_loss.detach()),weighted_aux_loss=float(extra.detach()),
                     groups=grouped_metrics(groups,gp,gx))
            assert all(np.isfinite(v["ratio"]) and v["ratio"]>0 for v in rec["groups"].values())
            records.append(rec)
            del gp,gx,main_loss,extra,out
        result[stamp]=records
        del model,a,b
        gc.collect()
        torch.cuda.empty_cache()
    atomic_json(OUT/"train_gradients.json",result)
    for name,records in result.items():
        print(name,{g:np.median([r["groups"][g]["ratio"] for r in records]) for g in ("decoder","encoder")},flush=True)


if __name__=="__main__":main()
