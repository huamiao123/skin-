"""Check whether best-epoch error patterns persist at the common last epoch."""
import json
from pathlib import Path
import numpy as np
from scipy.ndimage import distance_transform_edt
import torch
from review import ROOT,ARM,OUT,reference,build,atomic_json,quota_dice


@torch.inference_mode()
def main():
    reference.setup()
    data,_=reference.load_data()
    regions=("near","mid","far")
    models=[];known=[]
    for p in (ROOT.parent/"runs/add",ARM):
        model=build("add").eval()
        state=torch.load(p/"latest.pth",map_location="cpu")
        assert state["history"][-1]["epoch"]==100
        known.append(state["history"][-1]["val_macro_dice"])
        model.load_state_dict(state["model"],strict=True)
        del state
        models.append(model)
    result=[]
    for i in range(0,len(data.ids["val"]),64):
        ids=torch.arange(i,min(i+64,len(data.ids["val"])),device="cuda")
        x,y=data.batch("val",ids)
        with torch.autocast("cuda",dtype=torch.bfloat16):
            scores=[m(x)["main"][:,0].float() for m in models]
        bits=[(v.sigmoid()>=.5).cpu().numpy() for v in scores]
        zz=[v.cpu().numpy() for v in scores]
        for j,g in enumerate((y[:,0]>=.5).cpu().numpy()):
            truth_distance=np.where(g,distance_transform_edt(np.pad(g,1))[1:-1,1:-1],distance_transform_edt(~g))
            dst=[truth_distance<=3,(truth_distance>3)&(truth_distance<=8),truth_distance>8]
            row={}
            ks=[];di=[]
            for name,b in zip(("b","a"),bits):
                pred=b[j];k=int(pred.sum());den=int(g.sum())+k
                dice=2*int((g&pred).sum())/den
                ks.append(k);di.append(dice);row[name]=dice
                for band,mask in zip(regions,dst):
                    row[name+"_"+band]=100*int(((pred!=g)&mask).sum())/den
            ab=quota_dice(zz[1][j],g,ks[0]);ba=quota_dice(zz[0][j],g,ks[1])
            row["area_pp"]=50*((ba-di[0])+(di[1]-ab))
            row["order_pp"]=50*((ab-di[0])+(di[1]-ba))
            result.append(row)
    means={k:float(np.mean([r[k] for r in result])) for k in result[0]}
    assert len(result)==762
    assert abs(means["a"]-known[1])<1e-12 and abs(means["b"]-known[0])<1e-12
    atomic_json(OUT/"last_epoch_replay.json",dict(epoch=100,n=762,means=means,test_used=False))
    print(means,flush=True)


if __name__=="__main__":main()
