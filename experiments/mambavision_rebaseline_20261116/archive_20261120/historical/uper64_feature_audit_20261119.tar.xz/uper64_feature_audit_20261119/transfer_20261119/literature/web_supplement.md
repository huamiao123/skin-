# 经过核对的论文与作者实现

检索分为医学分割面积与损失、皮肤病灶边界与标注、自然图像的金字塔融合三个方向。以下条目用原论文、出版社、会议或作者仓库交叉核对。各组 API 原始记录分别在 corpus、dermoscopy、pyramid，作者仓库检索在 source_checks.json。未使用各篇论文不同划分上的数值给本项目排序。

| 来源 | 方法与可迁移问题 | 核查依据 |
|---|---|---|
| Liu 等，Medical Image Analysis，卷期 2024 | 从目标函数分析区域大小偏倚，提供二值视网膜病变的 CE 加 L1 前景占比配置。已核查 get_region_proportion 和 CrossEntropyWithL1，正式迁移只取比例项。 | [论文](https://pubmed.ncbi.nlm.nih.gov/37918314/) · [作者实现固定版本](https://github.com/by-liu/SegLossBias/blob/81fb0a47748f3151f656b40b92f93cf27801f289/seglossbias/modeling/compound_losses.py) · [视网膜配置](https://github.com/by-liu/SegLossBias/blob/81fb0a47748f3151f656b40b92f93cf27801f289/configs/retinal-lesions/unet_bce-l1_896x896.yaml) |
| Adaptive Region-Specific Loss，IEEE TPAMI 2023 | 把体数据划成子区域，按局部误报与漏分调整损失。可以检验单个面积匹配后同一图内仍有两种错误的情况。体数据结论须在二维皮肤图重新验证。 | [原文](https://pmc.ncbi.nlm.nih.gov/articles/PMC11346301/) |
| Xu 等，AAAI 2025 | 区分多数类/少数类的频率差异与类内难例，对应两类不同的训练加权。适合检验前景和背景难例竞争的假设。 | [原文](https://ojs.aaai.org/index.php/AAAI/article/view/32956) |
| Yuan 等，ECCV 2020，OCRNet | 按预测区域聚合像素形成对象表示，通过像素与对象表示的关系补充上下文。可在二值任务用前景/背景两个参考，须控制辅助监督、投影维度和均匀池化。获取并查看了作者 HRNet-OCR 分支的 SpatialGather_Module 与 SpatialOCR_Module。 | [论文](https://www.ecva.net/papers/eccv_2020/papers_ECCV/papers/123510171.pdf) · [作者代码](https://github.com/HRNet/HRNet-Semantic-Segmentation/blob/HRNet-OCR/lib/models/seg_hrnet_ocr.py) |
| Huang 等，ICCV 2021，FaPN | 对齐自顶向下和横向特征，专门处理相加前的空间误配。适用于病例有局部错位证据时。本文核对到论文和作者仓库地址。 | [论文](https://openaccess.thecvf.com/content/ICCV2021/html/Huang_FaPN_Feature-Aligned_Pyramid_Network_for_Dense_Image_Prediction_ICCV_2021_paper.html) · [作者仓库](https://github.com/EMI-Group/FaPN) |
| Liu 等，ICCV 2023，DySample | 通过学习偏移作点采样上采样。可只替换一级 FPN 的双线性上采样。已核查 dysample.py。需要检查边界错位、额外运算及等参数对照。 | [论文](https://openaccess.thecvf.com/content/ICCV2023/html/Liu_Learning_to_Upsample_by_Learning_to_Sample_ICCV_2023_paper.html) · [作者代码](https://github.com/tiny-smart/dysample/blob/main/dysample.py) |
| LB-UNet，MICCAI 2024 | 面向皮肤病灶，通过区域和边界监督及预测图辅助分割。边界专门机制应在明确的贴边错误上对照。已查看作者 lbunet.py。 | [原文](https://papers.miccai.org/miccai-2024/446-Paper2135.html) · [作者代码](https://github.com/xuxuxuxuxuxjh/LB-UNet) |
| Kervadec 等，MIDL 2019 | 利用有符号距离把边界距离目标写成区域积分，可用来检验边界定位问题。内部大段漏分与边界微调应分别评价。 | [论文](https://proceedings.mlr.press/v102/kervadec19a.html) |
| Robust T-Loss，MICCAI 2023，Medical Image Analysis 2025 扩展 | 包括皮肤病灶实验，用 Student-t 目标降低噪声标注影响。已查看作者 TLoss 类。项目旧审计中的两个文献噪声病例支持单独检查标签，不支持删除难例或把总体差距归因于噪声。 | [扩展论文](https://pubmed.ncbi.nlm.nih.gov/40743711/) · [作者代码](https://github.com/Digital-Dermatology/t-loss) · [独立的 ISIC 标注实证](https://pmc.ncbi.nlm.nih.gov/articles/PMC10407008/) |
| Rahman 等，CVPR 2024，EMCAD | 多尺度深度卷积和不同注意力解码。项目历史已有 EMCAD 与集成修订，迁移时需区分实际新增因素。 | [论文](https://openaccess.thecvf.com/content/CVPR2024/html/Rahman_EMCAD_Efficient_Multi-scale_Convolutional_Attention_Decoding_for_Medical_Image_Segmentation_CVPR_2024_paper.html) |
| Ma 等，Medical Image Analysis 2021 | 在多项任务、数据集实测多种损失。给现有 BCE 加 Dice 保留强对照的依据。 | [论文](https://pubmed.ncbi.nlm.nih.gov/33813286/) · [作者基准](https://github.com/JunMa11/SegLossOdyssey) |
| Isensee 等，MICCAI 2024 | 从 3D 分割实证强调算力、训练配方、公平比较的影响。对当前 0.1–0.2 个百分点差异，独立训练种子和数据来源应分别核实。 | [原文](https://papers.miccai.org/miccai-2024/562-Paper2847.html) |
