# Scholarly Deep Research Retrieval Report

- Query: semantic segmentation feature alignment pyramid upsampling
- Year range: 2016 to 2026
- Records after deduplication: 14
- Ranking: score = 0.40 * lexical_relevance + 0.20 * citation_score + 0.15 * recency_score + 0.10 * venue_source_confidence + 0.10 * open_access_score + 0.05 * metadata_completeness

## Ranked Papers

### 1. CFPNET: Channel-Wise Feature Pyramid For Real-Time Semantic Segmentation

- Score: 0.7895
- Authors: Ange Lou, Murray Loew
- Year / Venue: 2021 / 2021 IEEE International Conference on Image Processing (ICIP)
- DOI: 10.1109/icip42928.2021.9506485
- Sources: crossref
- Citations: 80
- URL: https://doi.org/10.1109/icip42928.2021.9506485

### 2. BLAST-NET: Semantic Segmentation of Human Blastocyst Components via Cascaded Atrous Pyramid and Dense Progressive Upsampling

- Score: 0.7195
- Authors: Reza Moradi Rad, Parvaneh Saeedi, Jason Au, Jon Havelock
- Year / Venue: 2019 / 2019 IEEE International Conference on Image Processing (ICIP)
- DOI: 10.1109/icip.2019.8803139
- Sources: crossref
- Citations: 26
- URL: https://doi.org/10.1109/icip.2019.8803139

### 3. Efficient pyramid context encoding and feature embedding for semantic segmentation

- Score: 0.7157
- Authors: Mengyu Liu, Hujun Yin
- Year / Venue: 2021 / Image and Vision Computing
- DOI: 10.1016/j.imavis.2021.104195
- Sources: crossref
- Citations: 15
- URL: https://doi.org/10.1016/j.imavis.2021.104195

### 4. Semantic Segmentation of Fashion Images Using Feature Pyramid Networks

- Score: 0.7122
- Authors: John Martinsson, Olof Mogren
- Year / Venue: 2019 / 2019 IEEE/CVF International Conference on Computer Vision Workshop (ICCVW)
- DOI: 10.1109/iccvw.2019.00382
- Sources: crossref
- Citations: 22
- URL: https://doi.org/10.1109/iccvw.2019.00382

### 5. Enhanced Feature Pyramid Network for Semantic Segmentation

- Score: 0.7026
- Authors: Mucong Ye, Jingpeng Ouyang, Ge Chen, Jing Zhang, et al.
- Year / Venue: 2021 / 2020 25th International Conference on Pattern Recognition (ICPR)
- DOI: 10.1109/icpr48806.2021.9413224
- Sources: crossref
- Citations: 11
- URL: https://doi.org/10.1109/icpr48806.2021.9413224

### 6. Cross-layer attentive feature upsampling for low-latency semantic segmentation

- Score: 0.6998
- Authors: Tianheng Cheng, Xinggang Wang, Junchao Liao, Wenyu Liu
- Year / Venue: 2025 / Machine Vision and Applications
- DOI: 10.1007/s00138-024-01631-2
- Sources: crossref
- Citations: 3
- URL: https://doi.org/10.1007/s00138-024-01631-2
- Abstract: Abstract Semantic segmentation is a fundamental problem in computer vision and it requires high-resolution feature maps for dense prediction. Current coordinate-guided low-resolution feature interpolation methods, e.g., bilinear interpolation, produce coarse high-resolution features which suffer from feature misalignment and insufficient context information. Moreover, enriching semantics to high-resolution features requires a high computation burden, so that it is challenging to meet the requirement of lowlatency inference. We propose a novel Guided Attentive Interpolation (GAI) method to adaptively interpolate fine-grained high-resolution features with semantic features to tackle these issu

### 7. Real-Time Semantic Edge Segmentation Using Modified Channelwise Feature Pyramid

- Score: 0.6726
- Authors: H. Harish, A. Sreenivasa Murthy
- Year / Venue: 2023 / SN Computer Science
- DOI: 10.1007/s42979-023-02338-3
- Sources: crossref
- Citations: 3
- URL: https://doi.org/10.1007/s42979-023-02338-3

### 8. Depth-Aware Feature Pyramid Network for Semantic Segmentation

- Score: 0.6595
- Authors: Taehyeon Kim, Seho Park, Kyung-Taek Lee
- Year / Venue: 2023 / 2023 Fourteenth International Conference on Ubiquitous and Future Networks (ICUFN)
- DOI: 10.1109/icufn57995.2023.10199328
- Sources: crossref
- Citations: 2
- URL: https://doi.org/10.1109/icufn57995.2023.10199328

### 9. Det2Seg: Detection-to-Segmentation Feature Alignment for Semi-Supervised Semantic Segmentation

- Score: 0.6395
- Authors: Chengkun Ge, Da-Kui Wu, Wenju Zhou, Shengqiang Cai
- Year / Venue: 2026 / Unknown
- DOI: 10.2139/ssrn.7228088
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.2139/ssrn.7228088
- Abstract: Pixel-level annotations are widely regarded as essential for accurate semantic segmentation, yet the large-scale deployment of segmentation models is constrained by their high acquisition cost. Compared with dense masks, bounding-box annotations can be acquired with substantially less labeling effort while preserving reliable object-category and localization cues. In this study, Det2Seg is introduced as a detection-guided semi-supervised semantic segmentation framework, in which bounding-box annotations are provided for the entire training set, whereas pixel-level masks are available for only a small subset. Detection-derived object-level priors are transferred to the segmentation branch thr

### 10. Spatial-frequency feature alignment network with multiscale pyramid fusion for remote sensing image semantic segmentation

- Score: 0.6133
- Authors: Yuxin Zheng, Lai Jiang, Aibin Huang
- Year / Venue: 2026 / Journal of Applied Remote Sensing
- DOI: 10.1117/1.jrs.20.026506
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.1117/1.jrs.20.026506
- Abstract: Remote sensing image semantic segmentation remains challenging due to complex spatial distributions, inter-class spectral confusion, and extreme scale variations. Although convolutional neural networks capture local features effectively, they exhibit limitations in modeling the global context. Existing methods often underutilize frequency domain information, with simple fusion strategies failing to exploit spatial-frequency complementarity. We propose the adaptive spatial-frequency feature alignment network with multiscale pyramid fusion (ASFNet). Built on a ConvNeXt-Small backbone, ASFNet employs adaptive spatial-frequency feature alignment to adaptively align spatial and frequency domain f

### 11. DFPNet:Dislocation Double Feature Pyramid Real-time Semantic Segmentation Network

- Score: 0.5795
- Authors: Qin Fang, Jun Qiu, Hao Wu, Jie Yang
- Year / Venue: 2020 / 2020 Chinese Automation Congress (CAC)
- DOI: 10.1109/cac51589.2020.9327332
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.1109/cac51589.2020.9327332

### 12. Hybrid Feature based Pyramid Network for Nighttime Semantic Segmentation

- Score: 0.5395
- Authors: Yuqi Li, Yinan Ma, Jing Wu, Chengnian Long
- Year / Venue: 2021 / Proceedings of the 16th International Joint Conference on Computer Vision, Imaging and Computer Graphics Theory and Applications
- DOI: 10.5220/0010248503210328
- Sources: crossref
- Citations: 2
- URL: https://doi.org/10.5220/0010248503210328

### 13. Mcanet: Feature Pyramid Network with Multi-Scale Convolutional Attention And Aggregation Mechanisms for Semantic Segmentation

- Score: 0.5124
- Authors: Shuo hu, XingWang Tao
- Year / Venue: 2024 / Unknown
- DOI: 10.2139/ssrn.5008171
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.2139/ssrn.5008171

### 14. Feature Pyramid Network with Multi-Scale Prediction Fusion for Real-Time Semantic Segmentation

- Score: 0.4924
- Authors: Min Young Kim, Toan Van Quyen
- Year / Venue: 2022 / Unknown
- DOI: 10.2139/ssrn.4179877
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.2139/ssrn.4179877

## Coverage Note

This report supports screening and does not guarantee exhaustive coverage. Final scholarly use requires human review.
