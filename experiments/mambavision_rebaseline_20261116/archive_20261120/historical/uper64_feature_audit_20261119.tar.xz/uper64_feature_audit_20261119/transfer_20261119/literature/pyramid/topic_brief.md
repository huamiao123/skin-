# 检索元数据索引

这些条目来自 pyramid 的 API 查询；标题、年份和 DOI 待逐项核实。已核实来源请看上一级 web_supplement.md。

- CFPNET: Channel-Wise Feature Pyramid For Real-Time Semantic Segmentation
- BLAST-NET: Semantic Segmentation of Human Blastocyst Components via Cascaded Atrous Pyramid and Dense Progressive Upsampling
- Efficient pyramid context encoding and feature embedding for semantic segmentation
- Semantic Segmentation of Fashion Images Using Feature Pyramid Networks
- Enhanced Feature Pyramid Network for Semantic Segmentation
- Cross-layer attentive feature upsampling for low-latency semantic segmentation
- Real-Time Semantic Edge Segmentation Using Modified Channelwise Feature Pyramid
- Depth-Aware Feature Pyramid Network for Semantic Segmentation
- Det2Seg: Detection-to-Segmentation Feature Alignment for Semi-Supervised Semantic Segmentation
- Spatial-frequency feature alignment network with multiscale pyramid fusion for remote sensing image semantic segmentation
- DFPNet:Dislocation Double Feature Pyramid Real-time Semantic Segmentation Network
- Hybrid Feature based Pyramid Network for Nighttime Semantic Segmentation
- Mcanet: Feature Pyramid Network with Multi-Scale Convolutional Attention And Aggregation Mechanisms for Semantic Segmentation
- Feature Pyramid Network with Multi-Scale Prediction Fusion for Real-Time Semantic Segmentation
