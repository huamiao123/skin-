# 检索元数据索引

这些条目来自 dermoscopy 的 API 查询；标题、年份和 DOI 待逐项核实。已核实来源请看上一级 web_supplement.md。

- Skin Lesion Segmentation in Dermoscopic Images with Combination of YOLO and GrabCut Algorithm
- Superpixel-Oriented Label Distribution Learning for Skin Lesion Segmentation
- Improved Skin Lesion Segmentation in Dermoscopic Images Using Object Detection and Semantic Segmentation
- Efficient Dermoscopic Lesion Segmentation via Multi-Directional State-Space Modeling and Frequency-Aware Boundary Refinement
- Dual-Architecture Neural Networks for Skin Cancer Lesion Segmentation: A Comparative Study of SingleNet and DoubleNet
- SRM-UNet: A Lightweight Structure-Region Guided Network with Multi-Receptive-Field Learning for Dermoscopic Skin Lesion Segmentation
- Illumination-based Transformations Improve Skin Lesion Segmentation in Dermoscopic Images
- Descriptor: ISIC Archive Multi-Annotator Dermoscopic Skin Lesion Segmentation Dataset (IMA++)
- IMPACT OF HAIR ARTIFACT REMOVAL ON SKIN LESION SEGMENTATION IN DERMOSCOPIC IMAGES
- Diagnosis-Stratified U-Net for Dermoscopic Lesion Segmentation: A Reproducible Baseline with Boundary-Aware Evaluation
- Automatic Lesion Segmentation Using Atrous Convolutional Deep Neural Networks in Dermoscopic Skin Cancer Images
- Skin lesion segmentation in dermoscopic images using CNN architecture
- HMP-MUNet: A Hybrid Deep Learning Framework for Automated Skin Lesion Segmentation in Dermoscopic Images
- Automated lesion segmentation and dermoscopic feature segmentation for skin cancer analysis
- Lesion Boundary Detection for Skin Lesion Segmentation Based on Boundary Sensing and Cnn-Transformer Fusion Networks
