# Scholarly Deep Research Retrieval Report

- Query: dermoscopic skin lesion segmentation boundary label noise
- Year range: 2016 to 2026
- Records after deduplication: 15
- Ranking: score = 0.40 * lexical_relevance + 0.20 * citation_score + 0.15 * recency_score + 0.10 * venue_source_confidence + 0.10 * open_access_score + 0.05 * metadata_completeness

## Ranked Papers

### 1. Skin Lesion Segmentation in Dermoscopic Images with Combination of YOLO and GrabCut Algorithm

- Score: 0.7386
- Authors: Halil Murat Ünver, Enes Ayan
- Year / Venue: 2019 / Diagnostics
- DOI: 10.3390/diagnostics9030072
- Sources: crossref
- Citations: 255
- URL: https://doi.org/10.3390/diagnostics9030072
- Abstract: Skin lesion segmentation has a critical role in the early and accurate diagnosis of skin cancer by computerized systems. However, automatic segmentation of skin lesions in dermoscopic images is a challenging task owing to difficulties including artifacts (hairs, gel bubbles, ruler markers), indistinct boundaries, low contrast and varying sizes and shapes of the lesion images. This paper proposes a novel and effective pipeline for skin lesion segmentation in dermoscopic images combining a deep convolutional neural network named as You Only Look Once (YOLO) and the GrabCut algorithm. This method performs lesion segmentation using a dermoscopic image in four steps: 1. Removal of hairs on the le

### 2. Superpixel-Oriented Label Distribution Learning for Skin Lesion Segmentation

- Score: 0.7088
- Authors: Qiaoer Zhou, Tingting He, Yuanwen Zou
- Year / Venue: 2022 / Diagnostics
- DOI: 10.3390/diagnostics12040938
- Sources: crossref
- Citations: 9
- URL: https://doi.org/10.3390/diagnostics12040938
- Abstract: Lesion segmentation is a critical task in skin cancer analysis and detection. When developing deep learning-based segmentation methods, we need a large number of human-annotated labels to serve as ground truth for model-supervised learning. Due to the complexity of dermatological images and the subjective differences of different dermatologists in decision-making, the labels in the segmentation target boundary region are prone to produce uncertain labels or error labels. These labels may lead to unsatisfactory performance of dermoscopy segmentation. In addition, the model trained by the errored one-hot label may be overconfident, which can lead to arbitrary prediction and model overfitting. 

### 3. Improved Skin Lesion Segmentation in Dermoscopic Images Using Object Detection and Semantic Segmentation

- Score: 0.6839
- Authors: Takashi Nagaoka
- Year / Venue: 2025 / Clinical, Cosmetic and Investigational Dermatology
- DOI: 10.2147/ccid.s518751
- Sources: crossref
- Citations: 12
- URL: https://doi.org/10.2147/ccid.s518751

### 4. Efficient Dermoscopic Lesion Segmentation via Multi-Directional State-Space Modeling and Frequency-Aware Boundary Refinement

- Score: 0.6657
- Authors: Zhengqi Liu, Lijun Xu
- Year / Venue: 2026 / Journal of Imaging
- DOI: 10.3390/jimaging12080339
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.3390/jimaging12080339
- Abstract: State-space models segment images in linear time, but existing dermoscopic segmenters serialize the two-dimensional feature map along only one or two scan directions and operate purely in the spatial domain, which dilutes the orientation cues and fine boundary information that distinguish a pigmented lesion from surrounding skin. We address both limitations in a single linear-complexity network, Hydra-DermSeg-Net, that unifies three components not previously combined for this task: a four-directional bidirectional Hydra block that aggregates forward and backward selective scans over horizontal, vertical and two diagonal trajectories with learnable fusion weights; a differentiable discrete co

### 5. Dual-Architecture Neural Networks for Skin Cancer Lesion Segmentation: A Comparative Study of SingleNet and DoubleNet

- Score: 0.6586
- Authors: Somashekar Reddy Kompall, Praneeth Agutla, Rahul Boga
- Year / Venue: 2026 / Unknown
- DOI: 10.31224/6635
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.31224/6635
- Abstract: Automated segmentation of skin cancer lesions plays a pivotal role in computer-aided dermatological diagnosis by assisting clinicians in identifying malignant regions at early stages, thereby improving treatment planning and patient survival rates. Accurate boundary delineation reduces inter-observer variability and enhances consistency in quantitative analysis, making deep learning–based segmentation systems increasingly valuable in clinical decision support environments. This paper presents a comprehensive study and practical implementation of two convolutional neural network architectures: SingleNet and DoubleNet. SingleNet serves as a structured encoder–decoder baseline framework designe

### 6. SRM-UNet: A Lightweight Structure-Region Guided Network with Multi-Receptive-Field Learning for Dermoscopic Skin Lesion Segmentation

- Score: 0.6586
- Authors: Shikai Zhang, Kaiyan Zhu, Yuhang Mao, Yuanbo Dai, et al.
- Year / Venue: 2026 / Unknown
- DOI: 10.21203/rs.3.rs-10142749/v1
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.21203/rs.3.rs-10142749/v1
- Abstract: Abstract Accurate skin lesion segmentation remains challenging because of blurred boundaries, low contrast, irregular lesion morphology, and interference from surrounding textures. This paper presents SRM-UNet, a lightweight structure-region guided network with multi-receptive-field learning for dermoscopic skin lesion segmentation. The central design of SRM-UNet is an explicit structure-region prior collaboration mechanism between the encoder and decoder. Specifically, the Structure-aware Local-Global Encoder (SLGE) performs stage-adaptive multi-receptive-field modeling and generates scale-matched structure priors that encode boundary, texture-transition, and shape-related cues. Prior-guide

### 7. Illumination-based Transformations Improve Skin Lesion Segmentation in Dermoscopic Images

- Score: 0.6339
- Authors: Abhishek Kumar, Ghassan Hamarneh, Mark S. Drew
- Year / Venue: 2020 / 2020 IEEE/CVF Conference on Computer Vision and Pattern Recognition Workshops (CVPRW)
- DOI: 10.1109/cvprw50498.2020.00372
- Sources: crossref
- Citations: 12
- URL: https://doi.org/10.1109/cvprw50498.2020.00372

### 8. Descriptor: ISIC Archive Multi-Annotator Dermoscopic Skin Lesion Segmentation Dataset (IMA++)

- Score: 0.6264
- Authors: Kumar Abhishek, Jeremy Kawahara, Ghassan Hamarneh
- Year / Venue: 2026 / IEEE Data Descriptions
- DOI: 10.1109/ieeedata.2026.3689801
- Sources: crossref
- Citations: 1
- URL: https://doi.org/10.1109/ieeedata.2026.3689801

### 9. IMPACT OF HAIR ARTIFACT REMOVAL ON SKIN LESION SEGMENTATION IN DERMOSCOPIC IMAGES

- Score: 0.5657
- Authors: Guzal Gulmirzaeva
- Year / Venue: 2026 / European Open Science Space
- DOI: 10.70286/eoss-26.10.2026.007.139-144
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.70286/eoss-26.10.2026.007.139-144
- Abstract: This study evaluates the effect of hair artifact removal on dermoscopic image segmentation. Original and hair -removed images were segmented under identical experimental conditions using the same SK-U-Net model. The results showed improvements in Dice, sensitivity, and overall segmentation accuracy, indicating that hair removal can enhance lesion boundary detection and segmentation reliability.

### 10. Diagnosis-Stratified U-Net for Dermoscopic Lesion Segmentation: A Reproducible Baseline with Boundary-Aware Evaluation

- Score: 0.5657
- Authors: B. Bhavya Sri, Vijay Kumar Burugari
- Year / Venue: 2026 / International Journal of Drug Delivery Technology
- DOI: 10.25258/ijddt.16.86s.126
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.25258/ijddt.16.86s.126
- Abstract: Background: Automated skin lesion segmentation is essential to computer-aided diagnosis, with existing approaches commonly neglecting boundary accuracy and performance variability based on morphology, which constrains clinical applications to surgical planning. Methods: We introduce a diagnosis-conscious U-Net model tested on the ISIC 2018 dataset (519 test images) with stratified partitioning to avoid diagnostic leakage. The pipeline uses error-graded augmentation and end-to-end assessment based on overlap measures (Dice, IoU), boundary-sensitive Hausdorff distance, and per-diagnosis assessment between melanoma, nevus, and seborrheic keratosis. A systematic comparison is made between baseli

### 11. Automatic Lesion Segmentation Using Atrous Convolutional Deep Neural Networks in Dermoscopic Skin Cancer Images

- Score: 0.5514
- Authors: Ranpreet Kaur, Hamid GholamHosseini, Roopak Sinha
- Year / Venue: 2021 / Unknown
- DOI: 10.21203/rs.3.rs-285138/v1
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.21203/rs.3.rs-285138/v1
- Abstract: Abstract Background : Among skin cancers, melanoma is the most dangerous and aggressive form, exhibiting a high mortality rate worldwide. Biopsy and histopatholog-ical analysis are common procedures for skin cancer detection and prevention in clinical settings. A significant step involved in the diagnosis process is the deep understanding of patterns, size, color, and structure of lesions based on images obtained through dermatoscopes for the infected area. However, the manual seg-mentation of the lesion region is time-consuming because the lesion evolves and changes its shape over time which makes its prediction challenging. Moreover, at the initial stage, it is difficult to predict melanom

### 12. Skin lesion segmentation in dermoscopic images using CNN architecture

- Score: 0.5514
- Authors: Chaitra Dayananda, Wonsang You, Jae Young Choi, Bumshik Lee
- Year / Venue: 2021 / 2021 International Conference on Information and Communication Technology Convergence (ICTC)
- DOI: 10.1109/ictc52510.2021.9621073
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.1109/ictc52510.2021.9621073

### 13. HMP-MUNet: A Hybrid Deep Learning Framework for Automated Skin Lesion Segmentation in Dermoscopic Images

- Score: 0.5014
- Authors: Dazhou Li, Chenyu Li, Wei Gao, Han Shi
- Year / Venue: 2026 / Journal of Visualized Experiments
- DOI: 10.3791/69449
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.3791/69449

### 14. Automated lesion segmentation and dermoscopic feature segmentation for skin cancer analysis

- Score: 0.5011
- Authors: Mansoureh Pezhman Pour, Huseyin Seker, Ling Shao
- Year / Venue: 2017 / 2017 39th Annual International Conference of the IEEE Engineering in Medicine and Biology Society (EMBC)
- DOI: 10.1109/embc.2017.8036906
- Sources: crossref
- Citations: 11
- URL: https://doi.org/10.1109/embc.2017.8036906

### 15. Lesion Boundary Detection for Skin Lesion Segmentation Based on Boundary Sensing and Cnn-Transformer Fusion Networks

- Score: 0.4743
- Authors: XuZhen Huang, Yuliang Ma, Xiajin Mei, Zizhuo Wu, et al.
- Year / Venue: 2024 / Unknown
- DOI: 10.2139/ssrn.4970410
- Sources: crossref
- Citations: 0
- URL: https://doi.org/10.2139/ssrn.4970410

## Coverage Note

This report supports screening and does not guarantee exhaustive coverage. Final scholarly use requires human review.
