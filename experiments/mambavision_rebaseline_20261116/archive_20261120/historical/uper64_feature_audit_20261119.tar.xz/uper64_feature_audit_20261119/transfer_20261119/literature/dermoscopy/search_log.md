# Search Log

- Timestamp: 2026-11-19T03:46:10.985684+00:00
- Query: dermoscopic skin lesion segmentation boundary label noise
- Year range: 2016 to 2026
- Requested limit per source: 15
- Sources: pubmed, crossref

## Source Counts

- crossref: 15
- pubmed: 0

- Total before deduplication: 15
- Total after deduplication: 15
- Ranking formula: score = 0.40 * lexical_relevance + 0.20 * citation_score + 0.15 * recency_score + 0.10 * venue_source_confidence + 0.10 * open_access_score + 0.05 * metadata_completeness
