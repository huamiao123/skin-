# Search Log

- Timestamp: 2026-11-19T03:46:10.983989+00:00
- Query: semantic segmentation feature alignment pyramid upsampling
- Year range: 2016 to 2026
- Requested limit per source: 15
- Sources: crossref

## Source Counts

- crossref: 15

- Total before deduplication: 15
- Total after deduplication: 14
- Ranking formula: score = 0.40 * lexical_relevance + 0.20 * citation_score + 0.15 * recency_score + 0.10 * venue_source_confidence + 0.10 * open_access_score + 0.05 * metadata_completeness

## Deduplication Notes

- Title duplicate: Cross-Layer Attentive Feature Upsampling for Low-latency Semantic Segmentation
