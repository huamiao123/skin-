# 补充核对来源

| 来源 | 资源类型 | 核对内容 |
|---|---|---|
| [Qian 等](https://arxiv.org/pdf/1809.03917) | 作者方法报告 | 预测框、训练框扰动及单阶段对照 |
| [CascadePSP 正文](https://openaccess.thecvf.com/content_CVPR_2020/papers/Cheng_CascadePSP_Toward_Class-Agnostic_and_Very_High-Resolution_Segmentation_via_Global_and_CVPR_2020_paper.pdf) · [作者代码](https://github.com/hkchengrex/CascadePSP/blob/master/segmentation-refinement/segmentation_refinement/eval_helper.py) | 论文与推理实现 | 局部窗、合并与边缘处理 |
| [HRDA](https://arxiv.org/abs/2204.13132) · [HRDAHead](https://github.com/lhoyer/HRDA/blob/master/mmseg/models/decode_heads/hrda_head.py) | 作者论文与代码 | 局部覆盖约束、尺度权重、可选辅助监督 |
| [Nagaoka 等](https://pmc.ncbi.nlm.nih.gov/articles/PMC12089257/) | 皮肤镜检测框提示研究 | 区分框提示与实际图像裁切 |
