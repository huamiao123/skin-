#!/bin/bash
set -eu
exec 9>/tmp/mambavision_s_hard_extent_20261119/recovery.lock
flock -n 9
orig=/home/featurize/work/mambavision_seg_rebaseline_20261116/uper64_feature_audit_20261119/transfer_20261119/hard_extent_s_20261119
run=/tmp/mambavision_s_hard_extent_20261119/run
mkdir -p "$run/uniform"
for name in mine.py fit.py initial.json mined.json folds.json fold_0.npz fold_1.npz fold_2.npz protocol.json mining_summary.json; do
  cp -n "$orig/$name" "$run/$name"
done
cp -n "$orig/uniform/best.pth" "$run/uniform/best.pth"
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8
cd "$run"
/home/waas/mambavision_stage22/env/bin/python -u /tmp/mambavision_s_hard_extent_20261119/driver.py >training.log 2>&1
for attempt in 1 2 3 4 5; do
 if rsync -a uniform targeted *_per_image.csv locked_before_test.json RESULTS.json training.log "$orig/"; then break; fi
 sleep 10
done
cd "$orig"
/home/waas/mambavision_stage22/env/bin/python sensitivity.py --score > sensitivity.log
