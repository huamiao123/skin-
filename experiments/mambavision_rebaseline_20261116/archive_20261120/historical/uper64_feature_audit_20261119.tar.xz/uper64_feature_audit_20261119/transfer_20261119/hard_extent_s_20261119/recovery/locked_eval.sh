#!/bin/bash
set -eu
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8
cd /tmp/mambavision_s_hard_extent_20261119/run
/home/waas/mambavision_stage22/env/bin/python -u /tmp/mambavision_s_hard_extent_20261119/locked_eval.py > locked_evaluation.log 2>&1
target=/home/featurize/work/mambavision_seg_rebaseline_20261116/uper64_feature_audit_20261119/transfer_20261119/hard_extent_s_20261119
for attempt in 1 2 3 4; do
    if rsync -a uniform targeted *_per_image.csv locked_before_test.json RESULTS.json training.log locked_evaluation.log "$target/"; then break; fi
    sleep 5
done
cd "$target"
/home/waas/mambavision_stage22/env/bin/python sensitivity.py --score > sensitivity.log
