#!/bin/bash
set -eu
cd "$(dirname "$0")"
exec 9>queue.lock
flock -n 9
while [ ! -e mined.json ]; do
    if ! pgrep -f '^/home/waas/mambavision_stage22/env/bin/python -u mine.py$' >/dev/null; then
        echo "Mining exited before completion"
        exit 1
    fi
    sleep 5
done
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8
PY=/home/waas/mambavision_stage22/env/bin/python
"$PY" -u fit.py > fit.log 2>&1
"$PY" -u evaluate.py > evaluation.log 2>&1
