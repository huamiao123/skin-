#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec 9>dysample_queue.lock
flock -n 9 || exit 1
phase=waiting_for_area_diagnostics
state() { printf '%s %s\n' "$(date -Is)" "$1" > dysample_state.txt; }
trap 'rc=$?; if [[ $rc != 0 ]]; then state "failed $phase rc=$rc"; fi' EXIT
state "$phase"
for ((n=0;n<300;n++)); do [[ -s transfer_cases.json ]] && break; sleep 3; done
[[ -s transfer_cases.json ]]
export PYTHONNOUSERSITE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
py=/home/waas/mambavision_stage22/env/bin/python
phase=preflight; state "$phase"; "$py" -u preflight_dysample.py
phase=train; state "$phase"; "$py" -u train_dysample.py dysample_f2_to_f1
phase=paired_evaluation; state "$phase"; "$py" -u post_dysample.py
state complete
