"""Select verified per-image recounts while preserving the original training logs."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
AUDIT = ROOT.parent / "uper64_feature_audit_20261119"


def validation_csv(arm):
    if arm in ("f3", "f4") and (AUDIT / "diagnostic_replay.json").is_file():
        corrected = AUDIT / f"{arm}_corrected_validation.csv"
        if corrected.is_file():
            return corrected
        import json
        if json.loads((AUDIT / "diagnostic_replay.json").read_text())["models"][arm]["changed_interior_rows"]:
            raise FileNotFoundError(corrected)
    return ROOT / arm / "best_validation.csv"
