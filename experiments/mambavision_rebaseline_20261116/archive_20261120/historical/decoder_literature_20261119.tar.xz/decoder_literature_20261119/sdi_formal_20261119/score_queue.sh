#!/bin/bash
set -eu
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8
out=/home/featurize/work/mambavision_seg_rebaseline_20261116/decoder_literature_20261119/sdi_formal_20261119
tmp=/tmp/mv_s_uper64_sdi_formal_20261119
exec 8>"$tmp/queue.lock"
flock -n 8
while [ ! -f "$tmp/fit_done.json" ]; do
    if ! pgrep -f '^/home/waas/mambavision_stage22/env/bin/python -u fit_sdi.py$' >/dev/null; then
       echo 'Training stopped before completion'
       exit 1
    fi
    sleep 8
done
cd "$out"
/home/waas/mambavision_stage22/env/bin/python -u score_sdi.py > "$tmp/testing.log" 2>&1
for attempt in 1 2 3 4; do
    if rsync -a --exclude='latest.pth' --exclude='*.lock' --exclude='*.tmp' "$tmp/" "$out/runs/"; then exit 0; fi
    sleep 6
done
exit 1
