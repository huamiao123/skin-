import sys, time, json
from pathlib import Path
from datetime import datetime
r=Path('/tmp/mv_sdi_shallow_bypass_20261119')
dur=Path('/home/featurize/work/mambavision_seg_rebaseline_20261116/decoder_literature_20261119/sdi_formal_20261119/shallow_bypass_20261119')
def status():
    arms={}
    for a in ['weak','global','shift','control']:
        h=r/a/'history.json'
        arms[a]=len(json.loads(h.read_text())) if h.exists() else 0
    scoring=(r/'score.log').read_text(errors='replace') if (r/'score.log').exists() else ''
    testing=[line for line in scoring.splitlines() if line.startswith(('scored ','verified','archived','Traceback','AssertionError','Fit exited'))]
    err=[]
    for f in ['train.log','score.log','dev.log']:
        loc=r/f
        if loc.exists() and 'Traceback (most recent call last)' in loc.read_text(errors='replace')[-4000:]:err.append(f)
    return dict(time=datetime.now().strftime('%H:%M:%S'),arms=arms,test=testing[-2:],diagnostic=(dur/'dev_gate_diagnosis.json').exists(),errors=err)
if __name__=='__main__':
    for n in range(2):
        print(json.dumps(status()),flush=True)
        if n==0 and sum(status()['arms'].values())<160:time.sleep(40)
