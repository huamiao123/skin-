#!/bin/bash
set -eu
cd '/home/featurize/work/mambavision_seg_rebaseline_20261116/decoder_literature_20261119/sdi_formal_20261119/shallow_bypass_20261119'
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8
scratch='/tmp/mv_sdi_shallow_bypass_20261119'
exec 9>"$scratch/scoring.lock"
flock -n 9 || exit 0
while ! test -s "$scratch/locked_for_test.json"; do
  if ! pgrep -f '[p]ython -u fit_bypass.py' >/dev/null; then
    echo 'Fit exited before the checkpoint lock'; exit 1
  fi
  sleep 15
done
if ! test -s "$scratch/RESULTS.json"; then
  /home/waas/mambavision_stage22/env/bin/python -u test_bypass.py
fi
mkdir -p runs
rsync -a --exclude='latest.pth' --exclude='*.tmp' --exclude='*.lock' "$scratch/" runs/
echo 'archived four weights and held-out results'
