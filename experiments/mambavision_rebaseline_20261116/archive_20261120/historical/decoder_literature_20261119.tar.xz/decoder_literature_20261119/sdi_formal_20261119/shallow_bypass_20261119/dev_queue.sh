#!/bin/bash
set -eu
cd '/home/featurize/work/mambavision_seg_rebaseline_20261116/decoder_literature_20261119/sdi_formal_20261119/shallow_bypass_20261119'
scratch='/tmp/mv_sdi_shallow_bypass_20261119'
exec 9>"$scratch/dev_diag.lock"
flock -n 9 || exit 0
while ! test -s "$scratch/RESULTS.json"; do
    if ! pgrep -f '[b]ash score_queue.sh' >/dev/null; then exit 1; fi
    sleep 10
done
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8
/home/waas/mambavision_stage22/env/bin/python -u dev_gate.py
