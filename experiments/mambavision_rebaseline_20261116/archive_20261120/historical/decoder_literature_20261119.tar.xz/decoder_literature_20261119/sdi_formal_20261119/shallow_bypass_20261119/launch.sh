#!/bin/bash
set -eu
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=8
cd /home/featurize/work/mambavision_seg_rebaseline_20261116/decoder_literature_20261119/sdi_formal_20261119/shallow_bypass_20261119
/home/waas/mambavision_stage22/env/bin/python -u fit_bypass.py > /tmp/mv_sdi_shallow_bypass_20261119/train.log 2>&1
