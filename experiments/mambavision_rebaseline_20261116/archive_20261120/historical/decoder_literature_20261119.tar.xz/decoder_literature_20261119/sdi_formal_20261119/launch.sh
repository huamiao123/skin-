#!/bin/bash
set -eu
export OMP_NUM_THREADS=8 CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONUNBUFFERED=1
cd /home/featurize/work/mambavision_seg_rebaseline_20261116/decoder_literature_20261119/sdi_formal_20261119
/home/waas/mambavision_stage22/env/bin/python -u fit_sdi.py >/tmp/mv_s_uper64_sdi_formal_20261119/train.log 2>&1
