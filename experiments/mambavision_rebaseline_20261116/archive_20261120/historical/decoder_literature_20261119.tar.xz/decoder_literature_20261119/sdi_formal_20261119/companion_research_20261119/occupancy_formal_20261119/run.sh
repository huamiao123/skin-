#!/bin/bash
set -eu
cd '/home/featurize/work/mambavision_seg_rebaseline_20261116/decoder_literature_20261119/sdi_formal_20261119/companion_research_20261119/occupancy_formal_20261119'
export OMP_NUM_THREADS=8 CUBLAS_WORKSPACE_CONFIG=:4096:8
p=/home/waas/mambavision_stage22/env/bin/python
"$p" -u fit.py > fit.log 2>&1
"$p" -u score.py > score.log 2>&1
