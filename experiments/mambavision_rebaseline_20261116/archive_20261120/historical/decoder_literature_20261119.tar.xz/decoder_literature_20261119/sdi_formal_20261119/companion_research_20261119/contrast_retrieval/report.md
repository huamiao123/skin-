# 医学分割中像素与区域的对比学习

接口返回 62 条去重记录。此索引用来筛选论文，包含领域外匹配项。方法解释与取舍见上一级的人工报告。

## 索引中排序靠前的条目

1. [Contrastive learning of global and local features for medical image segmentation with limited annotations](https://doi.org/10.3929/ethz-b-000443425) (2020)
2. [Local contrastive loss with pseudo-label based self-training for semi-supervised medical image segmentation](https://doi.org/10.1016/j.media.2023.102792) (2023)
3. [Uncertainty-Guided Pixel Contrastive Learning for Semi-Supervised Medical Image Segmentation](https://doi.org/10.24963/ijcai.2022/201) (2022)
4. [Semi-supervised Contrastive Learning for Label-Efficient Medical Image Segmentation](https://doi.org/10.1007/978-3-030-87196-3_45) (2021)
5. [Dynamic contrastive learning guided by class confidence and confusion degree for medical image segmentation](https://doi.org/10.1016/j.patcog.2023.109881) (2023)
6. [Exploring Cross-Image Pixel Contrast for Semantic Segmentation](https://doi.org/10.1109/iccv48922.2021.00721) (2021)
7. [Combining contrastive learning and shape awareness for semi-supervised medical image segmentation](https://doi.org/10.1016/j.eswa.2023.122567) (2023)
8. [Semi-Mamba-UNet: Pixel-level contrastive and cross-supervised visual Mamba-based UNet for semi-supervised medical image segmentation](https://doi.org/10.1016/j.knosys.2024.112203) (2024)
9. [SuperCL: Superpixel Guided Contrastive Learning for Medical Image Segmentation Pre-Training](https://doi.org/10.1109/tip.2026.3657233) (2026)
10. [Dense Self-Supervised Learning for Medical Image Segmentation](https://doi.org/10.48550/arxiv.2407.20395) (2024)
11. [Semantic-Aware Contrastive Learning for Multi-Object Medical Image Segmentation](https://doi.org/10.1109/jbhi.2023.3285230) (2023)
12. [Bootstrapping Semi-supervised Medical Image Segmentation with Anatomical-Aware Contrastive Distillation](https://doi.org/10.1007/978-3-031-34048-2_49) (2023)
