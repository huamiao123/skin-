from pathlib import Path
import json
root=Path(__file__).resolve().parent
for name,title in [('retrieval','图像分割的编码器旁路和多尺度特征'),('contrast_retrieval','医学分割中像素与区域的对比学习')]:
    directory=root/name;rows=json.loads((directory/'papers.json').read_text())
    note=['# '+title,'','接口返回 '+str(len(rows))+' 条去重记录。此索引用来筛选论文，包含领域外匹配项。方法解释与取舍见上一级的人工报告。','','## 索引中排序靠前的条目','']
    for i,x in enumerate(rows[:12],1):
        link=x.get('url') or x.get('open_access_url') or ('https://doi.org/'+x['doi'] if x.get('doi') else '')
        note.append(str(i)+'. '+('['+x['title']+']('+link+')' if link else x['title'])+' ('+str(x.get('year'))+')')
    for f in ['topic_brief.md','report.md']:
        (directory/f).write_text('\n'.join(note)+'\n')
