# Search Log

- Timestamp: 2026-11-19T09:41:28.972788+00:00
- Query: spatial prior adapter image segmentation multiscale high resolution semantic segmentation
- Year range: 2018 to 2026
- Requested limit per source: 24
- Sources: openalex, crossref, semanticscholar

## Source Counts

- openalex: 24
- semanticscholar: 0
- crossref: 24

- Total before deduplication: 48
- Total after deduplication: 31
- Ranking formula: score = 0.40 * lexical_relevance + 0.20 * citation_score + 0.15 * recency_score + 0.10 * venue_source_confidence + 0.10 * open_access_score + 0.05 * metadata_completeness

## Deduplication Notes

- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Review for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Decision letter for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Decision letter for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Decision letter for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"
- Title duplicate: Identifying Southern Pine Beetle Damage in High Spatial Resolution Drone Imagery Using Multiscale Image Segmentation and
- Title duplicate: Author response for "Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation"

## Errors

- semanticscholar: HTTPError: HTTP Error 429: 
