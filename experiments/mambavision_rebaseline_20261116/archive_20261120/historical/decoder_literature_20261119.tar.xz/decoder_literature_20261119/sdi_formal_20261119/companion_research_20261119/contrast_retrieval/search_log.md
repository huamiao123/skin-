# Search Log

- Timestamp: 2026-11-19T09:43:31.319617+00:00
- Query: contrastive learning pixel medical image segmentation
- Year range: 2019 to 2026
- Requested limit per source: 24
- Sources: openalex, crossref, pubmed

## Source Counts

- openalex: 24
- crossref: 24
- pubmed: 24

- Total before deduplication: 72
- Total after deduplication: 62
- Ranking formula: score = 0.40 * lexical_relevance + 0.20 * citation_score + 0.15 * recency_score + 0.10 * venue_source_confidence + 0.10 * open_access_score + 0.05 * metadata_completeness

## Deduplication Notes

- DOI duplicate: 10.1007/s11042-023-16611-3
- DOI duplicate: 10.24963/ijcai.2022/201
- DOI duplicate: 10.1109/isbi61048.2026.11515841
- Title duplicate: Combining Contrastive Learning and Shape Awareness for Semi-Supervised Medical Image Segmentation
- DOI duplicate: 10.1016/j.media.2022.102564
- DOI duplicate: 10.1109/icipai70034.2026.11605674
- DOI duplicate: 10.1109/bibm62325.2024.10822626
- DOI duplicate: 10.1007/978-3-031-25825-1_36
- DOI duplicate: 10.1016/j.knosys.2024.112203
- Title duplicate: Entropy‐guided contrastive learning for semi‐supervised medical image segmentation
