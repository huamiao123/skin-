# 图像分割的编码器旁路和多尺度特征

接口返回 31 条去重记录。此索引用来筛选论文，包含领域外匹配项。方法解释与取舍见上一级的人工报告。

## 索引中排序靠前的条目

1. [A Unified Framework With Multimodal Fine-Tuning for Remote Sensing Semantic Segmentation](https://doi.org/10.1109/tgrs.2025.3585238) (2025)
2. [Building Extraction from High Spatial Resolution Remote Sensing Images via Multiscale-Aware and Segmentation-Prior Conditional Random Fields](https://doi.org/10.3390/rs12233983) (2020)
3. [Hyperspectral Adapter for Semantic Segmentation With Vision Foundation Models](https://doi.org/10.1109/lra.2026.3656795) (2026)
4. [Open-Vocabulary High-Resolution Remote Sensing Image Semantic Segmentation](https://doi.org/10.1109/tgrs.2025.3559557) (2025)
5. [Spatial Frequency Modulation for Semantic Segmentation](https://doi.org/10.1109/tpami.2025.3592621) (2025)
6. [Open-Vocabulary Semantic Segmentation with Image Embedding Balancing](https://doi.org/10.1109/cvpr52733.2024.02684) (2024)
7. [Transformer-Based Visual Segmentation: A Survey](https://doi.org/10.1109/tpami.2024.3434373) (2024)
8. [ACTNet: A Dual-Attention Adapter with a CNN-Transformer Network for the Semantic Segmentation of Remote Sensing Imagery](https://doi.org/10.3390/rs15092363) (2023)
9. [Your ViT is Secretly an Image Segmentation Model](https://doi.org/10.1109/cvpr52734.2025.02356) (2025)
10. [SAM2-UNet: segment anything 2 makes strong encoder for natural and medical image segmentation](https://doi.org/10.1007/s44267-025-00106-w) (2026)
11. [Image Segmentation in Foundation Model Era: A Survey](https://doi.org/10.48550/arxiv.2408.12957) (2024)
12. [Generalization Boosted Adapter for Open-Vocabulary Segmentation](https://doi.org/10.1109/tcsvt.2024.3454227) (2024)
