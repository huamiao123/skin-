import hashlib,json,pathlib,urllib.request
root=pathlib.Path(__file__).resolve().parent
dest=root/'authors';dest.mkdir(exist_ok=True)
projects={'contrast':'tfzhou/ContrastiveSeg','reco':'lorenmt/reco','sapa':'poppinace/sapa','adapter':'czczup/ViT-Adapter','uv2':'yaoppeng/U-Net_v2'}
def fetch(url):
    req=urllib.request.Request(url,headers={'User-Agent':'academic-source-audit'})
    return urllib.request.urlopen(req,timeout=12).read()
def read_json(url):return json.loads(fetch(url))
sources={}
from concurrent.futures import ThreadPoolExecutor
def get(pair):
    name,repo=pair
    try:
        info=read_json('https://api.github.com/repos/'+repo)
        sha=read_json('https://api.github.com/repos/'+repo+'/commits/'+info['default_branch'])['sha']
        tree=[f['path'] for f in read_json('https://api.github.com/repos/'+repo+'/git/trees/'+sha+'?recursive=1')['tree'] if f['path'].endswith('.py')]
        if name=='contrast': paths=[p for p in tree if p.endswith(('loss_contrast.py','seg_hrnet_contrast.py','projection.py'))]
        if name=='reco': paths=[p for p in tree if p.endswith(('reco.py','trainer.py','train_semisupervised.py','model.py'))][:6]
        if name=='sapa': paths=[p for p in tree if p.endswith(('sapa.py','sapa_module.py')) or ('sapa' in p.lower() and 'module' in p.lower())][:5]
        if name=='adapter':paths=[p for p in tree if p.startswith('segmentation/') and p.endswith(('vit_adapter.py','adapter_modules.py'))][:3]
        if name=='uv2':paths=[p for p in tree if p=='PolypSeg/unet_v2/UNet_v2.py']
        receipts=[]
        for p in paths:
            blob=fetch('https://raw.githubusercontent.com/'+repo+'/'+sha+'/'+p)
            out=dest/(name+'__'+p.replace('/','_'));out.write_bytes(blob)
            receipts.append(dict(path=p,local=out.name,hash=hashlib.sha256(blob).hexdigest(),url='https://github.com/'+repo+'/blob/'+sha+'/'+p))
        return name,dict(repo=repo,sha=sha,files=receipts,tree_sample=[p for p in tree if p.count('/')<3][:45] if not paths else [])
    except Exception as e:return name,dict(repo=repo,error=str(e))
with ThreadPoolExecutor(5) as pool:sources=dict(pool.map(get,projects.items()))
(root/'source_manifest.json').write_text(json.dumps(sources,indent=2))
for k,r in sources.items():print(k,r.get('sha'),[p['path'] for p in r.get('files',[])],r.get('error',''),r.get('tree_sample',[])[:18])
