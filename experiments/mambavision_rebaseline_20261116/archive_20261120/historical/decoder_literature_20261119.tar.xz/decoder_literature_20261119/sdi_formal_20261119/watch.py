import json,sys,time
from pathlib import Path
tmp=Path('/tmp/mv_s_uper64_sdi_formal_20261119')
def terminal():
    if (tmp/'result.json').is_file():return 'RESULT_READY'
    for name in ('train.log','testing.log','queue.log'):
        path=tmp/name
        if path.exists():
            with path.open('rb') as f:
                f.seek(max(0,path.stat().st_size-3000))
                tail=f.read().decode(errors='replace')
            if 'Traceback (most recent call last):' in tail or 'Training stopped before completion' in tail:
                return 'ERROR '+name+' '+tail.splitlines()[-1]
    return ''
end=time.monotonic()+min(47,int(sys.argv[1]))
while time.monotonic()<end and not terminal():
    time.sleep(min(4,max(0,end-time.monotonic())))
for name in ('product_42','mean_42','add_43','mean_43','product_43'):
    hist=tmp/name/'history.json'
    if hist.is_file():
        h=json.load(hist.open());b=max(h,key=lambda r:r['val_macro_dice'])
        print(name,len(h),round(b['val_macro_dice'],6),'@',b['epoch'],h[-1]['seconds'])
print(terminal(),flush=True)
