# 医学图像分割 decoder 检索简报

以 2018–2026 为年份范围，OpenAlex、Crossref 返回 70 条原始记录，去重后 61 条。语料中可直接定位 EMCAD、G-CASCADE、CASCADE、MIST 等工作。具体接入依据、第三方来源与实验限制见上一级 deep_research_report.md 和 web_supplement.md。文件 papers.json 与 search_log.md 保留 API 原始结果和检索参数。
