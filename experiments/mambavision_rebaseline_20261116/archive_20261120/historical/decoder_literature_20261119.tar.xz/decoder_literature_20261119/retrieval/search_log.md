# Search Log

- Timestamp: 2026-11-19T07:47:16.691058+00:00
- Query: medical image segmentation decoder
- Year range: 2018 to 2026
- Requested limit per source: 35
- Sources: openalex, crossref

## Source Counts

- openalex: 35
- crossref: 35

- Total before deduplication: 70
- Total after deduplication: 61
- Ranking formula: score = 0.40 * lexical_relevance + 0.20 * citation_score + 0.15 * recency_score + 0.10 * venue_source_confidence + 0.10 * open_access_score + 0.05 * metadata_completeness

## Deduplication Notes

- DOI duplicate: 10.1109/icip42928.2021.9506463
- DOI duplicate: 10.1109/prmvai65741.2025.11108450
- DOI duplicate: 10.1117/12.2542199
- DOI duplicate: 10.1109/icassp49660.2025.10889260
- DOI duplicate: 10.1016/j.patcog.2026.113198
- DOI duplicate: 10.1109/wacv57701.2024.00047
- DOI duplicate: 10.1109/bibm58861.2023.10385407
- DOI duplicate: 10.1049/sil2.12114
- Title duplicate: GIVTED-Net: GhostNet-Mobile Involution ViT Encoder-Decoder Network for Lightweight Medical Image Segmentation
