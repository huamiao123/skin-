#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
while kill -0 75306 2>/dev/null && [[ ! -f test_result.json ]]; do sleep 12; done
[[ -s test_result.json ]]
exec env OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 PYTHONNOUSERSITE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8 /home/waas/mambavision_stage22/env/bin/python -u read_branches.py
