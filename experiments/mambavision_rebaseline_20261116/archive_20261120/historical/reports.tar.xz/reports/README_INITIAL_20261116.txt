# MambaVision segmentation Stage A

Independent server workspace for a CPU-audited native UPerNet adaptation. Read `SOURCE_AUDIT.md`, `PROTOCOL.md`, and `reports/cpu_tests.log`. Three arms and the historical encoder adapter are implemented in `src/model.py`; `src/preflight_gpu.py` is a proposed synthetic preflight and was initially CPU-tested and subsequently passed on the new RTX 3090 instance. No formal training runner or formal results are provided yet.

CPU tests (no GPU):

```bash
cd /home/featurize/work/mambavision_seg_rebaseline_20261116
PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=8 /home/waas/mambavision_stage22/env/bin/python -m unittest discover -s tests -v
```

Old Stage 1–51 code, results, logs and retained checkpoints are never written by this workspace. This is a local research adapter, not a reproduction of the ADE20K recipe.

2026-11-16: A new RTX 3090 instance has passed the three synthetic GPU preflights, and the development images/masks have been restored and hash checked. `src/smoke_train.py` is a CPU-tested, two-epoch validation-only smoke runner; real-data execution requires explicit authorization. There is still no formal training runner.
