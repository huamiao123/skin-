# Search Log

- Timestamp: 2026-11-19T15:24:37.697706+00:00
- Query: skin lesion segmentation
- Year range: 2018 to 2026
- Requested limit per source: 45
- Sources: crossref, pubmed

## Source Counts

- crossref: 45
- pubmed: 45

- Total before deduplication: 90
- Total after deduplication: 89
- Ranking formula: score = 0.40 * lexical_relevance + 0.20 * citation_score + 0.15 * recency_score + 0.10 * venue_source_confidence + 0.10 * open_access_score + 0.05 * metadata_completeness

## Deduplication Notes

- Title duplicate: Skin Lesion Segmentation Techniques for Melanoma Diagnosis: Comparative Studies
