# MambaVision-S + UPer64 在四个皮肤病灶分割数据集上的基线强度

2026-11-19。项目分数均为验证集选出的最佳权重在固定测试集上的逐图前景 Dice。各数据集分别从 ImageNet 预训练权重微调。

## 结论

可以把该配置作为研究中的强基线。HAM10000 上，它与常见有监督分割网络处在相近的高分区，并在同配置下抵住了两种解码器改动。PH² 的域内得分接近已发表的较高结果。ISIC2018 仍有可测的困难病例。Waterloo 的域内测试规模及公开协议差异限制了方法排名。

## 文献与实验对应

| 数据集 | 本项目 | 外部结果及可比性 |
|---|---:|---|
| ISIC2018 | 89.8869%，867 张 | 同骨干 HMT-UNet 89.73%；L2S 90.97%；2D D-LKA Net 91.77%；SkinFormer 93.2 ± 0.3%。L2S 使用五折交叉验证，SkinFormer 在官方 2,594 张训练图上交叉验证。[HMT-UNet，表 3、表 6](https://arxiv.org/html/2408.11289v1) · [L2S，CVPR 2025，表 1](https://openaccess.thecvf.com/content/CVPR2025/papers/Guo_Take_the_Bull_by_the_Horns_Learning_to_Segment_Hard_CVPR_2025_paper.pdf) · [2D D-LKA Net，WACV 2024，表 2](https://openaccess.thecvf.com/content/WACV2024/papers/Azad_Beyond_Self-Attention_Deformable_Large_Kernel_Attention_for_Medical_Image_Segmentation_WACV_2024_paper.pdf) · [SkinFormer，表 IV](https://arxiv.org/pdf/2409.08652) |
| HAM10000 | 94.6961%，1,001 张 | 独立研究在同一留出折测得 U-Net 94.02%、SegFormer-B2 94.16%。CVPR 的 MambaLiteUNet 为 95.16%，公开测试代码采用全像素合并的 Dice。[HAM10000 无提示分割对照，表 5](https://pmc.ncbi.nlm.nih.gov/articles/PMC13666333/) · [MambaLiteUNet，CVPR 2026，表 1、表 2](https://arxiv.org/html/2604.20286v1) · [MambaLiteUNet 测试代码](https://github.com/maklachur/MambaLiteUNet/blob/main/engine.py#L138-L153) |
| PH² | 95.4676%，40 张 | D-LKA 94.90%；VML-UNet 95.64%（170/30）；MambaLiteUNet 93.92%（140/20/40）。本项目为 120/40/40。[2D D-LKA Net，WACV 2024，表 2](https://openaccess.thecvf.com/content/WACV2024/papers/Azad_Beyond_Self-Attention_Deformable_Large_Kernel_Attention_for_Medical_Image_Segmentation_WACV_2024_paper.pdf) · [VML-UNet，实验设置与表 1](https://www.mdpi.com/2079-9292/14/14/2866) · [MambaLiteUNet，CVPR 2026，表 1、表 2](https://arxiv.org/html/2604.20286v1) |
| Waterloo | 92.9444%，41 张，34 个已知分组 | MacroE-Net + DAttUNet 作者稿为 88.8%。EM-Net 为 90.03%，训练源为 ISIC2016，Waterloo 6 张用于域泛化、200 张用于测试。两者与本项目的实验条件不同。[MacroE-Net 作者稿，表 V](https://d197for5662m48.cloudfront.net/documents/publicationstatus/258095/preprint_pdf/d7d23c9ea95cd83037831c3f63e32b63.pdf) · [EM-Net 作者结果表](https://bean-young.github.io/emnet/) · [EM-Net 划分说明](https://github.com/Bean-Young/EM-Net) |

MambaVision-S 是已有官方语义分割适配的层次化骨干。当前 UPer64 使用金字塔池化和多尺度融合；项目采用 256 像素输入、16/8 编码器窗口并微调 Stage 3/4。HMT-UNet 在论文内控制初始化，ISIC2018 的 84.60% 提升至 89.73%，表明预训练本身有潜在贡献。该差值仅适用于作者实验。[MambaVision 官方语义分割配置](https://github.com/NVlabs/MambaVision/tree/main/semantic_segmentation) · [HMT-UNet，表 3、表 6](https://arxiv.org/html/2408.11289v1)

## 同划分的实验事实

- HAM10000 的 UPer64、SDI 弱训练、Swin + LocalFusion 依次为 94.6961%、94.6692%、94.6254%。相对基线差值 −0.0269 和 −0.0707 个百分点。对测试集 746 个记录在案的病灶 ID 做 8,000 次配对重采样，区间分别为 [−0.2693, +0.2195] 和 [−0.2741, +0.1110] 个百分点。这些区间只表示这组训练权重的测试样本不确定性。
- HAM10000 的公开近重复清单中有 3 对跨训练和测试、2 对跨训练和验证。剔除关联的 4 张测试图，基线在 997 张上的均值为 94.6986%。修正式分组仍需在重训前合并相关病灶。[HAM10000 重复图像审计](https://derm.cs.sfu.ca/critique/)
- 旧轮次同 40 张 PH² 图片，历史 ISIC 权重直接测试为 92.6647%，在 PH² 训练的旧基线为 95.6028%。Waterloo 同样 41 张上，历史权重直接测试为 90.4058%，在 Waterloo 训练的旧基线为 93.9137%。这些历史对照说明域内训练与跨域应用应分别解读，数值不能代替本轮 16/8 结果。
- 本轮 ISIC2018 有 78/867 张 Dice 低于 0.80。HAM10000 为 35/1,001，PH² 为 0/40，Waterloo 为 2/41。0.80 是描述低分病例的阈值。
- 项目评估文件位于 `four_dataset_matched_20261119` 和 `ham10000_window16_20g_20261119`。历史迁移对照在 `uper64_feature_audit_20261119/transfer_20261119/target_training_20261119/same_test_ids_historical_scores.json`。

## 可复核性与证据边界

2026-11-19 以 skin lesion segmentation 检索 Crossref、PubMed，两库各返回 45 条，初步去重 89 条。分数仅使用逐项核对的原论文、作者代码及项目评分记录。网页补检覆盖四个数据集名称和 DermIS/DermQuest 等别称。分数受训练集、目标域训练与否、测试清单、预训练、Dice 汇总方式及随机种子影响。ISIC 官方榜另有评分规则。[ISIC 2018 Task 1 官方评测](https://challenge.isic-archive.com/landing/2018/45/) · [MambaLiteUNet 的 ISIC2018 划分代码](https://github.com/maklachur/MambaLiteUNet/blob/main/dataprepare/prepare_ISIC2018.py#L45-L53)

建议把 UPer64 保留为主消融基线，外部方法优先选择 MambaLiteUNet，在同一划分上训练并按逐图 Dice 评测。方法比较前锁定选模规则；长期反复查看过的测试集可在论文中披露，最终用预先锁定的新评估补充。