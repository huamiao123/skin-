from pathlib import Path
import ast,copy,json,torch
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'src/train_stageB_enclr.py').read_text()
node=next(n for n in ast.parse(s).body if getattr(n,'name',None)=='make_optimizer')
scope={'torch':torch};exec(compile(ast.Module(body=[node],type_ignores=[]),'optimizer','exec'),scope)
class Tiny(torch.nn.Module):
 def __init__(self):
  super().__init__();self.probe=torch.nn.Linear(3,2);self.encoder=torch.nn.Linear(3,3)
for head_lr in [.001,.0003]:
 torch.manual_seed(42);a=Tiny();b=copy.deepcopy(a);initial={k:p.detach().clone() for k,p in a.named_parameters()}
 oa=torch.optim.AdamW([dict(params=list(a.probe.parameters()),lr=head_lr,initial_lr=head_lr,name='decoder'),
  dict(params=list(a.encoder.parameters()),lr=.0001,initial_lr=.0001,name='encoder')],
  weight_decay=.01,betas=(.9,.999),eps=1e-8)
 ob=scope['make_optimizer'](b,head_lr)
 assert [g['lr'] for g in ob.param_groups]==[head_lr,.00003]
 for ga,gb in zip(oa.param_groups,ob.param_groups):
  for k in set(ga)-{'params','lr','initial_lr'}:assert ga[k]==gb[k]
 for (name,p),(name2,q) in zip(a.named_parameters(),b.named_parameters()):
  assert name==name2
  grad=torch.arange(p.numel()).reshape(p.shape).float()/max(p.numel(),1)+.1
  p.grad=grad.clone();q.grad=grad.clone()
 for opt in [oa,ob]:
  for group in opt.param_groups:torch.nn.utils.clip_grad_norm_(group['params'],1.)
  opt.step()
 for (name,p),(name2,q) in zip(a.named_parameters(),b.named_parameters()):
  if name.startswith('probe'):assert torch.equal(p,q),name
  else:torch.testing.assert_close(q-initial[name],.3*(p-initial[name]),atol=4e-8,rtol=1e-3)
report=dict(passed=True,both_head_lr_branches_checked=True,decoder_updates_exact=True,encoder_update_ratio=.3,other_options_same=True)
(ROOT/'reports/STAGEB_ENCLR_CPU_TESTS.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
