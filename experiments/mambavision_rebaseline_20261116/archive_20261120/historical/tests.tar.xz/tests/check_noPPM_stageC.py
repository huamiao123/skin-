from pathlib import Path
import sys,copy,json
import torch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from model import NativeHeads,objective
from ablation_ppm import remove_ppm,EmptyPPM
torch.set_num_threads(8);torch.manual_seed(42)
full=NativeHeads('C-512-aux',42).eval()
changed=copy.deepcopy(full)
rng=torch.get_rng_state().clone()
remove_ppm(changed.decode_head)
assert torch.equal(rng,torch.get_rng_state()),'ablation construction consumed training RNG'
old=full.state_dict();new=changed.state_dict()
common=0
for k,v in new.items():
 if k.endswith('decode_head.bottleneck.conv.weight'):
  assert torch.equal(v,old[k][:,:768])
 else:
  assert torch.equal(v,old[k]),k
  common+=1
assert not any('psp_modules.' in k for k in new)
assert sum(p.numel() for p in changed.parameters())<sum(p.numel() for p in full.parameters())
features=[torch.randn(2,c,s,s,requires_grad=True) for c,s in zip([96,192,384,768],[16,8,4,2])]
handle=full.decode_head.psp_modules.register_forward_hook(lambda m,i,o:[torch.zeros_like(v) for v in o])
with torch.no_grad():
 expected=full(features,(64,64))['main'];actual=changed(features,(64,64))['main']
handle.remove()
assert torch.allclose(actual,expected,atol=2e-5,rtol=2e-5),float((actual-expected).abs().max())
changed.train();out=changed(features,(64,64));assert set(out)=={'main','aux'}
target=torch.randint(0,2,(2,1,64,64)).float();loss,terms=objective(out,target);loss.backward()
assert all(x.grad is not None and torch.isfinite(x.grad).all() for x in features)
assert changed.decode_head.bottleneck.conv.weight.grad.abs().sum()>0
assert changed.auxiliary_head.conv_seg.weight.grad.abs().sum()>0
assert all(p.grad is None or torch.isfinite(p.grad).all() for p in changed.parameters())
report=dict(passed=True,common_tensors_exact=common,raw_f4_columns_preserved=True,auxiliary_head_unchanged=True,global_rng_preserved=True,zero_PPM_equivalence_max_abs=float((actual-expected).abs().max()),native_head_parameters=sum(p.numel() for p in full.parameters()),noPPM_head_parameters=sum(p.numel() for p in changed.parameters()),all_four_feature_gradients_finite=True,auxiliary_gradient_verified=True,limitation='Removing PPM also removes parameters; this ablation does not isolate pooling from capacity.')
(ROOT/'reports/STAGEC_NOPPM_CPU_TESTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
