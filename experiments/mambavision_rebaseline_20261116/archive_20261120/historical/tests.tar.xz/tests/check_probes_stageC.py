from pathlib import Path
import sys,copy,json
import torch,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from probes_stageC_core import *
from train_mb64 import base
from stage1_visual.analyze import metrics
torch.set_num_threads(8);torch.manual_seed(42);rng=torch.get_rng_state().clone()
heads=make_heads();assert torch.equal(rng,torch.get_rng_state())
for level in range(1,5):
 a=heads[f'f{level}_linear32'];b=heads[f'f{level}_nonlinear32']
 assert sum(p.numel() for p in a.parameters())==sum(p.numel() for p in b.parameters())
 base.assert_tree_exact(a.state_dict(),b.state_dict())
seen=set()
for name,head in heads.items():
 for p in head.parameters():assert id(p) not in seen;seen.add(id(p))
features=[torch.randn(2,c,s,s) for c,s in zip(CHANNELS,[16,8,4,2])]
target=torch.rand(2,1,64,64)
original=copy.deepcopy(heads);joint=make_optimizer(heads)
losses,norms=step_heads(heads,joint,features,target)
for spec in SPECS:
 key=spec['key'];head=original[key]
 opt=torch.optim.AdamW(head.parameters(),lr=1e-3,weight_decay=.01,betas=(.9,.999),eps=1e-8)
 opt.zero_grad();loss=segmentation_loss(head(features[spec['level']],(64,64)),target);loss.backward()
 torch.nn.utils.clip_grad_norm_(head.parameters(),1.);opt.step()
 for k,v in head.state_dict().items():assert torch.equal(v,heads[key].state_dict()[k]),(key,k)
for predval,gtval in [(False,False),(False,True),(True,False),(True,True)]:
 logit=torch.full((2,1,8,8),20. if predval else -20.)
 gt=torch.full((2,1,8,8),float(gtval))
 scores=image_scores(logit,gt)
 exp=metrics(np.full((8,8),predval),np.full((8,8),gtval))
 assert abs(float(scores['dice'][0])-exp['dice'])<1e-12
 for k in ['tp','fp','fn','tn']:assert int(scores[k][0])==exp[k]
for c,level in zip(CHANNELS,range(1,5)):
 assert sum(p.numel() for p in heads[f'f{level}_direct'].parameters())==c+1
 assert sum(p.numel() for p in heads[f'f{level}_linear32'].parameters())==32*c+33
snapshot=base.cpu_tree(heads.state_dict());opt_snapshot=base.cpu_tree(joint.state_dict())
step_heads(heads,joint,features,target);heads.load_state_dict(snapshot);joint.load_state_dict(opt_snapshot)
base.assert_tree_exact(heads.state_dict(),snapshot);base.assert_tree_exact(joint.state_dict(),opt_snapshot)
x=torch.zeros(1,3,7,7);y=torch.zeros(1,1,7,7)
x[:,:,1,4]=.3;y[:,:,1,4]=.3
for view in range(6):
 xx,yy=apply_view(x,view),apply_view(y,view)
 assert torch.equal(xx[:,0:1],yy)
 assert torch.equal(torch.unique(y),torch.unique(yy))
z=torch.randn(2,3,7,7)
for v,inverse in [(0,0),(1,1),(2,2),(3,5),(4,4),(5,3)]:assert torch.equal(apply_view(apply_view(z,v),inverse),z)
cache=dict(ids=['0','1','2'],features=[torch.randn(3,c,s,s) for c,s in zip(CHANNELS,[16,8,4,2])],target=torch.rand(3,1,64,64))
values=validate(heads,cache)
with torch.no_grad():
 for s in SPECS:
  logits=heads[s['key']](cache['features'][s['level']],(64,64))
  assert abs(values[s['key']]['macro_dice']-float(image_scores(logits,cache['target'])['dice'].mean()))<1e-12
  assert abs(values[s['key']]['loss']-float(segmentation_loss(logits,cache['target'])))<1e-6
r=dict(passed=True,heads=12,six_views_image_mask_alignment_exact=True,paired_initialization_exact=True,paired_parameter_counts_exact=True,all_head_parameters_disjoint=True,joint_vs_independent_updates_bitwise_equal=True,empty_foreground_metric_contract_verified=True,model_optimizer_restore_exact=True,global_init_rng_preserved=True,parameter_counts={k:sum(p.numel() for p in v.parameters()) for k,v in heads.items()},note='Per-layer linear32/nonlinear32 budgets match. Parameter counts differ across encoder channel dimensions; low probe scores do not prove absent information.')
(ROOT/'reports/STAGEC_PROBES_CPU_TESTS.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r),flush=True)
