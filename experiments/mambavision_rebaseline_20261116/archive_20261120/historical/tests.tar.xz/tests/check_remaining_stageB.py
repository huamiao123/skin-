from pathlib import Path
import sys,json,copy
import torch
from torch import nn
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from remaining_stageB import VARIANTS,build_system,make_optimizer
from model import SegmentationSystem
from train_mb64 import base
torch.set_num_threads(8);torch.manual_seed(42)
class TinyEncoder(nn.Module):
 def __init__(self):
  super().__init__();self.model=nn.Module()
  self.model.patch_embed=nn.Linear(3,3)
  self.model.levels=nn.ModuleList([nn.Linear(3,3) for _ in range(4)])
template=TinyEncoder()
reference=SegmentationSystem(copy.deepcopy(template),'A-64-noaux',42)
results={}
for arm,spec in VARIANTS.items():
 model=build_system(copy.deepcopy(template),arm,42)
 base.assert_tree_exact(model.state_dict(),reference.state_dict())
 assert not model.encoder.training and model.probe.training
 assert model.probe.auxiliary_head is None
 expected=(2,3) if spec['tune']=='late' else (3,) if spec['tune']=='stage4' else ()
 for i,level in enumerate(model.encoder.model.levels):assert all(p.requires_grad==(i in expected) for p in level.parameters())
 assert not any(p.requires_grad for p in model.encoder.model.patch_embed.parameters())
 opt=make_optimizer(model,arm)
 actual={id(p) for g in opt.param_groups for p in g['params']}
 assert actual=={id(p) for p in model.parameters() if p.requires_grad}
 assert all(g['weight_decay']==spec['weight_decay'] for g in opt.param_groups)
 if spec['tune']=='frozen':assert [g['name'] for g in opt.param_groups]==['decoder']
 else:assert [g['name'] for g in opt.param_groups]==['decoder','encoder']
 before=base.cpu_tree(model.state_dict())
 loss=sum(p.square().sum() for p in model.parameters() if p.requires_grad)
 opt.zero_grad();loss.backward();opt.step()
 for name,p in model.named_parameters():
  if not p.requires_grad:assert p.grad is None and torch.equal(p.detach(),before[name])
 for i in expected:
  assert any(not torch.equal(p.detach(),before['encoder.model.levels.'+str(i)+'.'+name]) for name,p in model.encoder.model.levels[i].named_parameters())
 results[arm]=dict(initial_tensors_equal=True,trainable_encoder_stages=[i+1 for i in expected],optimizer_membership_exact=True,frozen_parameters_unchanged=True,weight_decay=spec['weight_decay'],encoder_eval=True,auxiliary_head=False)
report=dict(passed=True,variants=results,note='Trainability and optimizer contracts checked on a small encoder fixture with the real native UPer64 head; actual MambaVision gradient/cache checks run separately on GPU.')
(ROOT/'reports/STAGEB_REMAINING_CPU_TESTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
