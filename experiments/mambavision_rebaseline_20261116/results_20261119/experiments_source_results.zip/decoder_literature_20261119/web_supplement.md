# 一手文献和实现核对

| 来源 | 类型 | 核对内容 |
|---|---|---|
| [U-Net v2，方法和消融表 3](https://arxiv.org/html/2311.17791v2) | 作者论文 | ISIC2017 消融以及 ISIC2018 整网结果 |
| [U-Net v2，SDI 源码](https://github.com/yaoppeng/U-Net_v2/blob/ae60bd0c7bae78956cbfdbeebdce8906972acd7f/PolypSeg/unet_v2/UNet_v2.py#L88) | 作者源码 | 固定版本，类 SDI 用于本项目接入验证 |
| [VM-UNetV2](https://arxiv.org/abs/2403.09157) | 作者论文 | 视觉状态空间网络已使用 SDI |
| [G-CASCADE 补充材料](https://openaccess.thecvf.com/content/WACV2024/supplemental/Rahman_G-CASCADE_Efficient_Cascaded_WACV_2024_supplemental.pdf) | 会议论文附录 | 核对 ISIC2018 的 PVT-CASCADE 与 PVT-GCASCADE、训练规模及五次运行 |
| [G-CASCADE 解码器](https://github.com/SLDGroup/G-CASCADE/blob/08d76880027bfe14ed79def1eea3d8a4957fbab6/lib/decoders.py#L543) | 作者源码 | 核对 GCASCADE 的通道、img_size、图算子及输入顺序 |
| [FreqFusion 论文](https://arxiv.org/abs/2408.12879) | 作者论文 | 频率感知多尺度融合在自然图像稠密预测上的证据 |
| [FreqFusion 源码](https://github.com/Linwei-Chen/FreqFusion/blob/3fb0c70637a3c194fb74294d3ce4681958b26241/FreqFusion.py) | 作者源码 | 核对高低分辨率输入与重组输出 |
| [EMCAD](https://openaccess.thecvf.com/content/CVPR2024/html/Rahman_EMCAD_Efficient_Multi-scale_Convolutional_Attention_Decoding_for_Medical_Image_Segmentation_CVPR_2024_paper.html) | 会议论文 | 本项目 Stage33–35 已测试适配版本 |
| [MIST CAM 论文及附录](https://openaccess.thecvf.com/content/WACV2024/supplemental/Rahman_MIST_Medical_WACV_2024_supplemental.pdf) | 会议论文附录 | 核对跳接形状与额外瓶颈 |
| [MIST 实现](https://github.com/Rahman-Motiur/MIST) | 作者仓库 | 核对数据集和训练入口 |
| [Dual Cross-Attention](https://arxiv.org/abs/2303.17696) | 作者论文 | 与已做的 UCTransNet CCA 区分，作为后备 |
| [Dual Cross-Attention 代码](https://github.com/gorkemcanates/Dual-Cross-Attention) | 作者仓库 | 跨尺度通道及空间注意力的来源 |
