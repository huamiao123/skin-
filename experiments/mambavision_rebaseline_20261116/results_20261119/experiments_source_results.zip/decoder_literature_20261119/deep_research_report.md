# 固定 MambaVision-S 的 decoder 选择

本轮以提升 ISIC2018 逐图前景 Dice 为目标。主指标不要求指定一类漏分必须同时改善。优先试 UPer64 加四尺度 SDI。如果愿意投入完整解码器的开发预算，下一候选为 G-CASCADE。两者都已有作者实现和同类任务实验。

## 项目内可以直接比较的数字

同一批特征修正训练中，762 张验证图的最佳逐图 Dice 为原生 Add 89.2213%、Gated Concat 89.1016%、F3 Difference 89.0155%。同家族的单级 DySample 结果为 89.2107%。配置和轮次可追溯至上一级工程的 uper64_feature_audit_20261119/runs 和 transfer_20261119/dysample_f2_to_f1。历史 Stage35 的 EMCAD 单输出与深监督适配分别为 88.9355% 和 88.9872% 验证 Dice。Stage36 已含 UCTransNet CCA 与去注意力对照，Stage39–43 已系统测试 PointRend。不同历史阶段有各自的匹配基线，尤其上一轮增加 472 次重采样的普通组不适合作本轮唯一基线。

## 为什么先试四尺度 SDI

U-Net v2 的表 3 在 ISIC2017 给出完整模型 90.21、去 SDI 89.85、去空间和通道注意力后保留 SDI 90.20。其表 1 的 ISIC2018 整网结果为 91.52。作者使用 PVT 系列编码器，报告的训练协议最高 300 轮，整网成绩和单模块增益应单独引用。VM-UNetV2 也将 SDI 与视觉状态空间模块结合并用于 ISIC。论文可以把这些作为直接先例。只把模块移入 MambaVision-S 可以回答工程适配的效果，不能凭这个组合主张首创。 [U-Net v2 正文](https://arxiv.org/html/2311.17791v2) · [VM-UNetV2](https://arxiv.org/abs/2403.09157)

保留四级 MambaVision-S 输出以及原生 UPer64 的 PPM、FPN 和分类头。使用现成的三个 64 通道侧向投影和一个 64 通道 PPM 输出。在第二级的 32×32 网格上对齐四路，每路独立做 3×3 卷积。作者 SDI 将四支对应元素相乘。新增 1×1 输出投影，以残差加回第二级原生融合。作者整网为四个尺度各建 SDI，本轮接法只增加一个位置。均值对照逐项保留相同的参数、卷积、对齐与输出投影，仅将乘法换为算术平均。 [作者实际使用的 SDI 类](https://github.com/yaoppeng/U-Net_v2/blob/ae60bd0c7bae78956cbfdbeebdce8906972acd7f/PolypSeg/unet_v2/UNet_v2.py#L88)

在服务器 RTX 4090 使用 4 张真实 ISIC 训练图，每组进行了两次优化器更新。四级输出分别为 96×64×64、192×32×32、384×16×16、768×8×8。均值和乘积两组的新增参数都是 151,872，新增权重初始化哈希一致，初始输出与原生 UPer64 最大差均为零。第二步两组四条输入卷积均有非零梯度。此次仅检查接入、训练路径和梯度，尚无正式验证或测试 Dice。参数和日期见 sdi_smoke.json。该版本按 256×256 正方形验证，原作者的 SDI 以宽度决定目标边长。

## 其他候选

| 方向 | 依据 | 接入与优先级 |
|---|---|---|
| G-CASCADE | WACV 2024 附录报告同一研究设置下，ISIC2018 的 PVT-CASCADE 为 91.1，PVT-GCASCADE 为 91.51±0.61。随机 80/10/10 划分，输入通常为 384×384，后者为五次运行。 | 完整 decoder 备选。用图邻域特征更新、空间注意力和逐级上采样替换解码路径，保留原编码器。源码按深到浅收取输入，配置改为 768、384、192、96，img_size 设为 256。先单主头、同损失测试整套解码器，若有效再以常规卷积代替图块来估计图算子的贡献。 |
| FreqFusion | 在自然图像稠密预测上检验了空间变化的低通、高通和采样修正。与已试的单级 DySample 的区别是对两路都作滤波。 | 作为保留 UPer64 的第二选择，在原生 FPN 的一处以作者模块同时处理高、低分辨率特征，再合并。记录 CARAFE 或纯 PyTorch 路径、显存。同一位置对照双线性与 DySample，先独立测试。 |
| MIST 的 CAM 解码器 | WACV 2024，ACDC 与 Synapse；作者图示的四种跳接宽度和网格与本项目相符。其完整结构还使用额外瓶颈、卷积投影自注意力和多种注意力混合。 | 可作为高容量后备。需适配额外瓶颈，通道相符不能证明可整网搬用。皮肤任务的直接证据弱于 G-CASCADE。 |
| EMCAD、DCA | EMCAD 有直接的皮肤分割论文及项目本地适配结果；DCA 顺序考虑跨尺度的通道和空间依赖。 | EMCAD 优先引用项目既有结果；DCA 与旧 CCA 有联系，二者各自有独立实现。优先级低于两条结构差别更大的方案。 |

G-CASCADE 的结果和源码见[会议补充材料](https://openaccess.thecvf.com/content/WACV2024/supplemental/Rahman_G-CASCADE_Efficient_Cascaded_WACV_2024_supplemental.pdf)及[解码器文件](https://github.com/SLDGroup/G-CASCADE/blob/08d76880027bfe14ed79def1eea3d8a4957fbab6/lib/decoders.py#L543)。其他实现见 [FreqFusion](https://github.com/Linwei-Chen/FreqFusion)、[MIST](https://github.com/Rahman-Motiur/MIST)、[EMCAD](https://openaccess.thecvf.com/content/CVPR2024/html/Rahman_EMCAD_Efficient_Multi-scale_Convolutional_Attention_Decoding_for_Medical_Image_Segmentation_CVPR_2024_paper.html)及 [DCA](https://github.com/gorkemcanates/Dual-Cross-Attention)。

## 最小正式实验

A 为原生 UPer64，B 为四路均值，C 为四路乘积。先核实 A 的数据、源码、初始化和训练配方与已有 89.2213% 基线一致，可以重用时不必多训一份。B/C 的初始参数配对。使用官方 ImageNet-1K 编码器起点，微调第 3、4 阶段和完整解码器；同划分、256×256、同增强、BCE 加逐图 soft Dice、100 轮、固定阈值 0.5，按验证逐图 Dice 选择权重。验证时报告 C−A 与 C−B 的配对差值。如 B/C 都改善且相近，多尺度信息路径足以解释一部分收益；如 C 在配对重复中还领先 B，可报告乘积的额外贡献；若 B 更好，性能优先时保留 B。验证优胜者和 A 使用相同的后续随机种子复核，再冻结方案评测。正式确认时考虑一套未用于选方案的数据。上一轮项目已多次读取历史测试，53 张图与训练或验证共享已知或保守病例分组。

## 检索范围和文件

OpenAlex 和 Crossref 各取 35 条，去重后 61 条。按相关度筛选，再用作者论文、CVF 附录和官方代码补查。61 条是索引记录数。表中的细节来自已核对的一手来源，覆盖受关键词、索引和公开代码影响。接口查询在 retrieval/search_log.md，原始条目在 retrieval/papers.json。一手来源在 web_supplement.md，三份固定版本的模型源码在 verified_sources/，本项目接口实现在 smoke_sdi.py。
