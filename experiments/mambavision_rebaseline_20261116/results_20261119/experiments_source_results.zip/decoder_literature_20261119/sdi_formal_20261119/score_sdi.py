"""Evaluate the validation-locked SDI experiment and export matched per-image Dice."""
import csv
from concurrent.futures import ThreadPoolExecutor
from itertools import combinations
import json
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from fit_sdi import ROOT, TMP, read, fixed, run_dir, setup, build, sha, train

GROUPS=Path('/home/featurize/work/mambavision_seg_rebaseline_20261116/uper64_feature_audit_20261119/transfer_20261119/hard_extent_s_20261119/group_sensitivity_protocol.json')
def get_val(path):
    rows=list(csv.DictReader(path.open()))
    return [r['id'] for r in rows],np.array([float(r['dice']) for r in rows])
def paired(a,b,groups):
    d=np.asarray(b)-np.asarray(a)
    names,ix=np.unique(groups,return_inverse=True)
    ns=np.bincount(ix);ss=np.bincount(ix,weights=d);n=len(names)
    rng=np.random.default_rng(42);boot=[]
    for _ in range(5000):
        sample=rng.integers(n,size=n)
        boot.append(ss[sample].sum()/ns[sample].sum())
    return dict(delta=float(d.mean()),paired_group_bootstrap95=np.quantile(boot,[.025,.975]).tolist(),
                groups=n,improved=int((d>0).sum()),worse=int((d<0).sum()),ties=int((d==0).sum()))
def summarize(arrays,cases,models):
    result={}
    for section,keep in [('all',np.ones(len(cases),dtype=bool)),('group_filtered',np.array([r['retain'] for r in cases]))]:
        arr={k:v[keep] for k,v in arrays.items()}
        groups=np.array([r['group'] for r in cases])[keep]
        comparisons={}
        for a,b in combinations(arr,2):
            if models[a]['seed']==models[b]['seed']:comparisons[b+' minus '+a]=paired(arr[a],arr[b],groups)
        result[section]=dict(n=int(keep.sum()),macro_dice={k:float(v.mean()) for k,v in arr.items()},paired=comparisons)
    return result
def main():
    done=read(TMP/'fit_done.json');assert done['complete']
    confirm=done['decision']['confirm'];leader=done['decision']['leader']
    armseeds=[('add',42),('mean',42),('product',42)]+([('add',43),(leader,43)] if confirm else [])
    groups=read(GROUPS)['cases']
    models={};vals={};locs={}
    for arm,seed in armseeds:
        loc=run_dir(arm,seed);name=f'{arm}_{seed}'
        comp=read(loc/'complete.json');v=comp['best'];ids,scores=get_val(loc/'best_validation.csv')
        assert ids==[c['id'] for c in groups['val']] and np.isclose(v['val_macro_dice'],scores.mean(),rtol=0,atol=1e-12)
        ckhash=sha(loc/'best.pth')
        if arm=='add' and seed==42:assert ckhash==read(TMP/'reference_verified.json')['checkpoint_sha256']
        else:assert ckhash==comp['sha256']
        vals[name]=scores;locs[name]=loc
        models[name]=dict(seed=seed,arm=arm,epoch=v['epoch'],sha256=ckhash,best_val=v['val_macro_dice'])
    fixed(TMP/'locked_before_test.json',dict(models=models,decision=done['decision'],fixed_threshold=.5,group_file_sha256=sha(GROUPS)))
    res={'validation':summarize(vals,groups['val'],models)}
    partition_path=train.PROJECT/'stage45_upernet_decoder/identity_partition.json'
    p=read(partition_path);ids=p['splits']['test'];assert [r['id'] for r in groups['test']]==ids
    parent=train.PROJECT.parent.parent;manifest_path=parent/'local_audit_records/test_assets/test_manifest.json'
    assert sha(manifest_path)==p['audit_sha256']['test_manifest.json']
    manifest={r['id']:r for r in read(manifest_path)}
    def read_img(sid):
        d=parent/'heldout_data/test';x=d/'images'/(sid+'.png');y=d/'masks'/(sid+'.png')
        assert sha(x)==manifest[sid]['image_256_sha256'] and sha(y)==manifest[sid]['mask_256_sha256']
        with Image.open(x) as rgb,Image.open(y) as target:
            return np.array(rgb.convert('RGB')),np.array(target.convert('L'))>=128
    with ThreadPoolExecutor(8) as pool:rows=list(pool.map(read_img,ids))
    x=torch.from_numpy(np.stack([a for a,b in rows])).permute(0,3,1,2).contiguous()
    g=torch.from_numpy(np.stack([b for a,b in rows]));del rows
    mu=torch.tensor([.485,.456,.406],device='cuda')[None,:,None,None];std=torch.tensor([.229,.224,.225],device='cuda')[None,:,None,None]
    tests={}
    for name,v in models.items():
        setup(v['seed']);model=build(v['arm'],v['seed'])
        state=torch.load(locs[name]/'best.pth',map_location='cpu',weights_only=False)
        assert state['epoch']==v['epoch'];model.load_state_dict(state['model']);del state;model.eval()
        chunks=[]
        with torch.inference_mode():
            for img,target in zip(x.split(64),g.split(64)):
                inp=(img.cuda().float()/255.-mu)/std;gt=target.cuda()
                with torch.autocast('cuda',dtype=torch.bfloat16):logits=model(inp)['main'].float()[:,0]
                assert torch.isfinite(logits).all()
                pred=logits.sigmoid()>=.5
                tp=(pred&gt).sum((1,2));den=pred.sum((1,2))+gt.sum((1,2))
                chunks.append(torch.where(den>0,2*tp.double()/den,1.).cpu().numpy())
        tests[name]=np.concatenate(chunks);del model;torch.cuda.empty_cache()
    res['test']=summarize(tests,groups['test'],models)
    assert res['test']['all']['n']==867 and res['test']['group_filtered']['n']==814
    for split,arrays in [('val',vals),('test',tests)]:
        rows=[dict(id=r['id'],group=r['group'],retained=r['retain'],**{k:float(v[i]) for k,v in arrays.items()}) for i,r in enumerate(groups[split])]
        train.write_rows(TMP/(split+'_per_image.csv'),rows)
    train.atomic_json(TMP/'result.json',dict(complete=True,models=models,**res))
    print('FINAL',json.dumps(res['test']['all']['macro_dice']),flush=True)
if __name__=='__main__':main()
