"""Quantify what the F3/F4 gate actually selects on unseen development images."""
from concurrent.futures import ThreadPoolExecutor
import csv
import json
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from scipy.ndimage import distance_transform_edt
from fit_bypass import ROOT, TMP, SEED, model_for, setup, lower_half, sha, train, read

def prob_and_gate(net,x,off=False):
    head=net.probe.decode_head
    factors={}
    def capture(i):
        def hook(m,args,out):factors[i]=lower_half(out)
        return hook
    handles=[head.sdi.convs[i].register_forward_hook(capture(i)) for i in (2,3)]
    if off:handles.append(head.shallow.register_forward_hook(lambda m,i,o:torch.zeros_like(o)))
    try:
        with torch.autocast('cuda',dtype=torch.bfloat16):
            p=net(x)['main'][:,0].float().sigmoid()
    finally:
        for h in handles:h.remove()
    mask=factors[2]&factors[3]
    gate=F.interpolate(mask.float(),size=p.shape[-2:],mode='nearest')[:,0].bool()
    return p,gate

def make_plots(cases,path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    font=Path('/tmp/mv_sdi_features_20261119/fonts/NotoSansCJKsc-Regular.otf')
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams['font.family']=font_manager.FontProperties(fname=str(font)).get_name()
    plt.rcParams['axes.unicode_minus']=False
    fig,axes=plt.subplots(len(cases),5,figsize=(13.4,7.8))
    names=['原图与人工标注','补入浅层特征的位置','关闭浅层分支','开启浅层分支','前景概率变化']
    for ax,name in zip(axes[0],names):ax.set_title(name,fontsize=12)
    for row,(sid,data) in enumerate(cases.items()):
        im,gt,gate,p0,p1=data
        for col,ax in enumerate(axes[row]):
            ax.set_xticks([]);ax.set_yticks([])
            if col==0:
                ax.imshow(im)
                ax.set_ylabel(sid,fontsize=10)
            elif col==1:
                ax.imshow(im);ax.imshow(np.ma.masked_where(~gate,gate),cmap='autumn',vmin=0,vmax=1,alpha=.62,interpolation='nearest')
            elif col==2 or col==3:
                prob=p0 if col==2 else p1
                ax.imshow(prob,cmap='gray',vmin=0,vmax=1)
                if prob.min()<.5<prob.max():ax.contour(prob,levels=[.5],colors=['#ff85cb'],linewidths=.9)
            else:change=ax.imshow(p1-p0,cmap='RdBu_r',vmin=-.15,vmax=.15)
            if gt.any() and not gt.all():ax.contour(gt,levels=[.5],colors=['#20cb91'],linewidths=.8)
    fig.suptitle('同一权重上开关浅层分支，观察修正位置与预测变化',fontsize=16,y=.975)
    fig.subplots_adjust(left=.08,right=.915,top=.88,bottom=.08,hspace=.10,wspace=.06)
    bar=fig.add_axes([.932,.275,.011,.42]);fig.colorbar(change,cax=bar,ticks=[-.15,0,.15],extend='both')
    fig.text(.08,.02,'绿色为人工轮廓，粉色为 0.5 预测轮廓。第二列黄色为实际加入浅层特征的位置。末列红色为开启后前景概率上升，蓝色为下降。三个病例沿用前一轮选例。',fontsize=9)
    fig.savefig(path,dpi=155)
    plt.close(fig)

@torch.inference_mode()
def main():
    setup(SEED)
    old=model_for('control').eval()
    weak=model_for('weak').eval()
    ck=TMP/'weak/best.pth'
    assert sha(ck)==read(TMP/'weak/complete.json')['sha256']
    weak.load_state_dict(torch.load(ck,map_location='cpu',weights_only=False)['model'])
    data,_=train.reference.load_data()
    with (ROOT.parent/'feature_maps_20261119/product_per_image.csv').open() as f:
        public=[r['isic'] for r in csv.DictReader(f)]
    assert len(public)==len(data.ids['val'])==762
    order=('ISIC_0017399','ISIC_0015056','ISIC_0014457')
    cases={};rows=[];norm=[.485,.456,.406];std=[.229,.224,.225]
    with ThreadPoolExecutor(8) as pool:
        for k in range(0,len(public),32):
            idx=torch.arange(k,min(k+32,len(public)),device='cuda')
            x,truth=data.batch('val',idx)
            gt=truth[:,0]>=.5
            ref,oldgate=prob_and_gate(old,x)
            on,gate=prob_and_gate(weak,x)
            off,othergate=prob_and_gate(weak,x,True)
            assert torch.equal(gate,othergate)
            assert torch.isfinite(on).all() and torch.isfinite(off).all()
            deep=gt&(torch.as_tensor(np.stack(list(pool.map(distance_transform_edt,gt.cpu().numpy()))),device=gt.device)>8)
            miss=deep&(ref<.1)
            correct=deep&(ref>=.5)
            changed=(on>=.5)!=(off>=.5)
            helped=changed&((on>=.5)==gt)
            hurt=changed&((on>=.5)!=gt)
            extra={
                'fixed_any':helped,'harmed_any':hurt,
                'fixed_reference_severe':helped&miss,'harmed_reference_severe':hurt&miss,
                'fixed_inside_gate':helped&gate,'harmed_inside_gate':hurt&gate,
                'off_severe_rescued':(deep&(off<.1)&(on>=.5)),
                'off_correct_now_severe':(deep&(off>=.5)&(on<.1))
            }
            for name,g in [('initial',oldgate),('trained',gate)]:
                extra[name+'_gated']=g;extra[name+'_background_gated']=g&~gt
                extra[name+'_reference_miss_gated']=g&miss;extra[name+'_reference_correct_gated']=g&correct
            extra['miss']=miss;extra['correct']=correct
            out={name:v.sum((1,2)).cpu().numpy() for name,v in extra.items()}
            for i,sid in enumerate(public[k:k+len(x)]):
                rows.append(dict(isic=sid,**{n:int(v[i]) for n,v in out.items()}))
                if sid in order:
                    img=(x[i].permute(1,2,0).cpu().numpy()*std+norm).clip(0,1)
                    cases[sid]=(img,gt[i].cpu().numpy(),gate[i].cpu().numpy(),off[i].cpu().numpy(),on[i].cpu().numpy())
    assert len(rows)==762 and set(cases)==set(order)
    paired=[r for r in rows if min(r['miss'],r['correct'])>=64]
    totals={k:sum(r[k] for r in rows) for k in rows[0] if k!='isic'}
    summary={'images':len(rows),'paired_interiors':len(paired),'counts':totals,'gate':{}}
    for name in ('initial','trained'):
        summary['gate'][name]=dict(area_fraction=totals[name+'_gated']/(len(rows)*256**2),
             background_fraction=totals[name+'_background_gated']/totals[name+'_gated'],
             mean_coverage_severe=float(np.mean([r[name+'_reference_miss_gated']/r['miss'] for r in paired])),
             mean_coverage_correct=float(np.mean([r[name+'_reference_correct_gated']/r['correct'] for r in paired])))
    train.write_rows(ROOT/'dev_gate_per_image.csv',rows)
    make_plots({k:cases[k] for k in order},ROOT/'gate_cases.png')
    train.atomic_json(ROOT/'dev_gate_diagnosis.json',summary)
    print(json.dumps(summary),flush=True)
if __name__=='__main__':main()
