"""Development-only factorial replay of learned weights and BN running statistics."""
from fit_bypass import model_for, START, ROOT, TMP, SEED, setup, torch, train, read, sha
def main():
    setup(SEED)
    data,_=train.reference.load_data()
    net=model_for('control')
    cache=train.reference.cache_new(len(data.ids['val']))
    a={k:v.detach().clone().cpu() for k,v in net.state_dict().items()}
    best=TMP/'control/best.pth'
    assert sha(best)==read(TMP/'control/complete.json')['sha256']
    b=torch.load(best,map_location='cpu',weights_only=False)['model']
    assert set(a)==set(b)
    names={k for k in a if k.endswith(('running_mean','running_var','num_batches_tracked'))}
    changed=[k for k in names if not torch.equal(a[k],b[k])]
    rows={}
    for w,stats in [('original','original'),('continued','continued'),('continued','original'),('original','continued')]:
        weights=a if w=='original' else b
        buffers=a if stats=='original' else b
        net.load_state_dict({k:(buffers[k] if k in names else weights[k]) for k in a})
        train.reference.fill_cache(net,data,'val',cache)
        scores,_=train.validate(net,cache,data.ids['val'],None)
        rows[w+'_weights_'+stats+'_bn']=scores['val_macro_dice']
    assert abs(rows['continued_weights_continued_bn']-read(TMP/'control/complete.json')['selection_score'])<1e-12
    result=dict(images=len(data.ids['val']),source='development only',bn_buffer_count=len(names),changed_bn_buffers=sorted(changed),dev=rows)
    train.atomic_json(ROOT/'bn_factorial_dev.json',result)
    print(rows)
if __name__=='__main__':main()
