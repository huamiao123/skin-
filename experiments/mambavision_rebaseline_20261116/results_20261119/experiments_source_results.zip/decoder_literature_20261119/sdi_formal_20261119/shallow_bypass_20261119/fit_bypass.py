"""Four matched continuations from the pretrained ISIC SDI checkpoint."""
import csv
import fcntl
import gc
import hashlib
import json
import math
import sys
import time
from pathlib import Path
import torch
from torch import nn
from torch.nn import functional as F

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
from fit_sdi import train, build as build_sdi, sha, setup, read, fixed
sys.path.insert(0,str(ROOT.parent/'feature_maps_20261119'))
from weak_gain import predict as old_gain

TMP=Path('/tmp/mv_sdi_shallow_bypass_20261119')
START=ROOT.parent/'runs/product_42/best.pth'
ARMS=('weak','global','shift','control')
EPOCHS=40
SEED=42
def lower_half(x):
    e=x.detach().float().square().mean(dim=1,keepdim=True)
    return e < e.flatten(1).median(dim=1).values[:,None,None,None]
def resize(x,size):
    return F.interpolate(x,size=size,mode='bilinear',align_corners=False)

class Supplement(nn.Module):
    def __init__(self,original,arm):
        super().__init__()
        self.head=original.head;self.sdi=original.sdi;self.out=original.out
        self.arm=arm
        self.shallow=None
        if arm!='control':
            self.shallow=nn.Sequential(nn.Conv2d(288,128,1,bias=False),nn.GroupNorm(8,128),nn.GELU(),
                                       nn.Conv2d(128,64,3,padding=1,bias=False),nn.GroupNorm(8,64),nn.GELU(),nn.Conv2d(64,64,1))
            nn.init.zeros_(self.shallow[-1].weight);nn.init.zeros_(self.shallow[-1].bias)

    def factors(self,lateral):
        size=lateral[1].shape[-2:];factors=[]
        for conv,x in zip(self.sdi.convs,lateral):
            if x.shape[-2]>size[0]:x=F.adaptive_avg_pool2d(x,size)
            elif x.shape[-2]<size[0]:x=F.interpolate(x,size=size,mode='bilinear',align_corners=True)
            factors.append(conv(x))
        return factors

    def mask(self,factors):
        mask=lower_half(factors[2]) & lower_half(factors[3])
        if self.arm=='shift':return torch.roll(mask,shifts=(mask.shape[-2]//2,mask.shape[-1]//2),dims=(-2,-1))
        if self.arm=='global':return torch.ones_like(mask)
        return mask

    def forward(self,features):
        h=self.head
        lat=[c(x) for c,x in zip(h.lateral_convs,features)]+[h.psp_forward(features)]
        fs=self.factors(lat)
        delta=self.out(fs[0]*fs[1]*fs[2]*fs[3])
        delta=(delta.float()*(1+lower_half(delta).float())).to(delta.dtype)
        if self.shallow is not None:
            local=torch.cat([F.adaptive_avg_pool2d(features[0],lat[1].shape[-2:]),features[1]],dim=1)
            branch=self.shallow(local)*self.mask(fs)
        for i in range(3,0,-1):
            lat[i-1]=lat[i-1]+resize(lat[i],lat[i-1].shape[-2:])
            if i==2:
                lat[i-1]=lat[i-1]+delta
                if self.shallow is not None:lat[i-1]=lat[i-1]+branch
        pyramid=[c(x) for c,x in zip(h.fpn_convs,lat)]+[lat[-1]]
        return h.cls_seg(h.fpn_bottleneck(torch.cat([pyramid[0]]+[resize(x,pyramid[0].shape[-2:]) for x in pyramid[1:]],dim=1)))

def model_for(arm):
    model=build_sdi('product',SEED)
    state=torch.load(START,map_location='cpu',weights_only=False)
    assert state['epoch']==39
    model.load_state_dict(state['model']);del state
    original=model.probe.decode_head
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(17211)
        model.probe.decode_head=Supplement(original,arm).cuda()
    return model
def opt_for(model):
    shallow=model.probe.decode_head.shallow
    extra=[] if shallow is None else list(shallow.parameters())
    extraids={id(w) for w in extra}
    groups=[dict(name='decoder',lr=1e-4,params=[p for p in model.probe.parameters() if id(p) not in extraids]),
            dict(name='encoder',lr=1e-5,params=[p for p in model.encoder.parameters() if p.requires_grad])]
    if extra:groups.append(dict(name='shallow',lr=1e-3,params=extra))
    assert sum(len(g['params']) for g in groups)==sum(1 for p in model.parameters() if p.requires_grad)
    for g in groups:g['initial_lr']=g['lr']
    return torch.optim.AdamW(groups,weight_decay=.01,betas=(.9,.999),eps=1e-8)
def preflight(data):
    setup(SEED);original=build_sdi('product',SEED);state=torch.load(START,map_location='cpu',weights_only=False)
    original.load_state_dict(state['model']);del state;original.eval()
    ids=torch.arange(4,device='cuda')
    x,gt=data.batch('train',ids)
    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
        f1,f2,mid=original.prefix(x);features=[f1,f2,*original.suffix(mid)]
        exact=old_gain(original,features,'weak2')
    del original
    records={};masks={}
    for arm in ARMS:
        setup(SEED);net=model_for(arm);h=net.probe.decode_head;net.eval()
        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
            out=net(x)['main'][:,0].float().sigmoid()
            assert torch.equal(out,exact),(arm,(out-exact).abs().max())
            lat=[c(y) for c,y in zip(h.head.lateral_convs,features)]+[h.head.psp_forward(features)]
            mask=h.mask(h.factors(lat)).cpu()
        masks[arm]=mask
        if h.shallow is not None:
            params=sum(p.numel() for p in h.shallow.parameters())
            engine=opt_for(net);net.train();grad=[]
            for step in range(2):
                engine.zero_grad(set_to_none=True)
                with torch.autocast('cuda',dtype=torch.bfloat16):z=net(x)['main']
                from model import segmentation_loss
                segmentation_loss(z,gt).backward()
                grad.append([float(h.shallow[j].weight.grad.abs().max()) for j in (0,3,6)])
                assert all(math.isfinite(v) for v in grad[-1])
                engine.step()
            assert min(grad[1])>0
        else:params=0;grad=[]
        records[arm]=dict(extra_parameters=params,peak_grad_two_steps=grad,initial_probability_difference=0,mask_fraction=float(mask.float().mean()))
        del net;gc.collect();torch.cuda.empty_cache()
    assert torch.equal(torch.roll(masks['weak'],(16,16),(-2,-1)),masks['shift']) and masks['global'].all()
    fixed(TMP/'preflight.json',records)
def train_arm(arm,data,cache,val):
    dst=TMP/arm;dst.mkdir(exist_ok=True)
    if (dst/'complete.json').exists():return
    setup(SEED);net=model_for(arm);opt=opt_for(net);last=dst/'latest.pth';hist=[]
    config=dict(arm=arm,code=sha(ROOT/'fit_bypass.py'),protocol=sha(TMP/'protocol.json'))
    if last.exists():
        st=torch.load(last,map_location='cpu',weights_only=False);assert st['config']==config
        net.load_state_dict(st['model']);opt.load_state_dict(st['optimizer']);train.restore_rng(st['rng'])
        hist=st['history'];del st
    best=max((a['val_macro_dice'] for a in hist),default=-1.)
    train.reference.fill_cache(net,data,'val',val)
    for epoch in range(len(hist)+1,EPOCHS+1):
        ts=time.monotonic();order,geo=data.geometry(39+epoch)
        train.reference.fill_cache(net,data,'train',cache,geo)
        factor=.01+.99*(1+math.cos(math.pi*(epoch-1)/EPOCHS))/2
        for g in opt.param_groups:g['lr']=g['initial_lr']*factor
        net.train();running=0.
        for i,ids in enumerate(order.split(64)):
            loss,norms=train.accumulate(net,opt,cache,ids,64)
            if i==0 and epoch==1:
                assert all(math.isfinite(v) and v>0 for v in norms.values())
                train.atomic_json(dst/'first_update.json',dict(loss=loss,norms=norms))
            running+=loss*len(ids)
        scores,rows=train.validate(net,val,data.ids['val'],None)
        rec=dict(epoch=epoch,train_loss=running/len(order),**scores,seconds=round(time.monotonic()-ts,2))
        hist.append(rec)
        if rec['val_macro_dice']>best:
            best=rec['val_macro_dice'];train.atomic_save(dst/'best.pth',dict(epoch=epoch,config=config,model=train.base.cpu_tree(net.state_dict()),scores=scores))
            train.write_rows(dst/'best_per_image.csv',rows)
        if epoch==1 or epoch%5==0:
            train.atomic_save(last,dict(config=config,model=train.base.cpu_tree(net.state_dict()),optimizer=train.base.cpu_tree(opt.state_dict()),rng=train.rng_state(),history=hist))
        train.atomic_json(dst/'history.json',hist)
        print('train',arm,epoch,'time',rec['seconds'],flush=True)
    st=torch.load(dst/'best.pth',map_location='cpu',weights_only=False);net.load_state_dict(st['model'])
    replay,rows=train.validate(net,val,data.ids['val'],None)
    assert abs(replay['val_macro_dice']-best)<1e-12
    fixed(dst/'complete.json',dict(epoch=st['epoch'],sha256=sha(dst/'best.pth'),selection_score=best,epochs=EPOCHS))
def main():
    with (TMP/'train.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        ref=read(ROOT.parent/'runs/locked_before_test.json')['models']['product_42']
        assert ref['sha256']==sha(START)
        fixed(TMP/'protocol.json',dict(arms=list(ARMS),seed=SEED,epochs=EPOCHS,start_sha=ref['sha256'],start_epoch=39,
              primary='mean per-image foreground Dice, threshold 0.5; true-location branch versus original weak2, continuation control, identical unrestricted branch and shifted mask',
              branch='raw F1 avg-pooled to stride 8 + raw F2; 1x1 128 GN GELU, 3x3 64 GN GELU, zero-initialized 1x1 64',
              weak_location='intersection of below-image-median squared channel RMS of aligned convolved F3 and F4; never uses a label',
              unchanged_gain='all arms double the SDI residual below its own spatial median, in training and inference',
              shift='roll true gate by half the spatial height and width within the image',
              trainable='encoder stages3/4, decoder and new branch; decoder lr 1e-4, late encoder 1e-5, new branch 1e-3, AdamW, cosine40, starting from trained SDI weights',
              sampling='1886 distinct training cases per epoch, existing augmentations with epoch indices 40-79',
              selection='per arm: highest development foreground Dice of 40 completed continuation epochs, earliest tie. Report original locked zero-update weak2 separately. Fixed before test.',
              secondary='814-case group-filtered test; one seed; historical test previously used',
              code=sha(ROOT/'fit_bypass.py')))
        setup(SEED);data,_=train.reference.load_data()
        if not (TMP/'preflight.json').exists():preflight(data)
        cache=train.reference.cache_new(1886);val=train.reference.cache_new(762)
        for arm in ARMS:
            train_arm(arm,data,cache,val);gc.collect();torch.cuda.empty_cache()
        fixed(TMP/'locked_for_test.json',{a:read(TMP/a/'complete.json') for a in ARMS})
if __name__=='__main__':main()
