"""Fixed held-out evaluation of matched MambaVision-S shallow extensions."""
import csv
import gc
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from fit_bypass import ARMS, EPOCHS, ROOT, SEED, START, TMP, fixed, model_for, read, setup, sha, train
from score_sdi import paired

GROUPS=Path('/home/featurize/work/mambavision_seg_rebaseline_20261116/uper64_feature_audit_20261119/transfer_20261119/hard_extent_s_20261119/group_sensitivity_protocol.json')
REFERENCE=ROOT.parent/'feature_maps_20261119/gain_test_per_image.csv'

def test_inputs(part):
    ids=part['splits']['test']
    base=train.PROJECT.parent.parent
    manifest=base/'local_audit_records/test_assets/test_manifest.json'
    assert sha(manifest)==part['audit_sha256']['test_manifest.json']
    entries={r['id']:r for r in read(manifest)}
    def load(sid):
        root=base/'heldout_data/test'
        img=root/'images'/(sid+'.png')
        mask=root/'masks'/(sid+'.png')
        assert sha(img)==entries[sid]['image_256_sha256'] and sha(mask)==entries[sid]['mask_256_sha256']
        with Image.open(img) as x,Image.open(mask) as y:
            return np.array(x.convert('RGB')),np.array(y.convert('L'))>=128
    with ThreadPoolExecutor(8) as pool:
        cases=list(pool.map(load,ids))
    x=torch.from_numpy(np.stack([a for a,b in cases])).permute(0,3,1,2).contiguous()
    y=torch.from_numpy(np.stack([b for a,b in cases]))
    return x,y

@torch.inference_mode()
def score(net,x,y):
    net.eval()
    mu=torch.tensor([.485,.456,.406],device='cuda')[None,:,None,None]
    sd=torch.tensor([.229,.224,.225],device='cuda')[None,:,None,None]
    result=[]
    for image,truth in zip(x.split(64),y.split(64)):
        inp=(image.cuda().float()/255.-mu)/sd
        with torch.autocast('cuda',dtype=torch.bfloat16):
            logits=net(inp)['main'][:,0].float()
        assert torch.isfinite(logits).all()
        pred=logits.sigmoid()>=.5
        gt=truth.cuda()
        total=pred.sum((1,2))+gt.sum((1,2))
        hit=(pred&gt).sum((1,2))
        result.append(torch.where(total>0,2*hit.double()/total,1.).cpu().numpy())
    return np.concatenate(result)

def main():
    lock=read(TMP/'locked_for_test.json')
    protocol=read(TMP/'protocol.json')
    assert sorted(lock)==sorted(ARMS) and protocol['code']==sha(ROOT/'fit_bypass.py') and protocol['start_sha']==sha(START)
    for arm in ARMS:
        complete=read(TMP/arm/'complete.json')
        history=read(TMP/arm/'history.json')
        chosen=max(history,key=lambda r:r['val_macro_dice'])
        assert len(history)==EPOCHS and chosen['epoch']==complete['epoch']
        assert lock[arm]==complete and sha(TMP/arm/'best.pth')==complete['sha256']
    audit=dict(train_protocol_sha=sha(TMP/'protocol.json'),weights_lock_sha=sha(TMP/'locked_for_test.json'),evaluation_sha=sha(ROOT/'test_bypass.py'),threshold=.5,group_sha=sha(GROUPS),old_predictions_sha=sha(REFERENCE),
               primary='true weak mask vs historical weak2, matched continuation, unrestricted and shifted arms; 867 fixed cases',diagnostics='independently switch off branch and move mask at inference on the same weak-arm weights; secondary 814 retained cases')
    fixed(TMP/'locked_eval.json',audit)
    part=read(train.PROJECT/'stage45_upernet_decoder/identity_partition.json')
    ids=part['splits']['test']
    groups=read(GROUPS)['cases']['test']
    with REFERENCE.open() as f:previous=list(csv.DictReader(f))
    assert ids==[r['id'] for r in groups]==[r['id'] for r in previous] and len(ids)==len(set(ids))==867
    x,y=test_inputs(part)
    scores={'native':np.array([float(r['native']) for r in previous])}
    setup(SEED)
    old=model_for('control')
    scores['original']=score(old,x,y)
    expected=np.array([float(r['weak2']) for r in previous])
    assert np.max(np.abs(scores['original']-expected))<1e-12,('historical replay',np.max(np.abs(scores['original']-expected)))
    del old
    for arm in ARMS:
        setup(SEED)
        net=model_for(arm)
        state=torch.load(TMP/arm/'best.pth',map_location='cpu',weights_only=False)
        assert state['epoch']==lock[arm]['epoch'] and state['config']['protocol']==audit['train_protocol_sha']
        net.load_state_dict(state['model'])
        del state
        scores[arm]=score(net,x,y)
        if arm=='weak':
            h=net.probe.decode_head
            hook=h.shallow.register_forward_hook(lambda m,i,o:torch.zeros_like(o))
            try:scores['weak_branch_off']=score(net,x,y)
            finally:hook.remove()
            h.arm='shift'
            try:scores['weak_gate_shifted_at_eval']=score(net,x,y)
            finally:h.arm='weak'
        del net
        gc.collect()
        torch.cuda.empty_cache()
        print('scored',arm,flush=True)
    rows=[dict(id=sid,group=groups[i]['group'],retain=groups[i]['retain'],**{k:float(a[i]) for k,a in scores.items()}) for i,sid in enumerate(ids)]
    train.write_rows(TMP/'test_per_image.csv',rows)
    comparisons=[('original','weak'),('control','weak'),('global','weak'),('shift','weak'),('original','control'),('control','global'),('weak_branch_off','weak'),('weak_gate_shifted_at_eval','weak')]
    group=np.array([r['group'] for r in groups])
    results={}
    for name,sel in [('all',np.ones(len(ids),dtype=bool)),('group_filtered',np.array([r['retain'] for r in groups],dtype=bool))]:
        assert sel.sum()==(867 if name=='all' else 814)
        results[name]=dict(n=int(sel.sum()),dice={k:float(v[sel].mean()) for k,v in scores.items()},paired={b+'_minus_'+a:paired(scores[a][sel],scores[b][sel],group[sel]) for a,b in comparisons})
    train.atomic_json(TMP/'RESULTS.json',dict(complete=True,selection_epochs={a:v['epoch'] for a,v in lock.items()},test=results))
    print('verified',results['all']['dice'],flush=True)

if __name__=='__main__':main()
