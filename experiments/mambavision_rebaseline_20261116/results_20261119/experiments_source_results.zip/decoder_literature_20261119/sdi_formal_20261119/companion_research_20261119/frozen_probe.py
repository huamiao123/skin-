"""Read-only frozen feature probe on training/development. No held-out samples."""
import json, sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import torch
from torch.nn import functional as F
from scipy.ndimage import distance_transform_edt
from scipy.stats import rankdata
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'shallow_bypass_20261119'))
from fit_bypass import model_for, SEED, setup, train, sha, START
def auc(a,b):
    if not len(a) or not len(b):return np.nan
    n=len(a)
    ranks=rankdata(np.concatenate([a,b]))
    return (ranks[:n].sum()-n*(n+1)/2)/(n*len(b))
def get_features(net,x):
    with torch.autocast('cuda',dtype=torch.bfloat16):
        f1,f2,mid=net.prefix(x)
        f3,f4=net.suffix(mid)
        prob=net.probe([f1,f2,f3,f4],(256,256))['main'][:,0].float().sigmoid()
    res=dict(F1=F.adaptive_avg_pool2d(f1.float(),(16,16)),F2=F.adaptive_avg_pool2d(f2.float(),(16,16)),F3=f3.float(),F4=F.interpolate(f4.float(),size=(16,16),mode='bilinear',align_corners=False))
    return res,prob

@torch.inference_mode()
def main():
    setup(SEED);model=model_for('control').eval()
    data,_=train.reference.load_data()
    names=('F1','F2','F3','F4');acc={k:[[],[]] for k in names}
    def batches(split):
        for ix in torch.arange(len(data.ids[split]),device='cuda').split(48):
            x,y=data.batch(split,ix)
            yield ix,x,(y[:,0]>=.5)
    def grid(mask):return F.avg_pool2d(mask[:,None].float(),16,16)[:,0]
    for ix,x,g in batches('train'):
        features,_=get_features(model,x)
        occ=grid(g)
        for key,v in features.items():
            vec=F.normalize(v,dim=1)
            for c,mask in enumerate((occ<=.1,occ>=.9)):
                counts=mask.sum((1,2))
                each=(vec*mask[:,None]).sum((2,3))/counts.clamp_min(1)[:,None]
                acc[key][c].append(each[counts>0].cpu())
    prototypes={}
    for key,l in acc.items():
        bins=[torch.cat(x) for x in l]
        prototypes[key]=torch.stack([F.normalize(x.mean(0),dim=0) for x in bins]).cuda()
    rows={k:[] for k in names}
    with ThreadPoolExecutor(6) as pool:
        for ix,x,g in batches('val'):
            features,p=get_features(model,x)
            deep=g&(torch.as_tensor(np.stack(list(pool.map(distance_transform_edt,g.cpu().numpy()))),device=g.device)>8)
            occ=grid(g)
            miss=(occ>=.9)&(grid(deep&(p<.1))>=.25)
            correct=(occ>=.9)&(grid(deep&(p>=.5))>=.25)&(grid(deep&(p<.1))==0)
            bg=occ<=.1
            for key,v in features.items():
                direction=prototypes[key][1]-prototypes[key][0]
                margin=(F.normalize(v,dim=1)*direction[None,:,None,None]).sum(1).cpu().numpy()
                for j,sid in enumerate(ix.tolist()):
                    m,b,c=miss[j].cpu().numpy(),bg[j].cpu().numpy(),correct[j].cpu().numpy()
                    if bool(m.any()) and bool(b.any()):
                        rows[key].append(dict(id=data.ids['val'][sid],miss_cells=int(m.sum()),background_cells=int(b.sum()),auc_miss_vs_background=float(auc(margin[j][m],margin[j][b])),auc_correct_vs_background=float(auc(margin[j][c],margin[j][b])) if c.any() else None,miss_margin=float(margin[j][m].mean()),bg_margin=float(margin[j][b].mean())))
    report=dict(train=len(data.ids['train']),development=len(data.ids['val']),checkpoint=sha(START),grid='16x16; same grid; F1/F2 average pool; F3 native; F4 bilinear; class centroids equal weights per training image, cosine difference; thresholds and grid defined before run',severe_cells='>=90% foreground; >=25% of all cell pixels are >8 pixels from boundary with fixed weak2 p<.1; bg cells <=10% fg',parts={})
    for key,v in rows.items():
        assert len(v)>0
        c=np.array([r['auc_miss_vs_background'] for r in v])
        easy=[r for r in v if r['auc_correct_vs_background'] is not None]
        report['parts'][key]=dict(images=len(c),cells=sum(r['miss_cells'] for r in v),mean_within_image_auc=float(c.mean()),cases_with_both_fg_types=len(easy),matched_miss_auc=float(np.mean([r['auc_miss_vs_background'] for r in easy])),matched_correct_auc=float(np.mean([r['auc_correct_vs_background'] for r in easy])))
    train.atomic_json(ROOT/'frozen_probe.json',report)
    train.write_rows(ROOT/'frozen_probe_per_image.csv',[dict(layer=k,**r) for k,v in rows.items() for r in v])
    print(json.dumps(report),flush=True)
if __name__=='__main__':main()
