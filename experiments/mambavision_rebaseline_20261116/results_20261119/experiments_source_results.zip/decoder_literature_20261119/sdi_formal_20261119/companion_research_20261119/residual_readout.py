"""Train-only ridge fit of one additive probability residual per region, frozen SDI weights."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import torch
from skimage.segmentation import slic
from frozen_probe import ROOT,setup,SEED,model_for,train
from region_geometry import equal_count_grid
yy,xx=np.indices((256,256));cell16=(yy//16)*16+xx//16;cell8=(yy//32)*8+xx//32
keys=('grid','image')
def membership(im):
    g=slic(im,n_segments=128,compactness=10.,sigma=1.,max_num_iter=10,convert2lab=True,enforce_connectivity=True,start_label=0,channel_axis=-1)
    _,u=np.unique(g,return_inverse=True);u=u.reshape(256,256)
    return {'image':u,'grid':equal_count_grid(u.max()+1,256,256)}
def features_np(args):
    im,p,g=args;partition=membership(im);result={}
    for key,l in partition.items():
        i=l.ravel();n=np.bincount(i);k=len(n);w=n/float(g.size)
        def mean(v):return np.bincount(i,weights=v.ravel())/n
        mass=mean(p)
        cov=np.stack([mass,mean(p*p),mean(xx)/255,mean(yy)/255,mean(((xx-127.5)**2+(yy-127.5)**2)/32768),w],axis=1).astype('float32')
        overlaps=[(np.bincount((l*c+j).ravel(),minlength=k*c).reshape(k,c)/n[:,None]).astype('float32') for c,j in [(256,cell16),(64,cell8)]]
        result[key]=(l,*overlaps,cov,w.astype('float32'),(mean(g)-mass).astype('float32'))
    return result
def fit(gram):
    m=gram.double()
    ww=m[0,0];mean=m[0,1:-1]/ww;my=m[0,-1]/ww
    cov=m[1:-1,1:-1]/ww-mean[:,None]*mean[None,:]
    scale=torch.diag(cov).clamp_min(1e-10)
    rhs=m[1:-1,-1]/ww-mean*my
    weights=torch.linalg.solve(cov+torch.diag(.1*scale)+torch.eye(len(scale),device=m.device)*1e-8,rhs)
    return torch.cat([(my-mean@weights).reshape(1),weights]).float()
def metrics(z,g):
    a=z>=.5;gt=g.bool();den=a.sum()+gt.sum();return int((a!=gt).sum()),float(2*(a&gt).sum()/den) if den else 1.
@torch.inference_mode()
def main():
    setup(SEED);net=model_for('control').eval();data,_=train.reference.load_data()
    gramm={};models={};rows=[]
    def gpu(v): return torch.from_numpy(v).cuda()
    with ThreadPoolExecutor(8) as pool:
        for split in ['train','val']:
            for ix in torch.arange(len(data.ids[split]),device='cuda').split(40):
                x,gt=data.batch(split,ix);gt=gt[:,0]>=.5
                with torch.autocast('cuda',dtype=torch.bfloat16):
                    f1,f2,m=net.prefix(x);f3,f4=net.suffix(m)
                    p=net.probe([f1,f2,f3,f4],(256,256))['main'][:,0].float().sigmoid()
                a=f3.float().flatten(2).transpose(1,2);b=f4.float().flatten(2).transpose(1,2)
                rgb=data.images[split][ix].permute(0,2,3,1).contiguous().cpu().numpy()
                cases=list(pool.map(features_np,zip(rgb,p.cpu().numpy(),gt.cpu().numpy())))
                accumulated={}
                for j,c in enumerate(cases):
                    if split=='val':
                        baseline,baseline_d=metrics(p[j],gt[j]);r=dict(id=data.ids[split][ix[j].item()],baseline_errors=baseline,baseline_dice=baseline_d)
                    for name,(region,o3,o4,cv,w,target) in c.items():
                        base=gpu(cv);deep=torch.cat([gpu(o3)@a[j],gpu(o4)@b[j]],1)
                        design=torch.cat([torch.ones((len(w),1),device='cuda'),base,deep],1)
                        if split=='train':
                            joint=torch.cat([design,gpu(target)[:,None]],1)*gpu(w).sqrt()[:,None]
                            accumulated.setdefault(name,[]).append(joint)
                        else:
                            for variant,dsg in [('scalar',design[:,:7]),('deep',design)]:
                                k=name+'_'+variant
                                offset=dsg@models[k]
                                pred=p[j]+offset[gpu(region)]
                                err,dice=metrics(pred,gt[j]);r[k+'_errors']=err;r[k+'_dice']=dice
                    if split=='val':rows.append(r)
                if split=='train':
                    for name,bits in accumulated.items():
                        z=torch.cat(bits);gg=z.T@z
                        if name not in gramm:gramm[name]=gg.double()
                        else:gramm[name]+=gg
            if split=='train':
                for name,m in gramm.items():
                    indices=list(range(7))+[m.shape[0]-1]; models[name+'_scalar']=fit(m[indices][:,indices]);models[name+'_deep']=fit(m)
                print('trained on',len(data.ids['train']),flush=True)
    train.write_rows(ROOT/'residual_readout_per_image.csv',rows)
    summary=dict(train=len(data.ids['train']),development=len(rows),lambda_standardized=.1,trained_weights='ridge probability residual, area weighted, single fixed setting, prediction = pixel p + region residual. No main model or BN change.',comp={})
    for k in models:
        delta=np.array([r[k+'_errors']-r['baseline_errors'] for r in rows]);dd=np.array([r[k+'_dice']-r['baseline_dice'] for r in rows])
        summary['comp'][k]=dict(mean_error_pixel_change=float(delta.mean()),better_on_pixel_count=int((delta<0).sum()),better_dice=int((dd>0).sum()),worse_dice=int((dd<0).sum()),internal_mean_dice_delta=float(dd.mean()))
    train.atomic_json(ROOT/'residual_readout.json',summary);print(summary)
if __name__=='__main__':main()
