# 论文与作者源码补查

| 一手出处 | 核对的内容 | 本项目中的角色 |
|---|---|---|
| [U-Net v2 论文](https://arxiv.org/abs/2311.17791)与[作者 SDI 类](https://github.com/yaoppeng/U-Net_v2/blob/ae60bd0c7bae78956cbfdbeebdce8906972acd7f/PolypSeg/unet_v2/UNet_v2.py#L88) | 对齐后做可学习投影和逐元素乘积，皮肤和息肉分割。 | 本地只在 T2 注入一次，另有原生 PPM 和 FPN。 |
| [VM-UNetV2](https://arxiv.org/abs/2403.09157) | 视觉状态空间医学分割与跨层整合已有直接先例。 | 论文新意需由与 SDI 的独立增益和机制支撑。 |
| [Superpixel-Oriented Label Distribution Learning for Skin Lesion Segmentation](https://pmc.ncbi.nlm.nih.gov/articles/PMC9026477/) | 在皮肤镜图上生成 SLIC 超像素，用人工边界和距离为相交区域内的像素构建软标签，训练用硬、软标签。 | 同任务直接近邻。文中未验证本项目冻结特征上的区域修正。 |
| [Efficient semantic image segmentation with superpixel pooling](https://arxiv.org/abs/1806.02705) | 评估不同超像素池化网络，在 IBSR、Cityscapes 验证。 | 区域池化的已有方法。 |
| [SpixelFCN，CVPR 2020](https://openaccess.thecvf.com/content_CVPR_2020/html/Yang_Superpixel_Segmentation_With_Fully_Convolutional_Networks_CVPR_2020_paper.html)与[作者 poolfeat、upfeat](https://github.com/fuy34/superpixel_fcn/blob/ae81e171a64dc9ed26a039a1a52b87b5fe744cf1/train_util.py) | 学习像素对邻近网格单元的软归属，工具提供按权重池化与反投影。 | 本次筛查用固定 SLIC 硬分区，归属计算有别。 |
| [Superpixel Transformers for Efficient Semantic Segmentation](https://arxiv.org/abs/2309.16889) | 在区域空间进行上下文计算，并将区域预测投回像素。 | 区域 token、池化、回写的直接先例。 |
| [Soft labelling for semantic segmentation](https://arxiv.org/abs/2302.13961) | 讨论标签降采样时保留区域内的类别分布。 | 粗尺度覆盖率辅助监督的参考。 |
| [Exploring Cross-Image Pixel Contrast，ICCV 2021](https://arxiv.org/abs/2101.11939)与[作者损失](https://github.com/tfzhou/ContrastiveSeg/blob/287e5d3069ce6d7a1517ddf98e004c00f23f8f99/lib/loss/loss_contrast.py) | 全监督跨图像素对比，带归一化投影与采样。 | 表征学习备选。需允许表示和主分割共用、可更新的参数。 |
| [ReCo，ICLR 2022](https://arxiv.org/abs/2104.04465)与[作者 compute_reco_loss](https://github.com/lorenmt/reco/blob/71c1b7324fd36049c6657b122ba3fef373877b72/module_list.py) | 计算类别表征并从其他类抽取负样本，支持有监督及半监督。 | 二分类仅有一个其他类，类间挑难负类的机制退化。 |
| [医学影像中的局部与全局对比学习，NeurIPS 2020](https://proceedings.neurips.cc/paper_files/paper/2020/hash/949686ecef4ee20a62d16b4a2d7ccca3-Abstract.html) | 标注有限的医学分割表征学习。 | 任务证据有别于已标注的皮肤镜单图。 |
| [SAPA，NeurIPS 2022](https://proceedings.neurips.cc/paper_files/paper/2022/hash/83ccb398f3ce9c4d137011f36a03c7d4-Abstract.html)与[作者 forward](https://github.com/poppinace/sapa/blob/5530ef8b727f1a06d68c9066f6bda8d7da8c1d5d/SAPA.py) | 高分辨率查询与低分辨率键算邻域相似度，在低分辨率值上重组。 | 融合替代，加入前需区分错位还是区域身份错误。 |
| [ViT-Adapter，ICLR 2023 作者仓库](https://github.com/czczup/ViT-Adapter)与[作者编码器实现](https://github.com/czczup/ViT-Adapter/blob/fd64a5190f9f4530e8e5961cc87b2a3ad591190b/segmentation/mmseg_custom/models/backbones/vit_adapter.py) | 建立外部空间先验并与 ViT 交互。 | 可借外部支路思路，直接套用会在编码器内部交换信息。 |
| [PointRend，CVPR 2020](https://openaccess.thecvf.com/content_CVPR_2020/html/Kirillov_PointRend_Image_Segmentation_As_Rendering_CVPR_2020_paper.html) | 粗预测结合特征的点级细化。 | 本项目 Stage39–43 已在 Swin 解码器开展多项对照。 |

官方仓库的已读版本和文件 SHA-256 见 source_manifest.json。论文只提供相关机制和对照方法，当前 MambaVision-S 项目的结论来自自己的实验。