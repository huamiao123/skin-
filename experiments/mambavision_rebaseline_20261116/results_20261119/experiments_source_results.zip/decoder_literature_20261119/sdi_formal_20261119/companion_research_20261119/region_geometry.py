"""Geometry and fixed-probability regional pooling on development images; diagnostics, no training or test."""
import sys,math,json
from pathlib import Path
import numpy as np
import torch
from concurrent.futures import ThreadPoolExecutor
from skimage.segmentation import slic
from frozen_probe import ROOT,setup,SEED,model_for,train
def equal_count_grid(k,h,w):
    nrows=max(1,round(math.sqrt(k)))
    cols=np.full(nrows,k//nrows,dtype=int);cols[:k%nrows]+=1
    yidx=np.minimum(np.arange(h)*nrows//h,nrows-1)
    off=np.r_[0,np.cumsum(cols)[:-1]]
    out=off[yidx,None]+np.arange(w)[None,:]*cols[yidx,None]//w
    assert len(np.unique(out))==k
    return out
def counts(seg,gt,p):
    n=np.bincount(seg.ravel());sy=np.bincount(seg.ravel(),weights=gt.ravel());sp=np.bincount(seg.ravel(),weights=p.ravel())
    piece=((sp/n)>=.5)[seg];orig=p>=.5
    return dict(minority=int(np.minimum(sy,n-sy).sum()),fixed=int(((orig!=gt)&(piece==gt)).sum()),broken=int(((orig==gt)&(piece!=gt)).sum()),pooled_err=int((piece!=gt).sum()))
def per(args):
    im,gt,p,sid=args
    region=slic(im,n_segments=128,compactness=10.,sigma=1.,max_num_iter=10,convert2lab=True,enforce_connectivity=True,start_label=0,channel_axis=-1)
    _,inv=np.unique(region,return_inverse=True);region=inv.reshape(gt.shape)
    k=region.max()+1
    grid=equal_count_grid(k,*gt.shape)
    return dict(id=sid,k=int(k),area=int(gt.size),base_err=int(((p>=.5)!=gt).sum()),**{f'{key}_{v}':int(z) for key,g in [('image',region),('grid',grid)] for v,z in counts(g,gt,p).items()})
@torch.inference_mode()
def main():
    setup(SEED);net=model_for('control').eval();data,_=train.reference.load_data()
    rows=[]
    with ThreadPoolExecutor(8) as pool:
        for ix in torch.arange(len(data.ids['val']),device='cuda').split(48):
            x,y=data.batch('val',ix)
            with torch.autocast('cuda',dtype=torch.bfloat16):p=net(x)['main'][:,0].float().sigmoid().cpu().numpy()
            rgb=data.images['val'][ix].permute(0,2,3,1).contiguous().cpu().numpy();assert rgb.dtype==np.uint8
            rows.extend(pool.map(per,zip(rgb,(y[:,0]>=.5).cpu().numpy(),p,[data.ids['val'][i] for i in ix.tolist()])))
    def avg(k):return float(np.mean([r[k] for r in rows]))
    report=dict(images=len(rows),target_superpixels=128,median_actual=float(np.median([r['k'] for r in rows])),mean_actual=avg('k'),frac_pixels_majority_oracle_error={k:avg(k+'_minority')/65536 for k in ('image','grid')},mean_pixel_error_change_from_pooling={k:avg(k+'_broken')-avg(k+'_fixed') for k in ('image','grid')},n_slic_lower_oracle_error=sum(r['image_minority']<r['grid_minority'] for r in rows),definition='true labels enter only diagnostic minority metric; predictions for pooling are unchanged weak2 model probabilities')
    train.write_rows(ROOT/'region_geometry_per_image.csv',rows);train.atomic_json(ROOT/'region_geometry.json',report);print(report)
if __name__=='__main__':main()
