"""Swap already trained native UPer64 and SDI decoders/encoders, with fixed development-only ensembles."""
import csv
import numpy as np
import torch
from analyze import HERE,SEED,setup,train,model_for,features,logits,blocks,at_quota,read,sha,fixed
from fit_sdi import build,REF,ROOT as SDIROOT
@torch.inference_mode()
def main():
    setup(SEED)
    receipt=read(SDIROOT/'runs/locked_before_test.json')['models']['add_42']
    assert sha(REF/'best.pth')==receipt['sha256']
    fixed(HERE/'decoder_protocol.json',dict(code=sha(HERE/'decoder_check.py'),weights=receipt['sha256'],split='same 762 validation inputs. No test inputs or new parameter fits',design='native/plain model and SDI model trained separately, same seed. Evaluate both decoder heads on either frozen encoder, and fixed 50/50 probability mean of SDI with either native-head output.'))
    n=model_for('control').eval();other=build('add',SEED).eval()
    other.load_state_dict(torch.load(REF/'best.pth',map_location='cpu',weights_only=False)['model'])
    with (REF/'best_validation.csv').open() as f:expected=list(csv.DictReader(f))
    data,_=train.reference.load_data()
    assert [r['id'] for r in expected]==data.ids['val']
    rows=[]
    for ix in torch.arange(len(expected),device='cuda').split(64):
        x,y=data.batch('val',ix);g=blocks(y>=.5)
        s=features(n,x);p=features(other,x)
        outputs={'SS':blocks(logits(n,s)).float().sigmoid(),'PP':blocks(logits(other,p)).float().sigmoid(),'SP':blocks(logits(other,s)).float().sigmoid(),'PS':blocks(logits(n,p)).float().sigmoid()}
        for k in ('PP','SP'):outputs['mean_SS_'+k]=.5*(outputs['SS']+outputs[k])
        truth=g.sum(-1);native=outputs['SS']>=.5;na=native.sum(-1)
        fields={}
        for k,v in outputs.items():
            pred=v>=.5;cnt=pred.sum(-1);fp=(pred&~g).sum((-1,-2));fn=(~pred&g).sum((-1,-2));tp=(pred&g).sum((-1,-2))
            fields[k+'_err']=fp+fn;fields[k+'_fp']=fp;fields[k+'_fn']=fn
            fields[k+'_dice']=2*tp.double()/(2*tp+fp+fn)
            fields[k+'_area']=(cnt-truth).double().abs().mean(-1)/1024
            diff=pred!=native
            fields[k+'_fix']=(diff&(pred==g)).sum((-1,-2));fields[k+'_harm']=(diff&(pred!=g)).sum((-1,-2))
            if k.startswith('mean_'):
                tp1=at_quota(outputs['SS'],g,cnt);tp2=at_quota(v,g,na)
                fields[k+'_Aorder']=(cnt+truth-2*tp1).sum(-1);fields[k+'_Acount']=(na+truth-2*tp2).sum(-1)
        fields={k:v.cpu().numpy() for k,v in fields.items()}
        for j,i in enumerate(ix.tolist()):
            row=dict(id=data.ids['val'][i],**{k:float(v[j]) for k,v in fields.items()})
            assert row['PP_fp']==int(expected[i]['fp']) and row['PP_fn']==int(expected[i]['fn'])
            rows.append(row)
    tab={k:np.array([r[k] for r in rows]) for k in rows[0] if k!='id'}
    baseline=tab['SS_err']
    assert baseline.sum()==read(HERE/'diagnosis.json')['pixels']['AA']['errors']
    res={}
    for k in outputs:
        e=tab[k+'_err'];d=tab[k+'_dice']-tab['SS_dice']
        res[k]=dict(total_errors=int(e.sum()),net_error_change=int((e-baseline).sum()),area_mae=float(tab[k+'_area'].mean()),fixed=int(tab[k+'_fix'].sum()),induced=int(tab[k+'_harm'].sum()),dice_better=int((d>0).sum()),dice_worse=int((d<0).sum()),internal_mean_dice_change=float(d.mean()))
        if k.startswith('mean_'):
            ac=tab[k+'_Aorder'];ca=tab[k+'_Acount']
            res[k].update(count_component=float(.5*(ac-baseline+e-ca).sum()),rank_component=float(.5*(ca-baseline+e-ac).sum()))
    train.write_rows(HERE/'decoder_per_image.csv',rows);train.atomic_json(HERE/'decoder_diagnosis.json',res);print(res)
if __name__=='__main__':main()
