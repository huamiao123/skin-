"""Frozen-model diagnosis. Both train and development only, full-resolution scoring within 32x32 cells."""
import json
import sys
from collections import defaultdict
from pathlib import Path
import numpy as np
import torch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from fit import ROOT,SEED,setup,model_for,fresh,load_side,features,logits,train,read,sha,fixed

def blocks(x):
    return x[:,0].reshape(-1,8,32,8,32).permute(0,1,3,2,4).reshape(-1,64,1024)

def at_quota(rank_scores,labels,quota):
    # Conditional expected true positives at uniform random tie breaks, never using GT to choose a pixel.
    k=quota.long()
    assert k.min()>=0 and k.max()<=1024
    t=torch.topk(rank_scores,1024,dim=-1,sorted=True).values.gather(-1,(k-1).clamp(min=0)[:,:,None])
    above=rank_scores>t
    same=rank_scores==t
    tied_to_pick=(k-above.sum(-1)).clamp_min(0)
    tp=(above&labels).sum(-1)+tied_to_pick.double()*(same&labels).sum(-1)/same.sum(-1)
    return torch.where(k==0,0.,tp)

def summarized(vals):
    return {k:float(v) for k,v in vals.items()}

@torch.inference_mode()
def main():
    setup(SEED)
    endpoint=ROOT/'resume.pth'
    assert read(ROOT/'RESULTS.json')['selected_epoch']=={'B':0,'C':0}
    cfg=dict(data='1886 training cases for one blend coefficient, 762 development cases for diagnostics; test split not used',
             source_sha=sha(HERE/'analyze.py'),epoch40_archive_sha=sha(endpoint),
             quota='8x8 disjoint 32x32 cells. Counts from GT for diagnostic oracle only. Other fractional counts nearest-integer. Uniform random tie break expected TP.',
             blending='fit one convex coefficient toward the C occupancy prediction from original binary-mask fraction by training MSE; no intercept, no dev search',
             replacement='2x2 of within-cell rankings and thresholded segmentation counts from A and C; count/ranking components average the two replacement orders on pixel error')
    fixed(HERE/'protocol.json',cfg)
    data,_=train.reference.load_data();base=model_for('control').eval();net=fresh().eval()
    end=torch.load(endpoint,map_location='cpu',weights_only=False);assert len(end['history'])==40
    load_side(net,end['current']['C']);del end
    h=net.probe.decode_head;h.capture=True
    def forward(split):
        for ix in torch.arange(len(data.ids[split]),device='cuda').split(64):
            x,y=data.batch(split,ix);gt=blocks(y>=.5)
            fs=features(base,x)
            a=blocks(logits(base,fs).float())
            c=blocks(logits(net,fs).float())
            q=h.occupancy.float().sigmoid().reshape(-1,64).double()
            yield ix,a,c,gt,q
    num=den=0.
    for _,a,c,g,q in forward('train'):
        a=(a.sigmoid()>=.5).double().mean(-1);truth=g.double().mean(-1)
        delta=q-a;num+=float((delta*(truth-a)).sum());den+=float(delta.square().sum())
    alpha=float(np.clip(num/den,0.,1.))
    fixed(HERE/'train_blend.json',dict(n=len(data.ids['train']),alpha=alpha,unclipped=num/den))
    rows=[];parts=defaultdict(lambda:defaultdict(float));strata=defaultdict(lambda:defaultdict(float))
    for ix,z,w,g,q in forward('val'):
        pa,pw=z.sigmoid(),w.sigmoid()
        a,c=pa>=.5,pw>=.5
        na,nc,gt=a.sum(-1),c.sum(-1),g.sum(-1)
        m=na.double()/1024;frac=gt.double()/1024;soft=pa.double().mean(-1)
        mix=m+(q-m)*alpha
        raw={'A_hard':m,'A_soft':soft,'C_aux':q,'C_seg_hard':nc.double()/1024,'blend':mix}
        strata_masks={'all':gt>=0,'empty':gt==0,'full':gt==1024,'mixed':(gt>0)&(gt<1024),'A_error_ge10pp':(m-frac).abs()>=.1}
        for key,mask in strata_masks.items():
            d=strata[key];d['n']+=int(mask.sum())
            for name,r in raw.items():
                d[name+'_abs']+=float((r-frac).abs()[mask].sum());d[name+'_bias']+=float((r-frac)[mask].sum())
        quotas={'a':na,'c':nc,'gt':gt,'head':torch.round(1024*q),'soft':torch.round(1024*soft),'blend':torch.round(1024*mix)}
        measures={}
        for label,rank,key in [('AA',z,'a'),('AC',z,'c'),('CA',w,'a'),('CC',w,'c'),('A_truth',z,'gt'),('C_truth',w,'gt'),('A_head',z,'head'),('A_soft',z,'soft'),('A_blend',z,'blend')]:
            k=quotas[key].long()
            tp=at_quota(rank,g,k);fp=k-tp;fn=gt-tp;err=fp+fn
            measures[label]=err
            if label=='AA':assert torch.equal(tp,(a&g).sum(-1).double())
            if label=='CC':assert torch.equal(tp,(c&g).sum(-1).double())
            sums=parts[label];sums['fp']+=float(fp.sum());sums['fn']+=float(fn.sum());sums['errors']+=float(err.sum())
            sums['pure_errors']+=float(err[(gt==0)|(gt==1024)].sum());sums['mixed_errors']+=float(err[(gt>0)&(gt<1024)].sum())
        fields={k:v.sum(-1).cpu().numpy() for k,v in measures.items()}
        floor=(na-gt).abs();parts['floor']['baseline_count_lower_bound']+=float(floor.sum())
        parts['direct']['fixed']+=int(((a!=c)&(c==g)).sum());parts['direct']['induced']+=int(((a!=c)&(c!=g)).sum())
        for j,i in enumerate(ix.tolist()):rows.append(dict(id=data.ids['val'][i],**{k:float(v[j]) for k,v in fields.items()}))
    assert len(rows)==762
    assert parts['direct']=={'fixed':193270.,'induced':342435.}
    expected=read(ROOT/'final_update_dev.json')['occupancy_mae_C']['final']
    assert abs(strata['all']['C_aux_abs']/strata['all']['n']-expected)<1e-6
    e={k:v['errors'] for k,v in parts.items() if 'errors' in v}
    count=.5*((e['AC']-e['AA'])+(e['CC']-e['CA']))
    ranking=.5*((e['CA']-e['AA'])+(e['CC']-e['AC']))
    assert abs(count+ranking-e['CC']+e['AA'])<1e-7
    grp={k:{f:(v if f=='n' else v/d['n']) for f,v in d.items()} for k,d in strata.items()}
    changes={k:dict(better=int(sum(r[k]<r['AA']-1e-7 for r in rows)),worse=int(sum(r[k]>r['AA']+1e-7 for r in rows)),net_error_change=v-e['AA']) for k,v in e.items()}
    res=dict(n=len(rows),alpha=alpha,area_groups=grp,pixels=dict(parts),changes=changes,
             attribution=dict(count=count,rank=ranking,net=e['CC']-e['AA']),oracle_reduction_fraction=1-e['A_truth']/e['AA'])
    train.atomic_json(HERE/'diagnosis.json',res);train.write_rows(HERE/'paired_error_per_image.csv',rows)
    print('completed',res['n'],'images, alpha',alpha,'attribution',res['attribution'])
if __name__=='__main__':main()
