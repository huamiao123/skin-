"""Matched F4-side-branch training with a strictly frozen MambaVision-S/SDI."""
import csv
import fcntl
import hashlib
import math
import sys
import time
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
from occupancy_sdi import OccupancySDI,segmentation_loss
from frozen_probe import SEED,START,model_for,setup,sha,train
from fit_sdi import fixed,read
WEIGHTS={'B':0.0,'C':0.2}
EPOCHS=40
BATCH=64
def module_fingerprint(module):
    h=hashlib.sha256()
    for k,v in module.state_dict().items():
        h.update(k.encode());h.update(v.detach().contiguous().cpu().numpy().tobytes())
    return h.hexdigest()
def fresh():
    n=model_for('control').eval().requires_grad_(False)
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(17211)
        side=OccupancySDI(n.probe.decode_head).cuda()
    n.probe.decode_head=side
    return n.eval()
def side_state(n):
    s=n.probe.decode_head
    return {k:train.base.cpu_tree(getattr(s,k).state_dict()) for k in ('adapter','project','readout')}
def load_side(n,st):
    h=n.probe.decode_head
    for k,v in st.items():getattr(h,k).load_state_dict(v)
def features(n,x):
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
        f1,f2,mid=n.prefix(x)
        return [f1,f2,*n.suffix(mid)]
def logits(n,feat):
    with torch.autocast('cuda',dtype=torch.bfloat16):
        return n.probe(feat,(256,256))['main']
def batches(data):
    result=[]
    for ids in torch.arange(len(data.ids['val']),device='cuda').split(BATCH):
        x,y=data.batch('val',ids)
        result.append((features(data._reference_encoder,x),y))
    return result
def image_dice(z,y):
    assert torch.isfinite(z).all()
    a=z[:,0].float().sigmoid()>=.5
    b=y[:,0]>=.5
    den=(a.sum((1,2))+b.sum((1,2)));tp=(a&b).sum((1,2))
    return torch.where(den>0,2*tp.double()/den,1.).cpu().numpy()
@torch.no_grad()
def validate(n,cache,aux=False):
    chunks=[];errors=[]
    if aux:n.probe.decode_head.capture=True
    for fs,y in cache:
        z=logits(n,fs)
        chunks.append(image_dice(z,y))
        if aux:
            target=F.avg_pool2d((y>=.5).float(),32,32)
            errors.append((n.probe.decode_head.occupancy.float().sigmoid()-target).abs().mean((1,2,3)).cpu().numpy())
    if aux:
        n.probe.decode_head.capture=False;n.probe.decode_head.occupancy=None
    return np.concatenate(chunks),float(np.concatenate(errors).mean()) if errors else None
def train_pair():
    setup(SEED)
    proto=dict(seed=SEED,epochs=EPOCHS,batch=BATCH,start=str(START),start_sha=sha(START),losses=WEIGHTS,
               model_src=sha(ROOT.parent/'occupancy_sdi.py'),fit_src=sha(ROOT/'fit.py'),score_src=sha(ROOT/'score.py'),
               initialization='CPU RNG fork seed 17211; zero branch output; all existing parameters and BN buffers frozen',
               optimizer='side branch only, AdamW lr=.001, wd=.01; cosine to 1% over 40 epochs; gradient norm clipped to 1',
               data='each arm uses the same augmented 1886 training cases, batch order and frozen features; geometry(40)...geometry(79); 762 development examples',
               selection='highest per-image foreground Dice over epochs 0..40, earliest tie; select each arm independently before test',
               evaluation='867 prior held-out ISIC cases, threshold 0.5. Paired C-B, C-A and B-A. Existing 814-case group sensitivity. No test selection.')
    assert proto['start_sha']=='2ff5042a748e9402a39acea84171597879e7d3d4e9eb55389fe5e7929570871f'
    fixed(ROOT/'protocol.json',proto)
    if (ROOT/'locked.json').exists():return
    original=model_for('control').eval().requires_grad_(False)
    nets={k:fresh() for k in WEIGHTS}
    optim={k:torch.optim.AdamW([p for p in n.parameters() if p.requires_grad],lr=.001,weight_decay=.01) for k,n in nets.items()}
    assert all(sum(p.numel() for p in n.parameters() if p.requires_grad)==133569 for n in nets.values())
    part=lambda n: (n.encoder,n.probe.decode_head.base)
    original_hashes=[module_fingerprint(m) for m in (original.encoder,original.probe.decode_head)]
    for n in nets.values():
        assert [module_fingerprint(m) for m in part(n)]==original_hashes
        assert all(not m.training for m in n.modules())
    for name,m in side_state(nets['B']).items():
        assert all(torch.equal(w,side_state(nets['C'])[name][k]) for k,w in m.items())
    data,_=train.reference.load_data();data.seed=SEED;data._reference_encoder=original
    assert len(data.ids['train'])==1886 and len(data.ids['val'])==762
    val=batches(data)
    init,_=validate(original,val)
    init_score=float(init.mean())
    historic=read(ROOT.parent.parent/'shallow_bypass_20261119/bn_factorial_dev.json')['dev']['original_weights_original_bn']
    assert abs(init_score-historic)<1e-5,(init_score,historic)
    areas={}
    for k,n in nets.items():
        rep,mae=validate(n,val,aux=True);areas[k]=mae
        assert np.array_equal(rep,init)
    fixed(ROOT/'initial.json',dict(n=762,frozen_hashes=original_hashes,initial_equal=True,prior_dev_replay_difference=init_score-historic,initial_area_mae=areas))
    rng=ROOT/'resume.pth'
    history=[];best={};best_scores={k:init_score for k in nets};epochs={k:0 for k in nets}
    if rng.exists():
        st=torch.load(rng,map_location='cpu',weights_only=False)
        assert st['protocol']==sha(ROOT/'protocol.json')
        history=st['history'];best=st['best'];best_scores=st['best_scores'];epochs=st['epochs']
        for k,n in nets.items():load_side(n,st['current'][k]);optim[k].load_state_dict(st['optimizer'][k])
        train.restore_rng(st['rng']);del st
    else:
        best={k:side_state(n) for k,n in nets.items()}
    for ep in range(len(history)+1,EPOCHS+1):
        ts=time.monotonic();order,geo=data.geometry(39+ep)
        assert len(torch.unique(order))==1886
        lr=.001*(.01+.99*(1+math.cos(math.pi*(ep-1)/EPOCHS))/2)
        for o in optim.values():o.param_groups[0]['lr']=lr
        losses={k:0. for k in nets}
        for i,ids in enumerate(order.split(BATCH)):
            x,y=data.batch('train',ids,geo);fs=features(original,x)
            target=F.avg_pool2d((y>=.5).float(),32,32)
            for k,n in nets.items():
                o=optim[k];o.zero_grad(set_to_none=True);h=n.probe.decode_head;h.capture=bool(WEIGHTS[k])
                z=logits(n,fs);loss=segmentation_loss(z,y)
                if h.capture:loss=loss+WEIGHTS[k]*F.binary_cross_entropy_with_logits(h.occupancy.float(),target)
                loss.backward()
                norm=nn.utils.clip_grad_norm_(o.param_groups[0]['params'],1.,error_if_nonfinite=True)
                if ep==1 and i==0:assert norm>0 and all(p.grad is None for p in n.encoder.parameters())
                o.step();losses[k]+=float(loss.detach())*len(ids)
                h.capture=False;h.occupancy=None
        record={'epoch':ep,'seconds':0,'learning_rate':lr}
        for k,n in nets.items():
            v,mae=validate(n,val,aux=k=='C');score=float(v.mean())
            record[k]=dict(score=score,loss=losses[k]/1886,occupancy_mae=mae)
            if score>best_scores[k]:
                best[k]=side_state(n);best_scores[k]=score;epochs[k]=ep
        record['seconds']=round(time.monotonic()-ts,2);history.append(record)
        train.atomic_save(rng,dict(protocol=sha(ROOT/'protocol.json'),current={k:side_state(n) for k,n in nets.items()},optimizer={k:train.base.cpu_tree(o.state_dict()) for k,o in optim.items()},rng=train.rng_state(),best=best,best_scores=best_scores,epochs=epochs,history=history))
        train.atomic_json(ROOT/'history.json',history)
        print('paired epoch',ep,'seconds',record['seconds'],'best epochs',epochs,flush=True)
    locked={}
    for k,n in nets.items():
        assert [module_fingerprint(m) for m in part(n)]==original_hashes
        load_side(n,best[k]);v,mae=validate(n,val,aux=k=='C')
        assert float(v.mean())==best_scores[k]
        path=ROOT/(k+'_best.pth');train.atomic_save(path,dict(branch=best[k],epoch=epochs[k],source=proto['start_sha'],protocol=sha(ROOT/'protocol.json')))
        locked[k]=dict(epoch=epochs[k],sha256=sha(path),score=best_scores[k],mae=mae)
    fixed(ROOT/'locked.json',dict(branches=locked,protocol=sha(ROOT/'protocol.json'),base=proto['start_sha'],frozen_verified=True))
    print('locked both final checkpoints',flush=True)
if __name__=='__main__':
    with (ROOT/'fit.lock').open('a') as l:
        fcntl.flock(l,fcntl.LOCK_EX|fcntl.LOCK_NB);train_pair()
