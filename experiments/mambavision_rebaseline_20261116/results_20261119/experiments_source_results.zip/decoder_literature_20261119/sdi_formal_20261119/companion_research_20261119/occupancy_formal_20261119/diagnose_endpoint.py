"""Development-only check on the actual final update, even if epoch zero was selected."""
from fit import ROOT,SEED,setup,train,model_for,fresh,load_side,features,logits,read,sha
import torch
@torch.inference_mode()
def main():
    setup(SEED);data,_=train.reference.load_data()
    base=model_for('control').eval();nets={k:fresh().eval() for k in ('B','C')}
    actual={k:fresh().eval() for k in nets}
    end=torch.load(ROOT/'resume.pth',map_location='cpu',weights_only=False)
    assert len(end['history'])==40 and end['protocol']==sha(ROOT/'protocol.json')
    for k,n in actual.items():load_side(n,end['current'][k])
    totals={k:dict(corrected=0,induced=0,from_below_point1_to_foreground=0,changed_images=0) for k in nets}
    for ids in torch.arange(len(data.ids['val']),device='cuda').split(64):
        x,y=data.batch('val',ids);gt=y>=.5;fs=features(base,x);z=logits(base,fs);p=z.float().sigmoid();a=p>=.5
        for k,n in nets.items():
            assert torch.equal(z,logits(n,fs))
            b=logits(actual[k],fs).float().sigmoid()>=.5;change=a!=b
            tot=totals[k];tot['corrected']+=int((change&(b==gt)).sum());tot['induced']+=int((change&(b!=gt)).sum());tot['changed_images']+=int(change.flatten(1).any(1).sum());tot['from_below_point1_to_foreground']+=int((gt&(p<.1)&b).sum())
    init=read(ROOT/'initial.json')['initial_area_mae']['C'];last=end['history'][-1]['C']['occupancy_mae']
    record=dict(split='development',n=len(data.ids['val']),initial_logit_identity_verified_all=True,final_only=totals,occupancy_mae_C=dict(initial=init,final=last))
    train.atomic_json(ROOT/'final_update_dev.json',record);print(record)
if __name__=='__main__':main()
