"""Test once after both checkpoints have been locked; verify 867 historical per-image predictions."""
import csv
import json
from pathlib import Path
import numpy as np
import torch
from fit import ROOT,SEED,START,model_for,fresh,load_side,setup,train,sha,read,fixed
from test_bypass import test_inputs,score,GROUPS,REFERENCE
from score_sdi import paired

def main():
    locked=read(ROOT/'locked.json');proto=read(ROOT/'protocol.json')
    assert locked['protocol']==sha(ROOT/'protocol.json') and proto['score_src']==sha(ROOT/'score.py') and sha(START)==locked['base']
    assert len(read(ROOT/'history.json'))==40
    setup(SEED)
    partition=train.PROJECT/'stage45_upernet_decoder/identity_partition.json';part=read(partition);ids=part['splits']['test']
    group=read(GROUPS)['cases']['test']
    with REFERENCE.open() as stream:old=list(csv.DictReader(stream))
    assert ids==[r['id'] for r in old]==[r['id'] for r in group] and len(set(ids))==867
    fixed(ROOT/'test_protocol.json',dict(lock=sha(ROOT/'locked.json'),partition=sha(partition),cases=sha(GROUPS),reference=sha(REFERENCE),threshold=.5))
    x,y=test_inputs(part)
    base=model_for('control').eval();res={'A':score(base,x,y)}
    assert np.max(np.abs(res['A']-np.array([float(r['weak2']) for r in old])))<1e-12
    del base
    for k,rec in locked['branches'].items():
        path=ROOT/(k+'_best.pth');assert sha(path)==rec['sha256']
        st=torch.load(path,map_location='cpu',weights_only=False)
        assert st['source']==sha(START) and st['epoch']==rec['epoch'] and st['protocol']==sha(ROOT/'protocol.json')
        n=fresh();load_side(n,st['branch']);res[k]=score(n,x,y);del n
        if rec['epoch']==0:assert np.array_equal(res[k],res['A'])
    train.write_rows(ROOT/'test_per_image.csv',[dict(id=sid,group=group[i]['group'],retained=group[i]['retain'],**{k:float(v[i]) for k,v in res.items()}) for i,sid in enumerate(ids)])
    output={}
    for name,sel in [('all',np.ones(867,dtype=bool)),('filtered',np.array([g['retain'] for g in group]))]:
        assert sel.sum()==(867 if name=='all' else 814)
        groups=np.array([g['group'] for g in group])[sel]
        output[name]=dict(n=int(sel.sum()),per_image_dice={k:float(v[sel].mean()) for k,v in res.items()},paired={b+'-'+a:paired(res[a][sel],res[b][sel],groups) for a,b in [('A','B'),('A','C'),('B','C')]})
    train.atomic_json(ROOT/'RESULTS.json',dict(test=output,selected_epoch={k:v['epoch'] for k,v in locked['branches'].items()},historical_replay_cases=len(ids),frozen_verified=locked['frozen_verified']))
    print('test complete',output['all']['per_image_dice'],flush=True)
if __name__=='__main__':main()
