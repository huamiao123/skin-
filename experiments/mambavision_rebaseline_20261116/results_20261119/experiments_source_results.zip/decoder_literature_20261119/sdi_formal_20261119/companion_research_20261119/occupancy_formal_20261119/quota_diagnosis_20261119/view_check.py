"""Fixed development-only mirrored view. No trainable parameters or test data."""
import sys
from pathlib import Path
import numpy as np
import torch
from analyze import HERE,ROOT,SEED,setup,model_for,train,features,logits,blocks,at_quota,read,sha,fixed

@torch.inference_mode()
def main():
    setup(SEED);n=model_for('control').eval();data,_=train.reference.load_data()
    fixed(HERE/'view_protocol.json',dict(script=sha(HERE/'view_check.py'),model='original frozen weak2',split='development only',transform='one horizontal mirror, invert mask coordinates, equal probability arithmetic mean; original cutoff .5; no fitting',checks='area, FP/FN, within-cell quota swaps, grouped paired errors by cases as available'))
    records=[]
    for ix in torch.arange(len(data.ids['val']),device='cuda').split(64):
        x,y=data.batch('val',ix);labels=blocks(y>=.5)
        za=logits(n,features(n,x)).float()
        flipped=x.flip((-1,)).contiguous()
        zv=logits(n,features(n,flipped)).float().flip((-1,))
        pa,pv=blocks(za.sigmoid()),blocks(zv.sigmoid());pmean=.5*(pa+pv)
        assert torch.isfinite(pmean).all()
        native=pa>=.5;mir=pv>=.5;fused=pmean>=.5
        na=native.sum(-1);nf=fused.sum(-1);truth=labels.sum(-1)
        out={}
        for k,pred in [('native',native),('mirror',mir),('mean',fused)]:
            count=pred.sum(-1)
            fp=(pred&~labels).sum((-1,-2));fn=(~pred&labels).sum((-1,-2))
            out[k+'_fp']=fp;out[k+'_fn']=fn;out[k+'_error']=fp+fn
            den=count.sum(-1)+truth.sum(-1);hit=(pred&labels).sum((-1,-2))
            out[k+'_dice']=torch.where(den>0,2*hit.double()/den,1.)
            out[k+'_area_abs']=(count-truth).double().abs().mean(-1)/1024
        for k,rs,quota in [('native_rank_mean_count',pa,nf),('mean_rank_native_count',pmean,na)]:
            tp=at_quota(rs,labels,quota)
            out[k+'_error']=(quota+truth-2*tp).sum(-1)
        agree=native==mir
        out['disagreed']=(~agree).sum((-1,-2))
        out['all_wrong_both']=(agree&(native!=labels)).sum((-1,-2))
        out['mean_fixed']=((native!=fused)&(fused==labels)).sum((-1,-2))
        out['mean_induced']=((native!=fused)&(fused!=labels)).sum((-1,-2))
        vals={k:v.cpu().numpy() for k,v in out.items()}
        for j,i in enumerate(ix.tolist()):records.append(dict(id=data.ids['val'][i],**{k:float(v[j]) for k,v in vals.items()}))
    assert len(records)==762
    fields={k:np.array([r[k] for r in records]) for k in records[0] if k!='id'}
    baseline=read(HERE/'diagnosis.json')
    assert fields['native_error'].sum()==baseline['pixels']['AA']['errors']
    def direction(d,tol=1e-10):return dict(lower=int((d < -tol).sum()),higher=int((d>tol).sum()),unchanged=int((np.abs(d)<=tol).sum()))
    res={'n':len(records),'metrics':{},'mean_fixed':int(fields['mean_fixed'].sum()),'mean_induced':int(fields['mean_induced'].sum()),'disagreed':int(fields['disagreed'].sum()),'joint_wrong':int(fields['all_wrong_both'].sum())}
    for k in ('native','mirror','mean'):
        error=fields[k+'_error'];d=fields[k+'_dice']-fields['native_dice']
        res['metrics'][k]=dict(fp=int(fields[k+'_fp'].sum()),fn=int(fields[k+'_fn'].sum()),pixel_errors=int(error.sum()),area_mae=float(fields[k+'_area_abs'].mean()),error_vs_native=direction(error-fields['native_error']),dice_vs_native=direction(d),internal_mean_dice_difference=float(d.mean()))
    aa=fields['native_error'];ac=fields['native_rank_mean_count_error'];ca=fields['mean_rank_native_count_error'];cc=fields['mean_error']
    res['error_components_mu']=dict(count=float(.5*(ac-aa+cc-ca).sum()),rank=float(.5*(ca-aa+cc-ac).sum()))
    train.atomic_json(HERE/'view_diagnosis.json',res);train.write_rows(HERE/'view_per_image.csv',records)
    print(res)
if __name__=='__main__':main()
