from frozen_probe import *
@torch.inference_mode()
def run():
    setup(SEED);net=model_for('control').eval();data,_=train.reference.load_data()
    names=['F1','F2','F3','F4'];acc={k:[[],[]] for k in names};loc=torch.zeros((16,16),device='cuda')
    def pool(x):return F.avg_pool2d(x[:,None].float(),16,16)[:,0]
    def batches(split):
        for ix in torch.arange(len(data.ids[split]),device='cuda').split(48):
            x,y=data.batch(split,ix); yield ix,x,y[:,0]>=.5
    for ix,x,g in batches('train'):
        features,_=get_features(net,x);occ=pool(g);loc+=occ.sum(0)
        for k,v in features.items():
            z=F.normalize(v,dim=1)
            for i,mask in enumerate([occ<=.1,occ>=.9]):
                c=mask.sum((1,2));a=(z*mask[:,None]).sum((2,3))/c.clamp_min(1)[:,None];acc[k][i].append(a[c>0].cpu())
    dirs={}
    for k,(bg,fg) in acc.items():dirs[k]=(F.normalize(torch.cat(fg).mean(0),dim=0)-F.normalize(torch.cat(bg).mean(0),dim=0)).cuda()
    loc=loc.cpu().numpy()/len(data.ids['train'])
    yy,xx=np.mgrid[:16,:16];ring=np.floor(np.hypot(yy-7.5,xx-7.5)/2).astype(int)
    records=[]
    with ThreadPoolExecutor(6) as executor:
        for ix,x,g in batches('val'):
            feat,p=get_features(net,x)
            deep=g&(torch.as_tensor(np.stack(list(executor.map(distance_transform_edt,g.cpu().numpy()))),device=g.device)>8)
            occ=pool(g);miss=((occ>=.9)&(pool(deep&(p<.1))>=.25)).cpu().numpy();bg=(occ<=.1).cpu().numpy()
            meanp=pool(p).cpu().numpy();rank={k:(F.normalize(v,dim=1)*dirs[k][None,:,None,None]).sum(1).cpu().numpy() for k,v in feat.items()}
            for j,i in enumerate(ix.tolist()):
                if not miss[j].any() or not bg[j].any():continue
                bucket=np.digitize(meanp[j],[.01,.05,.1,.25,.5])
                a,b=np.where((miss[j].ravel()[:,None]&bg[j].ravel()[None,:])&(ring.ravel()[:,None]==ring.ravel()[None,:])&(bucket.ravel()[:,None]==bucket.ravel()[None,:]))
                if not len(a):continue
                scores={**{k:v[j] for k,v in rank.items()},'position_prior':loc,'base_mask_probability':meanp[j]}
                def concord(s):
                    v=s.ravel()[a]-s.ravel()[b];return float((np.sum(v>0)+.5*np.sum(v==0))/len(a))
                records.append(dict(id=data.ids['val'][i],pairs=len(a),**{k:concord(v) for k,v in scores.items()}))
    keys=names+['position_prior','base_mask_probability'];values={k:np.array([r[k] for r in records]) for k in keys}
    rng=np.random.default_rng(42);idx=rng.integers(0,len(records),(3000,len(records)))
    dif=values['F4']-values['base_mask_probability']
    result=dict(images=len(records),pairs=sum(r['pairs'] for r in records),metric='within-image same 2-cell radius ring and same bin of original mean cell foreground probability; image-weighted pair concordance; no test accessed',averages={k:float(v.mean()) for k,v in values.items()},F4_minus_sdi95_descriptive=np.quantile(dif[idx].mean(1),[.025,.975]).tolist())
    train.write_rows(ROOT/'matched_probe_per_image.csv',records);train.atomic_json(ROOT/'matched_probe.json',result);print(result)
if __name__=='__main__':run()
