"""Scientific figures of measured intermediate activations and direct prediction changes."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,colors
from matplotlib.cm import ScalarMappable
from PIL import Image
ROOT=Path(__file__).resolve().parent
cache=Path('/tmp/mv_sdi_features_20261119')
font=cache/'fonts/NotoSansCJKsc-Regular.otf'
font_manager.fontManager.addfont(str(font))
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=str(font)).get_name(),'font.size':10,'axes.unicode_minus':False,'figure.facecolor':'#f8f9f6','savefig.facecolor':'#f8f9f6','text.color':'#192c31','axes.titlecolor':'#192c31'})
cases=['help_example','hurt_example','prior_case']
titles=['分支净纠正','分支净损害','此前的大面积漏分']
def load(case):
    with np.load(cache/(case+'_product.npz')) as z:return {k:z[k] for k in z}
zs=[load(c) for c in cases]
box=(-.5,255.5,255.5,-.5)
def show(ax,x,**opts):
    im=ax.imshow(x,origin='upper',extent=box,interpolation='nearest',**opts)
    ax.set(xlim=(-.5,255.5),ylim=(255.5,-.5),xticks=[],yticks=[])
    for v in ax.spines.values():v.set_visible(False)
    return im
def outline(ax,g,col):
    if np.any(g) and not g.all():
        yy,xx=np.mgrid[-1:257,-1:257]
        ax.contour(xx,yy,np.pad(g.astype(float),1),levels=[.5],colors=[col],linewidths=.9)
def bar(fig,im,x,y,w,left,right):
    bx=fig.add_axes([x,y,w,.012]);b=fig.colorbar(im,cax=bx,orientation='horizontal')
    b.outline.set_visible(False);b.set_ticks([im.norm.vmin,im.norm.vmax]);b.set_ticklabels([left,right]);bx.tick_params(labelsize=9,length=2,pad=1)
def common_limit(key):
    return max(1,int(np.ceil(np.quantile(np.concatenate([a[key].ravel() for a in zs]),.99))))
def save(fig,name):
    p=ROOT/name;fig.savefig(p,dpi=152);plt.close(fig)
    with Image.open(p) as im:im.verify()
def figure_cases():
    fig=plt.figure(figsize=(15.7,10.3))
    fig.text(.034,.96,'四尺度 SDI 在哪里改变了分割？',fontsize=24,weight='bold')
    fig.text(.035,.921,'同一份第 39 轮权重，同一张真实图。开关只作用于 F2 的 64 通道残差。前两例从净纠正与净损害病例中分别选取。',fontsize=12)
    labs=['输入图与真实标注','四路乘积的强度','加回 F2 的残差强度','开启分支后前景概率变化','开启分支后的像素翻转']
    lefts=[.082,.265,.448,.631,.814];width=.157;ys=[.635,.380,.125]
    for x,lab in zip(lefts,labs):fig.text(x+width/2,.877,lab,ha='center',fontsize=13,weight='bold')
    mx1=common_limit('joint_rms');mx2=common_limit('delta_rms');diffmax=.65
    colorbars={}
    for j,(title,z) in enumerate(zip(titles,zs)):
        y=ys[j];rgb=z['rgb'];g=z['gt'];a=z['pred']>=.5;b=z['off']>=.5
        fix=(a!=b)&(a==g);bad=(a!=b)&(a!=g)
        fig.text(.015,y+.128,title,fontsize=10,va='center',rotation=90)
        axes=[fig.add_axes([x,y,width,.226]) for x in lefts]
        show(axes[0],rgb);outline(axes[0],g,'#00ffbb')
        fig.text(lefts[0]+width/2,y-.015,str(z['public_id']),ha='center',fontsize=10)
        colorbars[1]=show(axes[1],z['joint_rms'],cmap='magma',vmin=0,vmax=mx1)
        colorbars[2]=show(axes[2],z['delta_rms'],cmap='magma',vmin=0,vmax=mx2)
        colorbars[3]=show(axes[3],z['pred']-z['off'],cmap='RdBu_r',vmin=-diffmax,vmax=diffmax)
        for ax in axes[1:4]:outline(ax,g,'#68bba1')
        gray=(rgb.astype(float)/255.)@np.array([.299,.587,.114])
        bg=np.broadcast_to((.13+.42*gray)[:,:,None],rgb.shape).copy()
        bg[fix]=[.0,.91,.70];bg[bad]=[1.,.33,.47]
        show(axes[4],bg)
        fig.text(lefts[4]+width/2,y-.015,f'纠正 {fix.sum():,}　引入错误 {bad.sum():,}',ha='center',fontsize=10)
    bar(fig,colorbars[1],lefts[1]+.015,.075,width-.03,'0',str(mx1))
    bar(fig,colorbars[2],lefts[2]+.015,.075,width-.03,'0',str(mx2))
    bar(fig,colorbars[3],lefts[3]+.015,.075,width-.03,'−0.65','+0.65')
    fig.text(.034,.020,'绿色细线为真实标注。两列强度均为跨 64 通道的均方根，热图保持 32 × 32 网格，各列在三例间共用色标。概率变化 = 开启 − 关闭；右列绿色为纠正，红色为新增错误。',fontsize=10)
    save(fig,'case_maps.png')
def figure_signed():
    fig=plt.figure(figsize=(14.5,7.15))
    fig.text(.035,.935,'逐通道看乘法：四张同位置的特征如何变成一张',fontsize=22,weight='bold')
    fig.text(.035,.876,'下图取整批开发图中乘积平方和最高的同一通道（索引 42），显示带符号激活。最后一列为前四列逐元素相乘后的实际输出。',fontsize=11)
    ls=[.055,.246,.437,.628,.819];w=.158;ys=[.48,.13]
    blocks=zs[:2];kys=['f1_signed','f2_signed','f3_signed','f4_signed','joint_signed']
    vals=np.concatenate([abs(z[k]).ravel() for z in blocks for k in kys[:4]])
    vmax=max(1,int(np.ceil(np.quantile(vals,.99))))
    jmax=max(1,int(np.ceil(np.quantile(np.concatenate([abs(z[kys[-1]]).ravel() for z in blocks]),.99))))
    for i,(x,t) in enumerate(zip(ls,['F1 · 浅层','F2','F3','F4 · 深层','F1 × F2 × F3 × F4'])):
        fig.text(x+w/2,.814,t,ha='center',fontsize=13,weight='bold')
    for j,z in enumerate(blocks):
        for i,(x,k) in enumerate(zip(ls,kys)):
            ax=fig.add_axes([x,ys[j],w,.315]);lim=jmax if i==4 else vmax
            show(ax,z[k],cmap='RdBu_r',vmin=-lim,vmax=lim);outline(ax,z['gt'],'#54af96')
        fig.text(.012,ys[j]+.15,str(z['public_id']),rotation=90,fontsize=10,ha='center',va='center')
    fig.text(.04,.047,f'蓝为负，红为正，白色接近零。四个输入共用 [−{vmax}, {vmax}] 色标；乘积使用 [−{jmax}, {jmax}] 色标以保留对比。超出显示范围的值只在绘图时截色。',fontsize=11)
    save(fig,'signed_factors.png')
figure_cases();figure_signed()
