"""Observe trained SDI activations; all interventions keep weights and inputs fixed."""
from pathlib import Path
import csv
import json
import math
import sys
import time
import numpy as np
import torch
from torch.nn import functional as F

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
from fit_sdi import build,setup,train,sha
SCRATCH=Path('/tmp/mv_sdi_features_20261119')
SCRATCH.mkdir(exist_ok=True)
MODES=('off','half','cap95','energy_matched')
def load_ck(arm):
    run=ROOT.parent/'runs'/(arm+'_42')
    ref=json.loads((ROOT.parent/'runs/locked_before_test.json').read_text())['models'][arm+'_42']
    assert sha(run/'best.pth')==ref['sha256']
    m=build(arm,42).eval()
    state=torch.load(run/'best.pth',map_location='cpu',weights_only=False)
    assert state['epoch']==ref['epoch']==39
    m.load_state_dict(state['model'])
    return m,ref
def single_pass(m,feat,mode=None):
    head=m.probe.decode_head
    buf={};handles=[]
    def save(k):
        def capture(layer,args,out):
            buf[k]=out
        return capture
    def before(k):
        def capture(layer,args):
            buf[k]=args[0]
        return capture
    def intervene(layer,args,out):
        if mode=='off':return torch.zeros_like(out)
        if mode=='half':return .5*out
        a=out.float()
        energy=a.square().mean(1,keepdim=True)
        mag=energy.sqrt()
        q=torch.quantile(mag.flatten(1),.95,dim=1)[:,None,None,None]
        scale=(q/mag.clamp_min(1e-12)).clamp(max=1)
        if mode=='energy_matched':
            scale=((scale.square()*energy).sum((1,2,3))/energy.sum((1,2,3)).clamp_min(1e-12)).sqrt()[:,None,None,None]
        return (a*scale).to(out.dtype)
    if mode is None:
        for i,conv in enumerate(head.sdi.convs):
            handles.append(conv.register_forward_hook(save('f'+str(i+1))))
        handles.extend([head.out.register_forward_pre_hook(before('joint')),head.out.register_forward_hook(save('delta'))])
    else:
        handles.append(head.out.register_forward_hook(intervene))
    if mode in ('off',None):
        handles.append(head.head.fpn_convs[1].register_forward_pre_hook(before('t2')))
    try:
        with torch.autocast('cuda',dtype=torch.bfloat16):
            z=m.probe(feat,(256,256))['main'][:,0].float()
    finally:
        for handle in handles:handle.remove()
    assert torch.isfinite(z).all() and all(torch.isfinite(x).all() for x in buf.values())
    return z.sigmoid(),buf
def compare(a,b,gt):
    # positive correction means enabling a fixes a prediction made by b.
    aa=a>=.5;bb=b>=.5
    dims=(1,2)
    return dict(rescued_fn=(aa&~bb&gt).sum(dims),added_fp=(aa&~bb&~gt).sum(dims),
                fixed_fp=(~aa&bb&~gt).sum(dims),added_fn=(~aa&bb&gt).sum(dims),
                pixels_p_change_gt05=((a-b).abs()>.05).sum(dims),
                mean_abs_p_change=(a-b).abs().mean(dims))
def put(arr,k,value):
    arr[k]=value.detach().double().cpu().numpy()
def top_energy(a,k=11):
    energy=a.float().square().mean(1).flatten(1)
    return torch.topk(energy,k,dim=1).values.sum(1)/energy.sum(1).clamp_min(1e-30)
def std_rms(x):
    return x.float().square().mean((1,2,3)).sqrt()
def metrics(arm,buf,off,xs,gt):
    arr={};delta=buf['delta'].float()
    for k in [*['f'+str(j) for j in range(1,5)],'joint','delta']:
        a=buf[k].float()
        put(arr,k+'_rms',std_rms(a));put(arr,k+'_top11_of_1024_energy',top_energy(a))
    put(arr,'rms_delta_over_t2',std_rms(delta)/std_rms(off['t2']).clamp_min(1e-12))
    put(arr,'joint_exact_zero',(buf['joint']==0).float().mean((1,2,3)))
    put(arr,'gt_pixels',gt.sum((1,2)))
    energy=delta.square().mean(1)
    frame=torch.zeros_like(energy[:1],dtype=torch.bool)
    frame[:,:2,:]=True;frame[:,-2:,:]=True;frame[:,:,:2]=True;frame[:,:,-2:]=True
    put(arr,'delta_energy_frame2',(energy*frame).sum((1,2))/energy.sum((1,2)).clamp_min(1e-25))
    lesion=F.avg_pool2d(gt[:,None].float(),8,8)[:,0]
    put(arr,'delta_energy_gt_fraction',(energy*lesion).sum((1,2))/energy.sum((1,2)).clamp_min(1e-25))
    es=delta.square().sum((2,3))
    put(arr,'delta_largest_channel_energy',es.max(1).values/es.sum(1).clamp_min(1e-25))
    put(arr,'p_mean_native',xs['native'].mean((1,2)))
    for mode in MODES:
        for k,v in compare(xs['native'],xs[mode],gt).items():put(arr,mode+'_'+k,v)
    return arr
def features(cache,sl,m):
    with torch.autocast('cuda',dtype=torch.bfloat16):
        return [cache['features'][0][sl],cache['features'][1][sl],*m.suffix(cache['mid'][sl])]
def metadata():
    p=train.PROJECT
    mfile=ROOT.parents[2]/'diagnostics/stageC_20261117/data_provenance/BICUBIC_MASK_ID_MAPPING.json'
    return {r['id']:r['official_matches'][0]['official_id'] for r in json.loads(mfile.read_text()) if r['split']=='val'}
def select(rows):
    net=np.array([(r['off_rescued_fn']+r['off_fixed_fp']-r['off_added_fn']-r['off_added_fp'])/max(1,r['gt_pixels']) for r in rows])
    flips=np.array([r['off_rescued_fn']+r['off_fixed_fp']+r['off_added_fn']+r['off_added_fp'] for r in rows])
    ratio=np.array([r['rms_delta_over_t2'] for r in rows])
    good=np.flatnonzero((net>0)&(flips>=32));bad=np.flatnonzero((net<0)&(flips>=32))
    picks={'helped':int(good[np.argmax(net[good])]),'hurt':int(bad[np.argmin(net[bad])]),
           'typical':int(np.argmin(abs(ratio-np.median(ratio))))}
    if '126' in [r['id'] for r in rows]:picks['prior_case']=next(i for i,r in enumerate(rows) if r['id']=='126')
    return picks

def capture_cases(arm,m,cache,data,rows,selected,top_channel):
    ids=data.ids['val']
    for case,ix in selected.items():
        start=64*(ix//64);sl=slice(start,start+64);j=ix-start
        feat=features(cache,sl,m)
        native,buf=single_pass(m,feat)
        off,_=single_pass(m,feat,'off')
        ck=lambda t:t.detach().float().cpu().numpy()
        obj=dict(rgb=data.images['val'][ix].permute(1,2,0).cpu().numpy(),gt=(cache['target'][ix,0]>=.5).cpu().numpy(),
                 pred=ck(native[j]),off=ck(off[j]),sid=ids[ix],public_id=rows[ix]['isic'],channel=top_channel)
        for key,x in buf.items():
            a=x[j].float();obj[key+'_rms']=ck(a.square().mean(0).sqrt());obj[key+'_signed']=ck(a[top_channel])
        np.savez_compressed(SCRATCH/f'{case}_{arm}.npz',**obj)

@torch.inference_mode()
def main():
    setup(42);data,_=train.reference.load_data();ids=data.ids['val'];assert len(ids)==762
    cache=train.reference.cache_new(len(ids));mp=metadata()
    summary={};selected=None
    for arm in ['product','mean']:
        tic=time.monotonic()
        model,ref=load_ck(arm);train.reference.fill_cache(model,data,'val',cache)
        saved=list(csv.DictReader((ROOT.parent/'runs'/(arm+'_42')/'best_validation.csv').open()));assert ids==[r['id'] for r in saved]
        rows=[];ce=torch.zeros(64,dtype=torch.float64,device='cuda')
        for start in range(0,len(ids),64):
            sl=slice(start,start+64);gt=cache['target'][sl,0]>=.5
            feat=features(cache,sl,model);on,buf=single_pass(model,feat)
            factors=[buf['f'+str(j)] for j in range(1,5)]
            if arm=='product':manual=factors[0]*factors[1]*factors[2]*factors[3]
            else:manual=torch.stack(factors).mean(0)
            assert torch.equal(manual,buf['joint'])
            xs={'native':on}
            for mode in MODES:
                prob,inter=single_pass(model,feat,mode);xs[mode]=prob
                if mode=='off':baseline=inter
            assert torch.equal(baseline['t2']+buf['delta'],buf['t2'])
            a=metrics(arm,buf,baseline,xs,gt)
            ce+=buf['joint'].float().square().sum((0,2,3)).double()
            pred=on>=.5
            counts=torch.stack([(pred&gt).sum((1,2)),(pred&~gt).sum((1,2)),(~pred&gt).sum((1,2))],1).cpu().tolist()
            for j,(sid,v) in enumerate(zip(ids[sl],counts)):
                assert v==[int(saved[start+j][k]) for k in ('tp','fp','fn')],(sid,v)
                rows.append(dict(id=sid,isic=mp[sid],**{k:float(arr[j]) for k,arr in a.items()}))
        train.write_rows(ROOT/(arm+'_per_image.csv'),rows)
        if selected is None:selected=select(rows)
        ch=int(ce.argmax())
        capture_cases(arm,model,cache,data,rows,selected,ch)
        quant={}
        for k in rows[0]:
            if k not in ('id','isic'):
                v=np.array([r[k] for r in rows]);quant[k]=dict(q10=float(np.quantile(v,.1)),median=float(np.median(v)),q90=float(np.quantile(v,.9)),total=float(v.sum()))
        modes={}
        for mode in MODES:
            def v(k):return np.array([r[mode+'_'+k] for r in rows])
            fixes=v('rescued_fn')+v('fixed_fp');harms=v('added_fp')+v('added_fn')
            modes[mode]=dict(fixed=int(fixes.sum()),harmed=int(harms.sum()),net=int((fixes-harms).sum()),
                             better=int((fixes>harms).sum()),worse=int((harms>fixes).sum()),equal=int((harms==fixes).sum()),
                             median_flips=float(np.median(fixes+harms)))
        summary[arm]=dict(verified_cases=len(rows),checkpoint=ref['sha256'],epoch=ref['epoch'],quantiles=quant,modes=modes,signed_channel=ch,
                          cases={k:rows[i] for k,i in selected.items()},seconds=time.monotonic()-tic)
        train.atomic_json(ROOT/'diagnosis.json',summary)
        print(arm,summary[arm]['modes'],flush=True)
        del model;torch.cuda.empty_cache()
if __name__=='__main__':main()
