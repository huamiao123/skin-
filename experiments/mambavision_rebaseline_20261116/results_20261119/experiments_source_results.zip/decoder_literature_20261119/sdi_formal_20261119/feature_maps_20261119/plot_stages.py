from pathlib import Path
import numpy as np
from scipy.stats import rankdata
import make_figures as pl
def figure():
    plt=pl.plt;fig=plt.figure(figsize=(16,8.5))
    fig.text(.03,.949,'从浅层到深层：响应从哪里开始集中？',fontsize=23,weight='bold')
    fig.text(.03,.901,'每个尺度先经对齐和卷积，再取跨 64 通道均方根。热图表示该位置在本图、本层 1024 个格点中的强度百分位。',fontsize=12)
    kinds=['f1','f2','f3','f4','delta'];heads=['原图与轮廓','F1 · 浅层','F2','F3','F4 · 深层','SDI 残差']
    ls=[.036,.199,.362,.525,.688,.851];ys=[.61,.36,.11];w=.135;h=.222
    for l,t in zip(ls,heads):fig.text(l+w/2,.845,t,ha='center',fontsize=12,weight='bold')
    for j,z in enumerate(pl.zs):
        ax=fig.add_axes([ls[0],ys[j],w,h]);pl.show(ax,z['rgb']);pl.outline(ax,z['gt'],'#00ffab');pl.outline(ax,z['pred']>=.5,'#fe58a0')
        fig.text(ls[0]+w/2,ys[j]-.017,str(z['public_id']),ha='center',fontsize=10)
        for n,k in enumerate(kinds,1):
            v=z[k+'_rms'];pct=100*(rankdata(v,method='average').reshape(v.shape)-.5)/v.size
            ax=fig.add_axes([ls[n],ys[j],w,h]);im=pl.show(ax,pct,cmap='magma',vmin=0,vmax=100)
            pl.outline(ax,z['gt'],'#43d4b2')
    pl.bar(fig,im,.55,.065,.21,'0 · 本层较弱','100 · 本层较强')
    fig.text(.03,.027,'绿线为真实标注，原图上的粉线为开启 SDI 后的预测。亮度表示相对响应强度，各层的绝对数值与通道含义不同。',fontsize=10)
    pl.save(fig,'stage_evidence.png')
figure()
