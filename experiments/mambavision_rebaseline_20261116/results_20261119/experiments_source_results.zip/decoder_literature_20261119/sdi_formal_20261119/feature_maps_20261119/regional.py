"""Pair severe interior misses with correctly segmented interior in the same images."""
import csv,json
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from scipy.ndimage import distance_transform_edt
import torch
from torch.nn import functional as F
import measure as m

@torch.inference_mode()
def main():
    m.setup(42);data,_=m.train.reference.load_data();model,_=m.load_ck('product')
    ids=data.ids['val'];cache=m.train.reference.cache_new(len(ids));m.train.reference.fill_cache(model,data,'val',cache)
    rows=list(csv.DictReader((m.ROOT/'product_per_image.csv').open()))
    assert [r['id'] for r in rows]==ids
    def get(k):return np.array([float(r[k]) for r in rows])
    change=(get('off_rescued_fn')+get('off_fixed_fp')-get('off_added_fp')-get('off_added_fn'))
    pool=(get('gt_pixels')>=.05*65536)&(get('gt_pixels')<=.65*65536)
    selected={}
    for key,sign in [('help_example',1),('hurt_example',-1)]:
        subset=np.flatnonzero(pool&(sign*change>0))
        cutoff=np.quantile(sign*change[subset],.90)
        selected[key]=int(subset[np.argmin(abs(sign*change[subset]-cutoff))])
    result=json.loads((m.ROOT/'diagnosis.json').read_text())
    m.capture_cases('product',model,cache,data,rows,selected,result['product']['signed_channel'])
    out=[]
    with ThreadPoolExecutor(8) as pool:
        for start in range(0,len(ids),64):
            sl=slice(start,start+64);gt=cache['target'][sl,0]>=.5
            feat=m.features(cache,sl,model);p,buf=m.single_pass(model,feat);po,_=m.single_pass(model,feat,'off')
            factors=[buf['f'+str(k)].abs().float() for k in range(1,5)]
            weak=[];strong=[]
            for x in factors:
                q=torch.quantile(x.flatten(2),torch.tensor([.25,.5],device=x.device),dim=-1)
                weak.append(x<q[0,:,:,None,None]);strong.append(x>q[1,:,:,None,None])
            weak1=torch.stack(weak).sum(0)==1;strong3=torch.stack(strong).sum(0)==3
            disagreement=(weak1&strong3).float().mean(1)
            strength=buf['delta'].float().square().mean(1)
            q=torch.quantile(strength.flatten(1),.5,dim=1)[:,None,None]
            low=strength<q
            distances=np.stack(list(pool.map(distance_transform_edt,gt.cpu().numpy())))
            deep=gt&(torch.as_tensor(distances,device='cuda')>8)
            masks={'miss':deep&(p<.1),'correct':deep&(p>=.5)}
            tensor_records={}
            for k,mask in masks.items():
                cnt=F.avg_pool2d(mask[:,None].float(),8,8)[:,0]*64
                tensor_records[k+'_pixels']=cnt.sum((1,2))
                tensor_records[k+'_low_pixels']=(cnt*low).sum((1,2))
                tensor_records[k+'_weak_channel_mass']=(cnt*disagreement).sum((1,2))
            native=p>=.5;off=po>=.5
            for k,mask in [('rescued',native&~off&gt),('newfp',native&~off&~gt)]:
                cnt=F.avg_pool2d(mask[:,None].float(),8,8)[:,0]*64
                tensor_records[k+'_ pixels'.replace(' ','')]=cnt.sum((1,2))
                tensor_records[k+'_low']=(cnt*low).sum((1,2))
            v={k:arr.cpu().tolist() for k,arr in tensor_records.items()}
            for j,sid in enumerate(ids[sl]):out.append(dict(id=sid,**{k:a[j] for k,a in v.items()}))
    m.train.write_rows(m.ROOT/'region_evidence_per_image.csv',out)
    gen=np.random.default_rng(42)
    eligible=[a for a in out if a['miss_pixels']>=64 and a['correct_pixels']>=64]
    groups={}
    for metric,field in [('bottom_half_residual','low_pixels'),('one_weak_three_strong_channels','weak_channel_mass')]:
        arr=np.array([[a[k+'_'+field]/a[k+'_pixels'] for k in ('miss','correct')] for a in eligible])
        delta=arr[:,0]-arr[:,1]
        boots=[delta[gen.integers(len(delta),size=len(delta))].mean() for _ in range(5000)]
        groups[metric]=dict(miss_mean=float(arr[:,0].mean()),correct_mean=float(arr[:,1].mean()),paired_diff=float(delta.mean()),
                            descriptive_image_ci95=np.quantile(boots,[.025,.975]).tolist())
    final=dict(selected={k:rows[i]['isic'] for k,i in selected.items()},selection='5-65% lesion area; closest to 90th percentile of abs net corrected pixels within helping/hurting groups, plus median ratio and prior 126 from first pass.',
               n_all=len(ids),n_with_both_interiors_ge64=len(eligible),deep_pixels_p_below01=int(sum(a['miss_pixels'] for a in out)),analysis=groups)
    m.train.atomic_json(m.ROOT/'region_evidence.json',final);print(json.dumps(final))
if __name__=='__main__':main()
