"""One prespecified frozen-weight trial after finding weak residual in missed interiors."""
import csv,json
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from scipy.ndimage import distance_transform_edt
import torch
from torch.nn import functional as F
import measure as m

MODES=['weak2','global_equal_energy']
NAMES=['f1','f2','f3','f4','joint','delta','t2']
def predict(model,feat,mode):
    def multiply(layer,args,out):
        a=out.float();e=a.square().mean(1,keepdim=True)
        q=e.flatten(1).median(1).values[:,None,None,None]
        gain=1.+(e<q).float()
        if mode=='global_equal_energy':
            gain=((e*gain.square()).sum((1,2,3))/e.sum((1,2,3)).clamp_min(1e-25)).sqrt()[:,None,None,None]
        return (a*gain).to(out.dtype)
    handle=model.probe.decode_head.out.register_forward_hook(multiply)
    try:
        with torch.autocast('cuda',dtype=torch.bfloat16):
            return model.probe(feat,(256,256))['main'][:,0].float().sigmoid()
    finally:handle.remove()
@torch.inference_mode()
def main():
    m.setup(42);data,_=m.train.reference.load_data();net,_=m.load_ck('product');ids=data.ids['val']
    cache=m.train.reference.cache_new(len(ids));m.train.reference.fill_cache(net,data,'val',cache)
    rows=[]
    with ThreadPoolExecutor(8) as pool:
        for start in range(0,len(ids),64):
            sl=slice(start,start+64);gt=cache['target'][sl,0]>=.5
            f=m.features(cache,sl,net);native,buf=m.single_pass(net,f);_,base=m.single_pass(net,f,'off');buf['t2']=base['t2']
            deep=gt&(torch.from_numpy(np.stack(list(pool.map(distance_transform_edt,gt.cpu().numpy())))).cuda()>8)
            miss=deep&(native<.1);correct=deep&(native>=.5);arrays={}
            def put(key,val):arrays[key]=val.cpu().numpy()
            for lab,sel in [('miss',miss),('correct',correct)]:
                area=F.avg_pool2d(sel[:,None].float(),8,8)[:,0]*64
                put(lab+'_area',area.sum((1,2)))
                for k in NAMES:
                    en=buf[k].float().square().mean(1);q=torch.quantile(en.flatten(1),.5,dim=1)[:,None,None]
                    put(lab+'_low_'+k,(area*(en<q)).sum((1,2)))
            orig=native>=.5
            def dice(pred):
                return (2*(pred&gt).sum((1,2))).double()/(pred.sum((1,2))+gt.sum((1,2))).clamp_min(1)
            for mode in MODES:
                v=predict(net,f,mode)
                alt=v>=.5
                for k,val in m.compare(v,native,gt).items():put(mode+'_'+k,val)
                put(mode+'_severe_fully_recovered',(alt&miss).sum((1,2)))
                put(mode+'_new_severe_from_correct',((v<.1)&correct).sum((1,2)))
                put(mode+'_selection_dice_delta',dice(alt)-dice(orig))
            for j,sid in enumerate(ids[sl]):rows.append(dict(id=sid,**{k:float(v[j]) for k,v in arrays.items()}))
    m.train.write_rows(m.ROOT/'weak_gain_per_image.csv',rows)
    elig=[r for r in rows if min(r['miss_area'],r['correct_area'])>=64]
    loc={k:{a:float(np.mean([r[a+'_low_'+k]/r[a+'_area'] for r in elig])) for a in ('miss','correct')} for k in NAMES}
    summary={}
    for mode in MODES:
        vals=lambda k:np.array([r[mode+'_'+k] for r in rows])
        fix=vals('rescued_fn')+vals('fixed_fp');harm=vals('added_fn')+vals('added_fp')
        summary[mode]=dict(fixed=int(fix.sum()),harmed=int(harm.sum()),net=int((fix-harm).sum()),better_pixels_cases=int((fix>harm).sum()),
                           worse_pixels_cases=int((fix<harm).sum()),severe_restored=int(vals('severe_fully_recovered').sum()),
                           new_severe_from_correct=int(vals('new_severe_from_correct').sum()),positive_macro_change=bool(vals('selection_dice_delta').mean()>0),
                           selection_delta=float(vals('selection_dice_delta').mean()))
    z=summary['weak2'];a=summary['global_equal_energy']
    passed=z['net']>0 and z['positive_macro_change'] and z['severe_restored']>z['new_severe_from_correct'] and z['selection_delta']>a['selection_delta']
    rec=dict(n=len(rows),eligible=len(elig),regional=loc,interventions=summary,pass_to_fixed_test=bool(passed))
    m.train.atomic_json(m.ROOT/'weak_gain.json',rec);print(json.dumps(rec))
if __name__=='__main__':main()
