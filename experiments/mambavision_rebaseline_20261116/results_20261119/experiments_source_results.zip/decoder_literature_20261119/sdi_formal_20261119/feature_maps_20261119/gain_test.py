"""Fixed held-out replay of the one-shot SDI weak-response gain after a positive development screen."""
from concurrent.futures import ThreadPoolExecutor
import csv,json
import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt as edt
import torch
import measure as m
from weak_gain import predict,MODES
from score_sdi import paired

@torch.inference_mode()
def run():
    dev=json.loads((m.ROOT/'weak_gain.json').read_text())
    assert dev['pass_to_fixed_test']
    m.setup(42);net,ref=m.load_ck('product')
    fixed=dict(checkpoint_sha=ref['sha256'],threshold=.5,variants=MODES,primary='weak2 minus native SDI, 867 images; paired bootstrap by prior case groups',protocol_sha=m.sha(m.ROOT/'weak_gain_protocol.json'),source_sha=m.sha(m.ROOT/'weak_gain.py'))
    path=m.ROOT/'locked_gain_test.json'
    if path.exists():assert json.loads(path.read_text())==fixed
    else:m.train.atomic_json(path,fixed)
    project=m.train.PROJECT;base=project.parent.parent
    part=json.loads((project/'stage45_upernet_decoder/identity_partition.json').read_text());ids=part['splits']['test']
    chk=base/'local_audit_records/test_assets/test_manifest.json';assert m.sha(chk)==part['audit_sha256']['test_manifest.json']
    manifest={r['id']:r for r in json.loads(chk.read_text())}
    def load(sid):
        root=base/'heldout_data/test';xx=root/'images'/(sid+'.png');yy=root/'masks'/(sid+'.png')
        assert m.sha(xx)==manifest[sid]['image_256_sha256'] and m.sha(yy)==manifest[sid]['mask_256_sha256']
        with Image.open(xx) as x,Image.open(yy) as y:
            im=np.array(x.convert('RGB'));gt=np.array(y.convert('L'))>=128
        return im,gt,gt&(edt(gt)>8)
    old=list(csv.DictReader((m.ROOT.parent/'runs/test_per_image.csv').open()))
    group=json.loads((m.Path('/home/featurize/work/mambavision_seg_rebaseline_20261116/uper64_feature_audit_20261119/transfer_20261119/hard_extent_s_20261119')/'group_sensitivity_protocol.json').read_text())['cases']['test']
    assert ids==[r['id'] for r in old]==[r['id'] for r in group] and len(ids)==867
    rows=[];mu=torch.tensor([.485,.456,.406],device='cuda')[None,:,None,None];std=torch.tensor([.229,.224,.225],device='cuda')[None,:,None,None]
    with ThreadPoolExecutor(8) as pool:
        for i in range(0,len(ids),64):
            inp=list(pool.map(load,ids[i:i+64]))
            x=torch.from_numpy(np.stack([a for a,b,c in inp])).permute(0,3,1,2).contiguous().cuda().float()/255.
            g=torch.from_numpy(np.stack([b for a,b,c in inp])).cuda();deep=torch.from_numpy(np.stack([c for a,b,c in inp])).cuda()
            with torch.autocast('cuda',dtype=torch.bfloat16):
                f1,f2,mid=net.prefix((x-mu)/std);features=[f1,f2,*net.suffix(mid)]
                basep=net.probe(features,(256,256))['main'][:,0].float().sigmoid()
            def dice(p):
                a=p>=.5;den=a.sum((1,2))+g.sum((1,2));tp=(a&g).sum((1,2))
                return torch.where(den>0,2*tp.double()/den,1.).cpu().numpy()
            born={'native':dice(basep)}
            for mode in MODES:
                p=predict(net,features,mode);born[mode]=dice(p)
                born[mode+'_deep_recovered']=((p>=.5)&(basep<.1)&deep).sum((1,2)).cpu().numpy()
                born[mode+'_new_deep']=((p<.1)&(basep>=.5)&deep).sum((1,2)).cpu().numpy()
            for j,sid in enumerate(ids[i:i+64]):
                assert abs(born['native'][j]-float(old[i+j]['product_42']))<1e-12
                rows.append(dict(id=sid,**{k:float(v[j]) for k,v in born.items()}))
    m.train.write_rows(m.ROOT/'gain_test_per_image.csv',rows)
    res={}
    for split,keep in [('all',np.ones(len(ids),dtype=bool)),('isolated',np.array([r['retain'] for r in group]))]:
        gr=np.array([r['group'] for r in group])[keep]
        ar={k:np.array([r[k] for r in rows])[keep] for k in ['native',*MODES]}
        res[split]=dict(n=len(gr),dice={k:float(v.mean()) for k,v in ar.items()},vs_native={k:paired(ar['native'],ar[k],gr) for k in MODES},
                        severe={k:{label:int(sum(r[k+'_'+label] for r,b in zip(rows,keep) if b)) for label in ['deep_recovered','new_deep']} for k in MODES})
    m.train.atomic_json(m.ROOT/'gain_test.json',res);print(json.dumps(res))
if __name__=='__main__':run()
