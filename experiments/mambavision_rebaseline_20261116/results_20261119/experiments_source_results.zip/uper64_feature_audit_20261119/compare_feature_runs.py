"""Paired differences of the three validation-selected systems."""
import csv
import json
from pathlib import Path

import numpy as np


def main():
    root = Path(__file__).resolve().parent / "runs"
    scores = {}
    arms = {}
    for arm in ("add", "gated_concat", "f3_difference"):
        directory = root / arm
        done = json.loads((directory / "complete.json").read_text())
        assert done["epochs"] == 100 and not done["test_used"]
        with (directory / "best_validation.csv").open() as handle:
            rows = list(csv.DictReader(handle))
        per_image = {row["id"]: float(row["dice"]) for row in rows}
        assert len(per_image) == len(rows) == 762
        best = done["best"]
        assert abs(np.mean(list(per_image.values())) - best["val_macro_dice"]) < 1e-10
        scores[arm] = per_image
        arms[arm] = dict(epoch=best["epoch"], validation_macro_dice=best["val_macro_dice"])
    ids = sorted(scores["add"])
    rng = np.random.default_rng(42)
    samples = rng.integers(len(ids), size=(5000, len(ids)))
    contrasts = []
    for candidate, reference in (("gated_concat","add"), ("f3_difference","add"),
                                 ("f3_difference","gated_concat")):
        assert ids == sorted(scores[candidate]) == sorted(scores[reference])
        delta = 100*np.array([scores[candidate][i] - scores[reference][i] for i in ids])
        contrasts.append(dict(candidate=candidate, reference=reference, difference_pp=float(delta.mean()),
                              paired_image_bootstrap_95pct_pp=np.quantile(delta[samples].mean(1), [.025,.975]).tolist()))
    report = dict(metric="validation mean per-image foreground Dice", seed=42, n=762, test_used=False,
                  arms=arms, comparisons=contrasts)
    tmp = root / "comparison.tmp"
    tmp.write_text(json.dumps(report, indent=2))
    tmp.replace(root / "comparison.json")


if __name__ == "__main__":
    main()
