"""Two real optimizer steps per arm; formal experiment folders are never touched."""
import gc
import hashlib
import json
import math

import torch

from train_feature import ARMS, ROOT, accumulate, atomic_json, build, optimizer, reference


def grad_size(layer):
    return float(layer.weight.grad.detach().abs().sum())


@torch.no_grad()
def prediction(model, cache):
    model.eval()
    with torch.autocast("cuda", dtype=torch.bfloat16):
        out = model.from_cache(*cache["features"], cache["mid"], (256, 256))
    assert set(out) == {"main"}
    return out["main"].float()


def run():
    reference.setup()
    data, _ = reference.load_data()
    order, geometry = data.geometry(1)
    ids = order[:64]
    images, target = data.batch("train", ids, geometry)
    idx = torch.arange(len(ids), device=images.device)
    results = {}
    control_digest = None
    for arm in ARMS:
        reference.setup()
        model = build(arm)
        model.eval()
        counts = sum(p.numel() for p in model.probe.parameters())
        if arm == "add":
            with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
                f1, f2, mid = model.prefix(images)
            cache = dict(features=[f1, f2], mid=mid, target=target)
        initial = prediction(model, cache)
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
            direct = model(images)["main"].float()
        assert torch.equal(direct, initial), arm
        if arm == "add":
            baseline = initial.clone()
        init_diff = (initial - baseline).abs().max().item()
        assert init_diff == 0., (arm, init_diff)
        assert model.probe.auxiliary_head is None
        opt = optimizer(model)
        correction = None if arm == "add" else model.probe.decode_head.correct
        if arm in ("gated_concat", "f3_difference", "f4_difference"):
            digest = hashlib.sha256()
            for value in correction.state_dict().values():
                digest.update(value.cpu().numpy().tobytes())
            if control_digest is None:
                control_digest = digest.hexdigest()
            assert digest.hexdigest() == control_digest
        shape = []
        if correction is not None:
            def capture(module, args, output):
                shape[:] = list(output.shape)
            handle = correction.register_forward_hook(capture)
        model.train()
        updates = []
        for step in range(2):
            loss, norms = accumulate(model, opt, cache, idx, 64)
            assert math.isfinite(loss) and all(math.isfinite(v) and v > 0 for v in norms.values())
            assert all(p.grad is None for p in model.encoder.parameters() if not p.requires_grad)
            item = {"loss": loss, "group_grad_norm": norms}
            if correction is not None:
                assert shape == [64, 64, 32, 32], shape
                item["residual_grad_l1"] = grad_size(correction.residual)
                item["mix_grad_l1"] = grad_size(correction.mix)
                assert item["residual_grad_l1"] > 0
                assert (item["mix_grad_l1"] > 0) == bool(step)
                if correction.gate is not None:
                    item["gate_grad_l1"] = grad_size(correction.gate)
                    assert (item["gate_grad_l1"] > 0) == bool(step)
            updates.append(item)
        effect = None
        if correction is not None:
            handle.remove()
            active = prediction(model, cache)
            with torch.no_grad():
                weight = correction.residual.weight.clone()
                bias = correction.residual.bias.clone()
                correction.residual.weight.zero_()
                correction.residual.bias.zero_()
                disabled = prediction(model, cache)
                correction.residual.weight.copy_(weight)
                correction.residual.bias.copy_(bias)
            effect = (active - disabled).abs().max().item()
            assert math.isfinite(effect) and effect > 0
        results[arm] = dict(head_parameters=counts, initial_max_abs_logit_difference=init_diff,
                            direct_matches_cache=True, update_shape=shape or None,
                            max_abs_effect_after_two_updates=effect, updates=updates)
        print("SMOKE_PASS", arm, counts, init_diff, effect, flush=True)
        del opt, model, correction
        gc.collect()
        torch.cuda.empty_cache()
    assert len({results[a]["head_parameters"] for a in ARMS[-3:]}) == 1
    atomic_json(ROOT / "smoke.json", dict(arms=results, equal_initial_gated_parameters_sha256=control_digest,
                                         images=64, test_used=False, formal_training_started=False))


if __name__ == "__main__":
    run()
