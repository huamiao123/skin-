from pathlib import Path
import csv
import gc
import json
import sys
import numpy as np
import torch
from scipy.ndimage import distance_transform_edt

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "method1_f3_20261118"
sys.path.insert(0, str(OLD))
from decoder import build
from train import interior_masks, validate, reference, atomic_json


def run():
    reference.setup()
    data, _ = reference.load_data()
    cache = reference.cache_new(len(data.ids["val"]))
    results = {}
    for arm in ("f3","f4","uper64"):
        model = build(arm)
        state = torch.load(OLD/arm/"best.pth", map_location="cpu")
        model.load_state_dict(state["model"], strict=True)
        del state
        reference.fill_cache(model,data,"val",cache)
        target = cache["target"]
        if not results:
            fg = target >= .5
            old_fg = target.bool()
            old_interior = np.stack([distance_transform_edt(np.pad(m,1))[1:-1,1:-1] > 8
                                     for m in old_fg[:,0].cpu().numpy()])
            interior = interior_masks(target)
            changed = (old_fg != fg).flatten(1).sum(1)
            changed_interior = (interior != torch.from_numpy(old_interior).cuda()).flatten(1).sum(1)
            audit = dict(images=len(fg), pixels=target.numel(), nonbinary=int(((target!=0)&(target!=1)).sum()),
                         foreground_pixels_differ=int(changed.sum()), foreground_images_differ=int((changed>0).sum()),
                         interior_pixels_differ=int(changed_interior.sum()), interior_images_differ=int((changed_interior>0).sum()))
            # A grey ring must be excluded, including when it changes the >8px interior.
            toy = torch.full((1,1,33,33), .1, device=target.device)
            toy[:,:,9:24,9:24] = .5
            assert not interior_masks(toy).any()
            assert interior_masks((toy!=0).float()).any()
        scores,rows = validate(model,cache,data.ids["val"],interior)
        with (OLD/arm/"best_validation.csv").open() as f:
            before={r["id"]:r for r in csv.DictReader(f)}
        assert set(before)=={r["id"] for r in rows}
        changed_rows=0
        for row in rows:
            original=before[row["id"]]
            changed_rows+=any(int(original[k])!=row[k] for k in ("conf_interior_fixed","conf_interior_fn") if k in row)
            for k,v in row.items():
                if k not in ("id","conf_interior_fixed","conf_interior_fn"):assert abs(float(original[k])-v)<1e-12,(arm,row["id"],k)
        results[arm]={"scores":scores,"changed_interior_rows":changed_rows}
        if changed_rows:
            from train import write_rows
            write_rows(ROOT/(arm+"_corrected_validation.csv"),rows)
        del model
        gc.collect()
        torch.cuda.empty_cache()
    atomic_json(ROOT/"diagnostic_replay.json",dict(validation_mask=audit,models=results))
    print(audit,flush=True)

if __name__=="__main__":run()
