"""Validation-only oracle: preserve score ordering, grant each image its exact GT size."""
import argparse
import csv
import json
from pathlib import Path
import sys

import numpy as np
import torch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from train_feature import atomic_json,build,reference,write_rows


def quota_dice(score,target,k):
    flat=score.reshape(-1)
    gt=target.reshape(-1)
    count=int(gt.sum())
    if k==0: return float(count==0)
    assert 0 < k <= gt.size
    cut=np.partition(flat, flat.size-k)[flat.size-k]
    above=flat>cut
    ties=flat==cut
    to_take=k-int(above.sum())
    expected_tp=(above & gt).sum() + to_take*(ties & gt).sum()/int(ties.sum())
    return float(2*expected_tp/(count+k))


@torch.inference_mode()
def run(arm):
    torch.cuda.set_per_process_memory_fraction(.22)
    reference.setup()
    model=build("add").eval()
    run_dir=HERE.parent/"runs/add" if arm=="baseline" else HERE/"proportion_l1"
    ck=torch.load(run_dir/"best.pth",map_location="cpu")
    model.load_state_dict(ck["model"])
    del ck
    with (run_dir/"best_validation.csv").open() as f:
        expected={r["id"]:r for r in csv.DictReader(f)}
    data,_=reference.load_data()
    rows=[]
    for i in range(0,len(data.ids["val"]),64):
        ids=torch.arange(i,min(i+64,len(data.ids["val"])),device="cuda")
        x,y=data.batch("val",ids)
        with torch.autocast("cuda",dtype=torch.bfloat16):
            logits=model(x)["main"][:,0].float()
        zz=logits.cpu().numpy()
        probs=logits.sigmoid()
        soft_size=probs.sum((1,2),dtype=torch.float64).round().long().cpu().tolist()
        pp=(probs>=.5).cpu().numpy()
        yy=(y[:,0]>=.5).cpu().numpy()
        for j,(z,p,g) in enumerate(zip(zz,pp,yy)):
            sid=data.ids["val"][i+j]
            tp,fp,fn=[int(t.sum()) for t in (p&g,p&~g,~p&g)]
            assert (tp,fp,fn)==tuple(int(expected[sid][k]) for k in ("tp","fp","fn"))
            reference_dice=float(expected[sid]["dice"])
            k=int(g.sum())
            score=quota_dice(z,g,k)
            soft=quota_dice(z,g,soft_size[j])
            small=quota_dice(z,g,max(0,round(.9*k)))
            large=quota_dice(z,g,min(g.size,round(1.1*k)))
            rows.append(dict(id=sid,dice=reference_dice,area_oracle=score,delta=score-reference_dice,
                             gt_fraction=float(g.mean()),soft_size_dice=soft,oracle_minus10=small,oracle_plus10=large))
    assert len(rows)==762
    write_rows(HERE/(arm+"_area_oracle.csv"),rows)
    d=np.array([v["delta"] for v in rows])
    def mean(k):return float(np.mean([v[k] for v in rows]))
    result=dict(n=len(rows),dice=mean("dice"),area_oracle=mean("area_oracle"),difference_pp=100*mean("delta"),
                soft_size_dice=mean("soft_size_dice"),oracle_minus10=mean("oracle_minus10"),
                oracle_plus10=mean("oracle_plus10"),improved=int((d>1e-10).sum()),worse=int((d< -1e-10).sum()),test_used=False,
                tie_rule="expected TP for a random subset within cutoff ties, fixed exact GT area")
    atomic_json(HERE/(arm+"_area_oracle.json"),result)
    print(json.dumps(result),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("arm",choices=["baseline","proportion_l1"])
    run(parser.parse_args().arm)
