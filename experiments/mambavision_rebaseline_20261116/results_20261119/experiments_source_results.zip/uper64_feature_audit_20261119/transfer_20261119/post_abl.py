import json
from pathlib import Path

import numpy as np

from train_abl import HERE, build, atomic_json
from paired_diagnostics import compare
from oracle_geometry import main as geometry
from compare_cases import read


if __name__=="__main__":
    folder=HERE/"abl_uper64"
    baseline=HERE.parent/"runs/add"
    compare("add",baseline/"best.pth",False,folder/"best.pth")
    geometry(candidate_dir=folder,candidate_factory=lambda:build("add"))
    g=json.loads((folder/"geometry.json").read_text())["means"]
    original=json.loads((HERE/"oracle_geometry.json").read_text())["means"]
    def error(z,band):return z["base_fn_"+band]+z["base_fp_"+band]
    bands={k:dict(base=error(original,k),candidate=error(g,k),delta=error(g,k)-error(original,k)) for k in ("near","mid","far")}
    ids,x=read(folder);other,b=read(baseline)
    assert ids==other and np.array_equal(x[:,0]+x[:,2],b[:,0]+b[:,2])
    def dice(t):return 1-(t[:,1]+t[:,2])/np.maximum(2*t[:,0]+t[:,1]+t[:,2],1)
    diff=100*(dice(x)-dice(b))
    ix=np.random.default_rng(42).integers(len(ids),size=(5000,len(ids)))
    result=dict(epochs=100,best=json.loads((folder/"complete.json").read_text())["best"],
        n_val=len(ids),delta_dice_pp=float(diff.mean()),paired_image_ci95_pp=np.quantile(diff[ix].mean(1),[.025,.975]).tolist(),
        dice_deficit_pp_by_distance=bands,test_used=False)
    atomic_json(folder/"summary.json",result)
    print(json.dumps(result),flush=True)
