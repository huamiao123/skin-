"""Train-only ridge probe of whether per-image area corrections transfer to validation."""
import csv
from pathlib import Path
import sys
import numpy as np
import torch

from area_oracle import HERE, quota_dice
from train_feature import atomic_json,build,reference,write_rows


def fit(X,y):
    X=X.astype(np.float64)
    center=X.mean(0)
    scale=X.std(0)
    scale[scale<1e-6]=1.
    Z=(X-center)/scale
    # Fixed ridge coefficient 1 in the mean-square-loss convention, unpenalized intercept.
    covariance=Z.T@Z/len(y)
    covariance.flat[::covariance.shape[0]+1]+=1.
    weight=np.linalg.solve(covariance,Z.T@(y-y.mean())/len(y))
    return center,scale,weight,float(y.mean())


def estimate(x,reg):
    center,scale,weight,bias=reg
    return ((x-center)/scale)@weight+bias


@torch.inference_mode()
def run(feature_builder=None,output_prefix="area_probe"):
    torch.cuda.set_per_process_memory_fraction(.22)
    reference.setup()
    model=build("add").eval()
    base=HERE.parent/"runs/add"
    ck=torch.load(base/"best.pth",map_location="cpu")
    model.load_state_dict(ck["model"])
    del ck
    with (base/"best_validation.csv").open() as f:
        gold={r["id"]:r for r in csv.DictReader(f)}
    data,_=reference.load_data()
    rows=[]
    models={}
    for split in ("train","val"):
        train_x={}
        train_y=[]
        for i in range(0,len(data.ids[split]),64):
            ix=torch.arange(i,min(i+64,len(data.ids[split])),device="cuda")
            images, y=data.batch(split,ix)
            with torch.autocast("cuda",dtype=torch.bfloat16):
                f1,f2,mid=model.prefix(images)
                f3,f4=model.suffix(mid)
                z=model.probe([f1,f2,f3,f4],(256,256))["main"][:,0].float()
            prob=z.sigmoid()
            size=(prob>=.5).sum((1,2)).cpu().numpy()
            # Prediction quantiles represented by areas above a fixed grid of probability thresholds.
            scalar=torch.stack([prob.mean((1,2))]+[(prob>=t).float().mean((1,2))
                              for t in (.05,.1,.25,.5,.75,.9,.95)],dim=1)
            if feature_builder is None:
                arrays={"score_only":scalar,"score_plus_features":torch.cat([scalar,f3.float().mean((2,3)),f4.float().mean((2,3))],1)}
            else:
                arrays=feature_builder(scalar,model.probe.decode_head,[f1,f2,f3,f4],z)
            arrays={name:x.cpu().numpy() for name,x in arrays.items()}
            gt=(y[:,0]>=.5).cpu().numpy()
            count=gt.sum((1,2))
            if split=="train":
                for name,x in arrays.items(): train_x.setdefault(name,[]).append(x)
                train_y.append(np.log((count+1)/(size+1)))
                continue
            ids=data.ids[split][i:i+len(ix)]
            zz=z.cpu().numpy()
            predictions={}
            for name,reg in models.items():
                prediction=estimate(arrays[name],reg)
                predictions[name]=np.clip(np.rint((size+1)*np.exp(np.clip(prediction,-12,12))-1),0,65536).astype(int)
            for j,sid in enumerate(ids):
                g=gold[sid]
                assert size[j]==int(g["tp"])+int(g["fp"])
                row=dict(id=sid,gt=int(count[j]),base_k=int(size[j]),base_dice=float(g["dice"]))
                for name,ks in predictions.items():
                    row[name+"_k"]=int(ks[j])
                    row[name+"_dice"]=quota_dice(zz[j],gt[j],int(ks[j]))
                rows.append(row)
        if split=="train":
            Y=np.concatenate(train_y)
            assert len(Y)==1886
            models={name:fit(np.concatenate(parts),Y) for name,parts in train_x.items()}
    assert len(rows)==762
    write_rows(HERE/(output_prefix+".csv"),rows)
    result={}
    for name in ("base",*models):
        dice=np.array([r[name+"_dice"] for r in rows]);base_dice=np.array([r["base_dice"] for r in rows])
        delta=dice-base_dice
        rng=np.random.default_rng(42)
        ix=rng.integers(len(rows),size=(5000,len(rows)))
        result[name]=dict(dice=float(dice.mean()),delta_pp=float(100*delta.mean()),
                          image_bootstrap_ci95_pp=(100*np.quantile(delta[ix].mean(1),[.025,.975])).tolist(),
                          area_mae=float(np.mean([abs(r[name+"_k"]-r["gt"])/65536 for r in rows])))
    atomic_json(HERE/(output_prefix+".json"),dict(n_train=1886,n_val=762,seed=42,test_used=False,
              fit="training split only; in-sample for the frozen segmenter; no validation hyperparameter search",
              ridge=1.,scores=result))
    print(result,flush=True)


if __name__=="__main__":
    run()
