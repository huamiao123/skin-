"""Train-only area readouts of OCRNet's original spatial gather on frozen UPer features."""
import ast
import hashlib
import json
import torch
from torch import nn
from torch.nn import functional as F
from area_probe import HERE,run


def load_gather():
    root=HERE/"upstream_ocr"
    manifest=json.loads((root/"manifest.json").read_text())
    path=root/"seg_hrnet_ocr.py"
    assert manifest["commit"]=="0bbb2880446ddff2d78f8dd7e8c4c610151d5a51"
    assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest["sha256"]
    tree=ast.parse(path.read_text())
    tree.body=[node for node in tree.body if isinstance(node,ast.ClassDef) and node.name=="SpatialGather_Module"]
    assert len(tree.body)==1
    scope=dict(nn=nn,torch=torch,F=F)
    exec(compile(tree,str(path),"exec"),scope)
    return scope["SpatialGather_Module"](cls_num=2).eval()


def make_builder():
    gather=load_gather()
    def features(scalar,head,stages,z):
        with torch.autocast("cuda",dtype=torch.bfloat16):
            maps=(head.lateral_convs[2](stages[2]),head.psp_forward(stages))
        reps={name:[scalar] for name in ("uniform","shifted","aligned")}
        for x in maps:
            x=x.float().contiguous()
            logit=F.interpolate(z[:,None],size=x.shape[-2:],mode="bilinear",align_corners=False)
            guides=torch.cat((-logit/2,logit/2),dim=1)
            variants={"aligned":guides,"shifted":guides.roll((x.shape[-2]//2,x.shape[-1]//2),(-2,-1)),
                      "uniform":torch.zeros_like(guides)}
            for name,guide in variants.items():
                reps[name].append(gather(x,guide.contiguous()).flatten(1))
        return {name:torch.cat(values,dim=1) for name,values in reps.items()}
    return features


if __name__=="__main__":
    run(feature_builder=make_builder(),output_prefix="ocr_area_probe")
