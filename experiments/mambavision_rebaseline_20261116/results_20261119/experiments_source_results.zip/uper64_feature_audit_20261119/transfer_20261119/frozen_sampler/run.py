"""Can a sampler transfer to, or improve, the validation-selected frozen UPer64?"""
import csv
import fcntl
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import distance_transform_edt

RUN=Path(__file__).resolve().parent
sys.path.insert(0,str(RUN.parent))
from dysample_decoder import HERE, ROOT, ARMS, SamplingHead
from feature_decoder import build
from train_feature import reference,atomic_json,atomic_save,write_rows
from model import segmentation_loss


def frozen_digest(model):
    h=hashlib.sha256()
    for name,t in model.state_dict().items():
        if name.startswith("probe.decode_head.sampler.offset."): continue
        h.update(name.encode())
        h.update(t.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


def geometry_band(target):
    out=[]
    for g in (target[:,0]>=.5).cpu().numpy():
        assert g.any()
        di=distance_transform_edt(np.pad(g,1))[1:-1,1:-1]
        do=distance_transform_edt(~g)
        out.append((g&(di<=3))|(~g&(do<=3)))
    return torch.from_numpy(np.stack(out)).to(target.device)


@torch.inference_mode()
def evaluate(model,cache,ids,band,label,baseline):
    rows=[]
    for i in range(0,len(ids),64):
        sl=slice(i,i+64)
        with torch.autocast("cuda",dtype=torch.bfloat16):
            logits=model.from_cache(cache["features"][0][sl],cache["features"][1][sl],cache["mid"][sl],(256,256))["main"][:,0]
        assert torch.isfinite(logits).all()
        pred=logits.float().sigmoid()>=.5
        gt=cache["target"][sl,0]>=.5
        bits=(pred&gt,pred&~gt,~pred&gt,(pred!=gt)&band[sl])
        counts=torch.stack([b.sum((1,2)) for b in bits],1).tolist()
        for j,(tp,fp,fn,near) in enumerate(counts):
            sid=ids[i+j];den=2*tp+fp+fn
            if label=="zero":
                assert [tp,fp,fn]==[int(baseline[sid][k]) for k in ("tp","fp","fn")],sid
            rows.append(dict(id=sid,tp=tp,fp=fp,fn=fn,dice=2*tp/den if den else 1.,near_pp=100*near/max(den,1)))
    assert len(rows)==len(baseline)==762
    write_rows(RUN/(label+".csv"),rows)
    diff=np.array([100*(r["dice"]-float(baseline[r["id"]]["dice"])) for r in rows])
    ix=np.random.default_rng(42).integers(len(diff),size=(5000,len(diff)))
    return dict(dice=float(np.mean([r["dice"] for r in rows])),near_deficit_pp=float(np.mean([r["near_pp"] for r in rows])),
            difference_pp=float(diff.mean()),paired_image_ci95_pp=np.quantile(diff[ix].mean(1),[.025,.975]).tolist(),
            images_better=int((diff>0).sum()),images_worse=int((diff<0).sum()))


def main():
    reference.setup()
    base_dir=ROOT/"runs/add"
    source=HERE/ARMS[0]
    model=build("add")
    ck=torch.load(base_dir/"best.pth",map_location="cpu")
    model.load_state_dict(ck["model"],strict=True)
    base_epoch=ck["epoch"]
    del ck
    assert base_epoch==39
    model.probe.decode_head=SamplingHead(model.probe.decode_head).cuda()
    model.requires_grad_(False)
    offset=model.probe.decode_head.sampler.offset
    offset.requires_grad_(True)
    model.eval()
    assert sum(v.numel() for v in model.parameters() if v.requires_grad)==2080
    fixed=frozen_digest(model)
    data,_=reference.load_data()
    val=reference.cache_new(len(data.ids["val"]))
    reference.fill_cache(model,data,"val",val)
    band=geometry_band(val["target"])
    with (base_dir/"best_validation.csv").open() as f:
        baseline={r["id"]:r for r in csv.DictReader(f)}
    scores={}
    scores["zero"]=evaluate(model,val,data.ids["val"],band,"zero",baseline)
    ck=torch.load(source/"best.pth",map_location="cpu")
    assert ck["epoch"]==39
    prefix="probe.decode_head.sampler.offset."
    offset.load_state_dict({k[len(prefix):]:v for k,v in ck["model"].items() if k.startswith(prefix)},strict=True)
    del ck
    scores["transplanted"]=evaluate(model,val,data.ids["val"],band,"transplanted",baseline)
    atomic_json(RUN/"swap.json",scores)
    with torch.no_grad():
        offset.weight.zero_();offset.bias.zero_()
    opt=torch.optim.AdamW(offset.parameters(),lr=1e-3,weight_decay=.01)
    config=dict(epochs=20,seed=42,batch=64,lr=1e-3,min_lr=1e-5,weight_decay=.01,clip=1.,
                objective="unchanged BCE + per-image soft Dice",selection="fixed final epoch",
                base_epoch=base_epoch,fixed_digest=fixed,trainable=2080,
                script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    atomic_json(RUN/"config.json",config)
    history=[]
    latest=RUN/"latest.pth"
    if latest.exists():
        saved=torch.load(latest,map_location="cpu")
        if saved["config"]!=config: raise ValueError("checkpoint config mismatch")
        offset.load_state_dict(saved["offset"])
        opt.load_state_dict(saved["optimizer"])
        history=saved["history"]
    for epoch in range(len(history)+1,21):
        start=time.perf_counter()
        order,geo=data.geometry(base_epoch+epoch)
        lr=1e-3*(.01+.99*(1+math.cos(math.pi*(epoch-1)/19))/2)
        opt.param_groups[0]["lr"]=lr
        total=0.
        for i in range(0,len(order),64):
            ids=order[i:i+64]
            images,target=data.batch("train",ids,geo)
            opt.zero_grad(set_to_none=True)
            with torch.autocast("cuda",dtype=torch.bfloat16):
                with torch.no_grad():
                    f1,f2,mid=model.prefix(images)
                    f3,f4=model.suffix(mid)
                out=model.probe([f1,f2,f3,f4],(256,256))["main"]
            loss=segmentation_loss(out,target)
            assert torch.isfinite(loss)
            loss.backward()
            norm=float(torch.nn.utils.clip_grad_norm_(offset.parameters(),1.,error_if_nonfinite=True))
            if epoch==1 and i==0:
                assert norm>0 and all(p.grad is None for p in model.parameters() if not p.requires_grad)
                atomic_json(RUN/"first_update.json",dict(loss=float(loss.detach()),offset_grad_norm=norm,batch=len(ids)))
            opt.step()
            total+=float(loss.detach())*len(ids)
        rec=dict(epoch=epoch,loss=total/len(order),lr=lr,seconds=time.perf_counter()-start)
        history.append(rec)
        atomic_save(latest,dict(config=config,offset=offset.state_dict(),optimizer=opt.state_dict(),history=history))
        atomic_json(RUN/"history.json",history)
        print(json.dumps(rec),flush=True)
    assert frozen_digest(model)==fixed
    scores["trained20"]=evaluate(model,val,data.ids["val"],band,"trained20",baseline)
    atomic_json(RUN/"result.json",dict(scores=scores,epochs=20,n_val=762,frozen_weights_buffers_verified=True,test_used=False))
    print(json.dumps(scores),flush=True)


if __name__=="__main__":
    with (RUN/"run.lock").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if not (RUN/"result.json").exists(): main()
