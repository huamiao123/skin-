"""Development-only interventions on the two target-trained native UPer64 models."""
import csv,io,json,sys,zipfile,math
from pathlib import Path
import numpy as np,torch
from torch.nn import functional as F
from scipy.ndimage import distance_transform_edt,binary_erosion
from PIL import Image
ROOT=Path(__file__).resolve().parent
T=ROOT.parent/'target_training_20261119';E=ROOT.parent/'external_test_20261119'
sys.path.insert(0,str(T));import train_target as tr
def rows(path):
    with path.open() as f:return list(csv.DictReader(f))
def raw_image(ds,r,z):
    if ds=='Waterloo':
        with Image.open(io.BytesIO(z.read(r['image_path']))) as im:return im.convert('RGB')
    with Image.open(r['image_path']) as im:return im.convert('RGB')
def batch_logits(model,arr):
    x=torch.from_numpy(np.stack(arr)).permute(0,3,1,2).contiguous().cuda().float()/255.
    with torch.autocast('cuda',dtype=torch.bfloat16):out=model(tr.norm(x))['main'][:,0].float()
    assert torch.isfinite(out).all()
    return out
def box(mask):
    y,x=np.where(mask)
    if len(y)==0:return (0,0,256,256)
    side=min(256,max(96,int(math.ceil(1.8*max(int(np.ptp(y))+1,int(np.ptp(x))+1)))))
    l=int(np.clip(round((x.min()+x.max()+1-side)/2),0,256-side))
    t=int(np.clip(round((y.min()+y.max()+1-side)/2),0,256-side))
    return (l,t,l+side,t+side)
def crop_at(img,b):
    w,h=img.size;return img.crop((round(b[0]*w/256),round(b[1]*h/256),round(b[2]*w/256),round(b[3]*h/256)))
def resized(im,k):return np.array(im.resize((k,k),Image.Resampling.BILINEAR))
def coarse(raw,k):return F.interpolate(raw[:,None],size=(k,k),mode='bilinear',align_corners=False)[:,0]
def dc(mask,y):
    den=mask.sum()+y.sum();return float(2*np.count_nonzero(mask&y)/den) if den else 1.
def summarize(out,keys):
    s={}
    for k in keys:
        d=100*np.array([r[k]-r['base'] for r in out])
        gs=sorted({r['group'] for r in out})
        sums=np.array([sum(x for x,r in zip(d,out) if r['group']==g) for g in gs]);n=np.array([sum(r['group']==g for r in out) for g in gs])
        sample=np.random.default_rng(42).integers(len(gs),size=(5000,len(gs)))
        s[k]={'dice':float(np.mean([r[k] for r in out])),'delta_pp':float(d.mean()),'interval':np.quantile(sums[sample].sum(1)/n[sample].sum(1),[.025,.975]).tolist()}
    return s
@torch.inference_mode()
def main():
    tr.reference.setup()
    manifest={(r['dataset'],r['id']):r for r in rows(E/'manifest.csv')}
    results={}
    with zipfile.ZipFile(E/'data/waterloo.zip') as z:
        for ds in ('PH2','Waterloo'):
            model=tr.build('add').eval();ck=torch.load(T/ds/'uper64/best.pth',map_location='cpu');model.load_state_dict(ck['model']);del ck
            trained,_=tr.evaluate(model,tr.load_split(ds,'train'));val=tr.load_split(ds,'val');valid_score,baseline=tr.evaluate(model,val)
            assert abs(valid_score-json.load((T/ds/'uper64/complete.json').open())['val_macro_dice'])<1e-10
            _,gts,meta=val;gts=gts[:,0].bool().cpu().numpy()
            raw=[raw_image(ds,manifest[(ds,r['id'])],z) for r in meta]
            originals=[resized(im,256) for im in raw]
            base=torch.cat([batch_logits(model,originals[i:i+32]) for i in range(0,len(raw),32)])
            use=['base','up512','native512','avg_up512','avg_native512','roi_up','roi_native']
            out=[]
            for i in range(0,len(meta),8):
                group=raw[i:i+8];b=base[i:i+8];low=[Image.fromarray(x) for x in originals[i:i+8]]
                up=coarse(batch_logits(model,[resized(im,512) for im in low]),256)
                native=coarse(batch_logits(model,[resized(im,512) for im in group]),256)
                boxes=[box(p) for p in (b>=0).cpu().numpy()]
                roi_up=batch_logits(model,[resized(crop_at(im,bb),256) for im,bb in zip(low,boxes)])
                roi_hi=batch_logits(model,[resized(crop_at(im,bb),256) for im,bb in zip(group,boxes)])
                variants=dict(base=b,up512=up,native512=native,avg_up512=(b+up)*.5,avg_native512=(b+native)*.5)
                for k,p in [('roi_up',roi_up),('roi_native',roi_hi)]:
                    combined=b.clone()
                    for j,(l,t,r,bt) in enumerate(boxes):
                        adjusted=coarse(p[j:j+1],r-l)[0]
                        if r-l<256:combined[j,t:bt,l:r]=(adjusted+b[j,t:bt,l:r])*.5
                    variants[k]=combined
                pred={k:(v.sigmoid()>=.5).cpu().numpy() for k,v in variants.items()}
                for j,m in enumerate(meta[i:i+8]):
                    yy=gts[i+j];p=pred['base'][j]
                    row=dict(id=m['id'],group=m['group'],gt_fraction=float(yy.mean()),crop_side=boxes[j][2]-boxes[j][0])
                    row.update({k:dc(v[j],yy) for k,v in pred.items()})
                    assert abs(row['base']-baseline[i+j]['dice'])<1e-10
                    dist_inside=distance_transform_edt(np.pad(yy,1))[1:-1,1:-1]
                    dist_outside=distance_transform_edt(~yy)
                    den=int(p.sum()+yy.sum())
                    row['far8_deficit']=(np.count_nonzero((yy&~p)&(dist_inside>8))+np.count_nonzero((p&~yy)&(dist_outside>8)))/den
                    row['area_ratio']=float(p.sum()/yy.sum())
                    out.append(row)
            tr.write_rows(ROOT/(ds+'_scale_cases.csv'),out)
            summary=summarize(out,use)
            for k1,k2 in [('native512','up512'),('roi_native','roi_up'),('avg_native512','avg_up512')]:
                adj=[dict(r,base=r[k2]) for r in out];summary[k1+'_vs_'+k2]=summarize(adj,[k1])[k1]
            deficits=np.array([1-r['base'] for r in out])
            result=dict(n=len(out),clean_train=trained,validation=valid_score,summary=summary,
                far8_share=float(sum(r['far8_deficit'] for r in out)/deficits.sum()),
                largest8_deficit_share=float(np.sort(deficits)[-8:].sum()/deficits.sum()))
            results[ds]=result;tr.atomic_json(ROOT/'validation_audit.json',results)
            print(ds,trained,valid_score,{k:round(v['delta_pp'],3) for k,v in summary.items()},flush=True)
if __name__=='__main__':main()
