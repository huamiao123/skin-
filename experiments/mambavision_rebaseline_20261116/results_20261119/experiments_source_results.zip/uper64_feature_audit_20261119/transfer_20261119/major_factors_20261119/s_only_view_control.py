"""Check whether a second S forward alone explains the observed crop benefit, validation only."""
from scale_audit import *
@torch.inference_mode()
def run():
    tr.reference.setup()
    result={}
    for ds in ('PH2','Waterloo'):
        trained=tr.build('add').eval()
        saved=torch.load(T/ds/'uper64/best.pth',map_location='cpu')
        trained.load_state_dict(saved['model']);del saved
        x,y,meta=tr.load_split(ds,'val')
        cases=rows(ROOT/(ds+'_scale_cases.csv'))
        assert [r['id'] for r in cases]==[r['id'] for r in meta]
        for i in range(0,len(cases),32):
            batch=tr.norm(x[i:i+32])
            with torch.autocast('cuda',dtype=torch.bfloat16):
                base=trained(batch)['main'][:,0].float()
                flipped=trained(batch.flip([-1]))['main'][:,0].float().flip([-1])
            for j,(p,a,g) in enumerate(zip(base.sigmoid()>=.5,((base+flipped)*.5).sigmoid()>=.5,y[i:i+32,0]>=.5)):
                gt=g.cpu().numpy();row=cases[i+j]
                assert abs(dc(p.cpu().numpy(),gt)-float(row['base']))<1e-10
                for key in ('base','roi_up'):row[key]=float(row[key])
                row['flip_tta']=dc(a.cpu().numpy(),gt)
        score=summarize(cases,['roi_up','flip_tta'])
        score['crop_minus_flip']=summarize([dict(r,base=r['flip_tta']) for r in cases],['roi_up'])['roi_up']
        selected=[r for r in cases if int(r['crop_side'])<256]
        score['cropped_cases']=len(selected);score['n']=len(cases)
        score['crop_better_than_base']=sum(r['roi_up']>r['base'] for r in selected)
        score['crop_worse_than_base']=sum(r['roi_up']<r['base'] for r in selected)
        result[ds]=score
    tr.atomic_json(ROOT/'s_only_view_control.json',result)
    print(json.dumps(result))
if __name__=='__main__':run()
