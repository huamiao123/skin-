from pathlib import Path
import json,hashlib,time,requests,os
out=Path(__file__).resolve().parent/'official_b';out.mkdir(exist_ok=True)
repo='nvidia/MambaVision-B-1K';rev='0245cefe77658b997f2061d7f7bed0895fb22101'
names=['config.json','configuration_mambavision.py','modeling_mambavision.py','model.safetensors']
record=requests.get('https://huggingface.co/api/models/'+repo+'/revision/'+rev+'?blobs=true',timeout=20);record.raise_for_status()
items={i['rfilename']:i for i in record.json()['siblings']}
def verify(p,item):
 if not p.is_file() or p.stat().st_size!=item['size']:return False
 if 'lfs' in item:
  with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()==item['lfs']['sha256']
 b=p.read_bytes()
 return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\x00'+b).hexdigest()==item['blobId']
for name in names:
 dest=out/name;item=items[name]
 if verify(dest,item):continue
 for host in ('huggingface.co','hf-mirror.com','huggingface.co'):
  try:
   url='https://'+host+'/'+repo+'/resolve/'+rev+'/'+name+'?download=true&request='+str(time.time_ns())
   tmp=dest.with_suffix('.part')
   with requests.get(url,timeout=(15,50),stream=True) as r:
    r.raise_for_status()
    with tmp.open('wb') as f:
     for b in r.iter_content(2**20):f.write(b)
   assert verify(tmp,item),(tmp.stat().st_size,item['size'])
   tmp.replace(dest);print('verified',name,flush=True);break
  except Exception as e:print(host,name,type(e).__name__,str(e).split('?')[0][:155],flush=True)
 else:raise RuntimeError(name)
(out/'source.json').write_text(json.dumps(dict(repo=repo,revision=rev,files={n:items[n] for n in names}),indent=2))
