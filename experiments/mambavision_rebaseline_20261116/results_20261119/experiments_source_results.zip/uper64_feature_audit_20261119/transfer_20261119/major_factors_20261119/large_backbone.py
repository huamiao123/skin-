"""MambaVision-B vs the prior target-trained S, matched recipe, UPer64 and image grid."""
import csv,fcntl,gc,json,math,sys,time
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from safetensors.torch import load_file
from transformers import AutoModel
from scale_audit import tr,box
from model import SegmentationSystem,native_classes
ROOT=Path(__file__).resolve().parent
TARGET=tr.ROOT
OFFICIAL=ROOT/'official_b'
SAMPLES=('PH2','Waterloo')
SHA='ccb5ad877adfa27edfd3bc4d5d8f0b3fd9fdd9be1ec88fa25c1577471ce8201f'
def make_head(channels):
    Head,_,_=native_classes()
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(42)
        head=Head(in_channels=list(channels),in_index=[0,1,2,3],channels=64,pool_scales=(1,2,3,6),dropout_ratio=.1,
                  num_classes=2,out_channels=1,threshold=.5,norm_cfg=dict(type='SyncBN',requires_grad=True),align_corners=False,
                  loss_decode=dict(type='CrossEntropyLoss',use_sigmoid=True,loss_weight=1.))
        head.init_weights()
    return head
class Decoder(nn.Module):
    def __init__(self,dim):
        super().__init__();self.decode_head=make_head(tuple(dim*2**i for i in range(4)))
    def forward(self,features,output_size):
        return {'main':F.interpolate(self.decode_head(features),size=output_size,mode='bilinear',align_corners=False)}
class Large(SegmentationSystem):
    def __init__(self):
        nn.Module.__init__(self)
        assert tr.file_hash(OFFICIAL/'model.safetensors')==SHA
        self.encoder,info=AutoModel.from_pretrained(str(OFFICIAL),trust_remote_code=True,local_files_only=True,output_loading_info=True)
        assert not any(info.get(k) for k in ('missing_keys','unexpected_keys','mismatched_keys','error_msgs')),str(info)
        weights=load_file(str(OFFICIAL/'model.safetensors'),device='cpu');self.encoder.load_state_dict(weights,strict=True)
        self.encoder.requires_grad_(False)
        for level in self.encoder.model.levels[2:4]:level.requires_grad_(True)
        self.probe=Decoder(self.encoder.config.dim);self.train()
def train(ds):
    run=ROOT/ds/'large';run.mkdir(parents=True,exist_ok=True)
    cfg=dict(ds=ds,source_sha256=tr.file_hash(Path(__file__)),recipe_sha256=tr.file_hash(TARGET/'train_target.py'),pretrained_sha256=SHA,split_sha256=tr.file_hash(TARGET/ds/'split.csv'),epochs=100,batch=16,
             head_width=64,image_size=256,head_lr=.001,encoder_lr=.0001,adapt_stages=[3,4],seed=42,weight_decay=.01)
    if (run/'config.json').exists():assert cfg==json.loads((run/'config.json').read_text())
    if (run/'complete.json').exists():return
    tr.reference.setup();model=Large().cuda();opt=tr.optimizer(model)
    tr.atomic_json(run/'config.json',cfg)
    tr.atomic_json(run/'model.json',dict(total=sum(p.numel() for p in model.parameters()),trainable=sum(p.numel() for p in model.parameters() if p.requires_grad),decoder=sum(p.numel() for p in model.probe.parameters()),initial_state=tr.initial_digest(model)))
    x,g,_=tr.load_split(ds,'train');val=tr.load_split(ds,'val')
    history=[];best=-1;resume=run/'resume.pth'
    if resume.exists():
        obj=torch.load(resume,map_location='cpu');assert obj['config']==cfg
        model.load_state_dict(obj['model']);opt.load_state_dict(obj['optim']);tr.restore_rng(obj['rng']);history=obj['history'];del obj
    if (run/'best.pth').exists():
        saved=torch.load(run/'best.pth',map_location='cpu');assert saved['config']==cfg;best=saved['score'];del saved
    for epoch in range(len(history)+1,101):
        tic=time.monotonic()
        factor=.01+.99*(1+math.cos(math.pi*(epoch-1)/100))/2
        for group in opt.param_groups:group['lr']=group['initial_lr']*factor
        model.train();order,image,target=tr.geometry(x,g,epoch);image=tr.norm(image)
        total=0
        for j,idx in enumerate(order.split(16)):
            assert len(idx)>1
            opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda',dtype=torch.bfloat16):z=model(image[idx])['main'].float()
            loss=tr.segmentation_loss(z,target[idx]);assert torch.isfinite(loss)
            loss.backward()
            norms=[float(nn.utils.clip_grad_norm_(group['params'],1.,error_if_nonfinite=True)) for group in opt.param_groups]
            if j==0 and epoch==1:
                assert min(norms)>0
                tr.atomic_json(run/'first_update.json',dict(gradient_norm=norms,loss=float(loss.detach())))
            opt.step();total+=float(loss.detach())*len(idx)
        score,rows=tr.evaluate(model,val)
        history.append(dict(epoch=epoch,loss=total/len(order),validation=score,sec=time.monotonic()-tic))
        if score>best:
            best=score;tr.atomic_save(run/'best.pth',dict(config=cfg,epoch=epoch,score=score,model=tr.base.cpu_tree(model.state_dict())))
        tr.atomic_json(run/'history.json',history)
        if epoch in (40,80):tr.atomic_save(resume,dict(config=cfg,history=history,model=tr.base.cpu_tree(model.state_dict()),optim=tr.base.cpu_tree(opt.state_dict()),rng=tr.rng_state()))
        if epoch==1 or epoch%10==0:print(ds,epoch,score,best,flush=True)
    obj=torch.load(run/'best.pth',map_location='cpu');model.load_state_dict(obj['model'])
    score,rows=tr.evaluate(model,val);assert abs(score-obj['score'])<1e-10
    tr.write_rows(run/'best_validation.csv',rows)
    train_score,_=tr.evaluate(model,tr.load_split(ds,'train'))
    tr.atomic_json(run/'complete.json',dict(best_epoch=obj['epoch'],val_dice=score,train_dice=train_score,best_sha256=tr.file_hash(run/'best.pth')))
    if resume.exists():resume.unlink()
if __name__=='__main__':
    with (ROOT/'large.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for ds in SAMPLES:
            train(ds);gc.collect();torch.cuda.empty_cache()
