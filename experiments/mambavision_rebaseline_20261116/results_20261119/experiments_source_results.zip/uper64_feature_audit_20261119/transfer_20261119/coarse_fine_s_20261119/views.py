"""Cache whole-image and raw ROI views from a single shared MambaVision-S per case."""
import csv,hashlib,math,sys,zipfile
import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F
from folds import ROOT,TARGET,SCRATCH,folds,tr
sys.path.insert(0,str(ROOT.parent/'major_factors_20261119'))
from scale_audit import box,crop_at,resized,raw_image,E,rows

def regions(mask,rng=None):
    if not mask.any() or mask.all():return []
    l,t,r,b=box(mask);side=r-l
    if side==256:
        s=160 if rng is None else int(rng.integers(148,177))
        return [(x,y,x+s,y+s) for y in (0,256-s) for x in (0,256-s)]
    if rng is not None:
        s=int(np.clip(round(side*rng.uniform(.9,1.1)),64,255))
        x=int(np.clip(round((l+r-s)/2+rng.uniform(-.06,.06)*side),0,256-s))
        y=int(np.clip(round((t+b-s)/2+rng.uniform(-.06,.06)*side),0,256-s))
        return [(x,y,x+s,y+s)]
    return [(l,t,r,b)]

def scaled(x,size):
    return F.interpolate(x,size=(size,size),mode='bilinear',align_corners=False)
def crop_global_feature(f,bb):
    x,y,r,b=bb;side=r-x
    yy,xx=torch.meshgrid(torch.arange(32,device=f.device)+.5,torch.arange(32,device=f.device)+.5,indexing='ij')
    grid=torch.stack((2*(x+xx*side/32)/256-1,2*(y+yy*side/32)/256-1),dim=-1)
    return F.grid_sample(f.float()[None],grid[None],mode='bilinear',padding_mode='border',align_corners=False)[0].to(torch.bfloat16)

@torch.no_grad()
def view(model,images):
    x=torch.from_numpy(np.stack(images)).permute(0,3,1,2).contiguous().cuda().float()/255
    with torch.autocast('cuda',dtype=torch.bfloat16):
        f1,f2,mid=model.prefix(tr.norm(x))
        z=model.from_cache(f1,f2,mid,(256,256))['main'].float()
    assert torch.isfinite(z).all()
    return z[:,0],f1,f2

def edge_weights(bb,device):
    x,y,r,b=bb;s=r-x
    axis=torch.arange(s,device=device).float()
    def weights(lo,hi):
        w=torch.ones_like(axis)
        if lo>0:w=torch.minimum(w,(axis+1)/12)
        if hi<256:w=torch.minimum(w,(s-axis)/12)
        return w
    return weights(y,b)[:,None]*weights(x,r)[None,:]

@torch.no_grad()
def subset(model,ds,meta,truth,indices,aug,zf,manifest,provided=None,include_legacy=True):
    response=[]
    for start in range(0,len(indices),32):
        ids=indices[start:start+32]
        original=[provided[i] for i in ids] if provided is not None else [raw_image(ds,manifest[(ds,meta[i]['id'])],zf) for i in ids]
        if aug:original=[im.transpose(Image.Transpose.FLIP_LEFT_RIGHT) for im in original]
        rgb=[resized(im,256) for im in original]
        global_z,_,global_f2=view(model,rgb)
        patches=[];lower=[];pending=[];records=[]
        for j,i in enumerate(ids):
            g=truth[i,0].bool().cpu() if truth is not None else None
            if aug and g is not None:g=g.flip([-1])
            base=global_z[j];mask=(base.sigmoid()>=.5).cpu().numpy()
            rec=dict(id=meta[i]['id'],group=meta[i]['group'],g=g,base=base.cpu(),patches=[],legacy=base.cpu().clone())
            records.append(rec)
            seed=int.from_bytes(hashlib.sha256(meta[i]['id'].encode()).digest()[:4],'little')
            boxes=regions(mask,np.random.default_rng(seed) if aug else None)
            for bb in boxes:
                patches.append(resized(crop_at(original[j],bb),256))
                pending.append((j,bb))
            old=box(mask)
            if include_legacy and not aug and old[2]-old[0]<256:
                lower.append((j,old,resized(crop_at(Image.fromarray(rgb[j]),old),256)))
        for n in range(0,len(patches),8):
            logits,f1,f2=view(model,patches[n:n+8])
            for k,(j,bb) in enumerate(pending[n:n+8]):
                x,y,r,b=bb
                base=records[j]['base']
                coarse64=scaled(base[None,None,y:b,x:r].cuda(),64)[0]
                local64=scaled(logits[k,None,None],64)[0]
                pp=dict(bb=bb,shallow=f1[k].cpu().clone(),mid=f2[k].cpu().clone(),context=crop_global_feature(global_f2[j],bb).cpu(),
                    evidence=torch.cat((coarse64,local64),dim=0).cpu(),local=scaled(logits[k,None,None],r-x)[0,0].cpu(),
                    weight=edge_weights(bb,'cpu'))
                records[j]['patches'].append(pp)
        for n in range(0,len(lower),8):
            ls=lower[n:n+8];old_logits,_,_=view(model,[r[2] for r in ls])
            for k,(j,(x,y,r,b),_) in enumerate(ls):
                rec=records[j]
                rec['legacy'][y:b,x:r]=(rec['base'][y:b,x:r]+scaled(old_logits[k,None,None],r-x)[0,0].cpu())*.5
        response.extend(records)
    return response

def get_cache(ds,split):
    out=SCRATCH/ds
    path=out/(split+'_rois.pth')
    if path.exists():return torch.load(path,map_location='cpu')
    _,gt,meta=tr.load_split(ds,split);idx=np.arange(len(meta));train=split=='train'
    assignments=folds(meta) if train else np.zeros(len(meta),int)
    manifest={(r['dataset'],r['id']):r for r in rows(E/'manifest.csv')}
    result=[{},{}] if train else [{}]
    tr.reference.setup()
    with zipfile.ZipFile(E/'data/waterloo.zip') as zf:
        for k in sorted(set(assignments)):
            ck=out/f'fold{k}.pth' if train else TARGET/ds/'uper64/best.pth'
            model=tr.build('add').eval();saved=torch.load(ck,map_location='cpu');model.load_state_dict(saved['model'],strict=True);del saved
            for v,hold in enumerate(result):
                batch=subset(model,ds,meta,gt,idx[assignments==k],bool(v),zf,manifest)
                hold.update({r['id']:r for r in batch})
            del model
    result=[[hold[m['id']] for m in meta] for hold in result]
    if not train:
        fname='best_validation.csv' if split=='val' else 'test_per_image.csv'
        old={r['id']:r for r in rows(TARGET/ds/'uper64'/fname)}
        for r in result[0]:
            p=r['base'].sigmoid()>=.5;g=r['g']
            counts=[int(t.sum()) for t in (p&g,p&~g,~p&g)]
            assert counts==[int(old[r['id']][k]) for k in ('tp','fp','fn')],(ds,split,r['id'])
    tr.atomic_save(path,result);return result
