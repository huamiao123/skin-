"""Predict one image without an annotation. The output mask is on the evaluation grid."""
import argparse
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from folds import ROOT,TARGET,DATASETS,tr
from views import subset
from refine import device_data,make_module,predict

@torch.inference_mode()
def run_image(rgb,coarse,decoder):
    entries=[dict(id='inference',group='inference')]
    r=subset(coarse,None,entries,None,[0],False,None,None,provided=[rgb.convert('RGB')],include_legacy=False)
    assert r[0]['g'] is None
    z,_=predict(device_data(r),decoder)
    return (z[0,0].float().sigmoid()>=.5).cpu().numpy()

def load(ds,arm='gated'):
    coarse=tr.build('add').eval()
    ref=TARGET/ds/'uper64/best.pth'
    payload=torch.load(ROOT/ds/arm/'best.pth',map_location='cpu')
    assert payload['config']['coarse_weight_sha']==tr.file_hash(ref)
    coarse.load_state_dict(torch.load(ref,map_location='cpu')['model'],strict=True)
    decoder=make_module(arm).eval();decoder.load_state_dict(payload['module'],strict=True)
    return coarse,decoder
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',choices=DATASETS,required=True);p.add_argument('--arm',choices=('fixed','gated'),default='gated')
    p.add_argument('--image',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
    args=p.parse_args()
    if args.output.exists():p.error('output file already exists')
    tr.reference.setup();models=load(args.dataset,args.arm)
    with Image.open(args.image) as im:mask=run_image(im,*models)
    args.output.parent.mkdir(exist_ok=True,parents=True)
    Image.fromarray(mask.astype(np.uint8)*255).save(args.output,format='PNG')
