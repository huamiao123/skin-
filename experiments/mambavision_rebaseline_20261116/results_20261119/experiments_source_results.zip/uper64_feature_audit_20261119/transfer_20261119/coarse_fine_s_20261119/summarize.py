import csv,json,math,statistics
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
T=ROOT.parent/'target_training_20261119'
def read(p):return json.loads(p.read_text())
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
def main():
    names={'single':'整图 MambaVision-S + UPer64','one_box':'原先的单框等权平均','matched_average':'相同原图窗口，直接平均','fixed':'训练区域解码器，固定融合权重','gated':'训练区域解码器，学习融合权重（主方法）'}
    lines=['# 固定 MambaVision-S 的粗到细实验','','原图与局部视图共享一套目标数据训练的 MambaVision-S + UPer64 权重。PH² 和 Waterloo 分别训练，使用上轮固定划分。下表均为逐图前景 Dice 的算术平均。','','| 方法 | PH² 验证（40） | PH² 测试（40） | Waterloo 验证（41） | Waterloo 测试（41） |','|---|---:|---:|---:|---:|']
    stats={(ds,sp):read(ROOT/ds/(sp+'_metrics.json')) for ds in ('PH2','Waterloo') for sp in ('val','test')}
    for k,name in names.items():
        lines.append('| '+name+' | '+' | '.join(f"{100*s['dice'][k]:.4f}%" for s in stats.values())+' |')
    lines+=['','## 学习融合的配对差值','','按可识别病灶组配对自举 10,000 次，区间反映固定权重下的病例抽样差异。未测量多种子训练方差。','','| 数据与分区 | 比整图 | 比原单框 | 比同窗口平均 [95% 区间] | 比训练后固定权重 |','|---|---:|---:|---:|---:|']
    sub={}
    for (ds,sp),v in stats.items():
        d=v['differences'];cmp=d['matched_average'];lo,hi=cmp['group_ci95_pp']
        lines.append(f"| {ds} {sp} | {d['single']['delta_pp']:+.4f} | {d['one_box']['delta_pp']:+.4f} | {cmp['delta_pp']:+.4f} [{lo:+.4f}, {hi:+.4f}] | {d['fixed']['delta_pp']:+.4f} |")
        expected=rows(T/ds/('uper64/best_validation.csv' if sp=='val' else 'uper64/test_per_image.csv'))
        table={}
        for arm in names:
            rr=rows(ROOT/ds/f'{sp}_{arm}.csv');assert [r['id'] for r in rr]==[r['id'] for r in expected]
            for r,e in zip(rr,expected):
                tp,fp,fn=[int(r[k]) for k in ('tp','fp','fn')]
                assert tp+fn==int(e['tp'])+int(e['fn'])
                assert abs(float(r['dice'])-2*tp/(2*tp+fp+fn))<1e-12
                if arm=='single':assert all(int(r[k])==int(e[k]) for k in ('tp','fp','fn'))
            assert abs(statistics.mean(float(r['dice']) for r in rr)-v['dice'][arm])<1e-12
            table[arm]=rr
        sub[ds+'_'+sp]={}
        for count in (0,1,4):
            ids=[j for j,r in enumerate(table['gated']) if int(r['n_patches'])==count]
            if ids:
                sub[ds+'_'+sp][str(count)]=dict(n=len(ids),dice={k:statistics.mean(float(rr[j]['dice']) for j in ids) for k,rr in table.items()})
    (ROOT/'window_groups.json').write_text(json.dumps(sub,indent=2))
    lines+=['','## 复现与解释','','每次推理共享同一 S 骨干。带余量病灶框使用一个局部视图；若框占满全图，使用四个重叠局部视图；若粗掩膜恒空或恒满则保留整图预测。旧单框基线在框占满全图时直接返回。新版本会增加局部读取次数。新增区域头读取局部浅层特征、对齐的全图特征和两路 logits；固定权重与学习权重两组使用相同区域和监督。两组新增约 63.5 万参数。','',
        '先用同一训练分区内部的三折、每折固定 48 轮 S 产生折外训练输入。第二阶段训练 32 轮，仅按验证选权重，评估时的粗模型来自各自目标数据集。所有四份新增头锁定后统一运行测试。各次实验共用这两套测试划分，后续的独立验证仍有价值。','',
        '输入单张图片的入口为 predict_image.py。示例命令为下，输出为与实验一致的 256×256 PNG 掩膜。','','```bash','python predict_image.py --dataset Waterloo --image lesion.jpg --output predicted.png','```','',
        '精确参数量和最佳轮次保存在各方法的 complete.json；逐图 TP、FP、FN 和 Dice 分别保存在 PH2/、Waterloo/。与原 S 权重配对使用的新增头为各数据集 gated/best.pth 和 fixed/best.pth。训练、验证、测试无需 ISIC 分割权重。方法来源、训练协议与适配理由见[调研记录](literature/deep_research_report.md)。']
    (ROOT/'RESULTS_zh.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines[:19]))
if __name__=='__main__':main()
