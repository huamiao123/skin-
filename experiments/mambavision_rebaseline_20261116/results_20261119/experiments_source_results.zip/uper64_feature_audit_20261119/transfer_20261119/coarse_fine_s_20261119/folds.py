"""Out-of-fold target-only MambaVision-S coarse predictions for training the refiner."""
import csv,fcntl,gc,json,math,sys,time,tempfile,hashlib
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np
import torch
ROOT=Path(__file__).resolve().parent
TARGET=ROOT.parent/'target_training_20261119'
sys.path.insert(0,str(TARGET))
import train_target as tr
DATASETS=('PH2','Waterloo')
SCRATCH=Path('/tmp')/('mvs_cf_'+hashlib.sha256(str(ROOT).encode()).hexdigest()[:16])
def folds(meta):
    groups=defaultdict(list)
    for ix,r in enumerate(meta):groups[(r['stratum'],r['group'])].append(ix)
    rng=np.random.default_rng(42);assign=np.full(len(meta),-1);all_sizes=np.zeros(3,int)
    for label in sorted({r['stratum'] for r in meta}):
        keys=[k for k in groups if k[0]==label];rng.shuffle(keys);keys.sort(key=lambda k:-len(groups[k]))
        counts=np.zeros(3,int)
        for key in keys:
            choice=min(rng.permutation(3),key=lambda f:(counts[f],all_sizes[f]))
            ids=groups[key];assign[ids]=choice;counts[choice]+=len(ids);all_sizes[choice]+=len(ids)
    assert set(assign)=={0,1,2}
    assert all(len(set(assign[ids]))==1 for ids in groups.values())
    return assign
def fit(ds):
    x,y,meta=tr.load_split(ds,'train');f=folds(meta);scratch=SCRATCH/ds;scratch.mkdir(parents=True,exist_ok=True)
    out=ROOT/ds;out.mkdir(exist_ok=True)
    tr.write_rows(out/'train_folds.csv',[dict(id=r['id'],group=r['group'],stratum=r['stratum'],fold=int(i)) for r,i in zip(meta,f)])
    for k in range(3):
        dest=scratch/f'fold{k}.pth';record=out/f'fold{k}.json'
        if record.exists() and dest.exists() and json.loads(record.read_text())['weight_sha']==tr.file_hash(dest):continue
        tr.reference.setup();model=tr.build('add',seed=42);opt=tr.optimizer(model)
        keep=np.where(f!=k)[0];sub=x[keep];gt=y[keep];tic=time.time();epochs=48
        for epoch in range(1,epochs+1):
            model.train();order,img,target=tr.geometry(sub,gt,epoch);img=tr.norm(img)
            for g in opt.param_groups:g['lr']=g['initial_lr']*(.01+.99*(1+math.cos(math.pi*(epoch-1)/epochs))/2)
            batches=list(order.split(16))
            if len(batches)>1 and len(batches[-1])==1:batches[-2:]=[torch.cat(batches[-2:])]
            for ix in batches:
                opt.zero_grad(set_to_none=True)
                with torch.autocast('cuda',dtype=torch.bfloat16):z=model(img[ix])['main'].float()
                loss=tr.segmentation_loss(z,target[ix]);loss.backward()
                for g in opt.param_groups:torch.nn.utils.clip_grad_norm_(g['params'],1.,error_if_nonfinite=True)
                opt.step()
            if epoch%16==0:print(ds,k,epoch,flush=True)
        tr.atomic_save(dest,{'model':tr.base.cpu_tree(model.state_dict())})
        tr.atomic_json(record,dict(fold=k,epochs=epochs,n_fit=len(keep),n_excluded=int(sum(f==k)),weight_sha=tr.file_hash(dest),encoder_init=tr.WEIGHT_SHA256,seconds=time.time()-tic))
        del model,opt;gc.collect();torch.cuda.empty_cache()
if __name__=='__main__':
    with (ROOT/'oof.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for dataset in DATASETS:fit(dataset)
