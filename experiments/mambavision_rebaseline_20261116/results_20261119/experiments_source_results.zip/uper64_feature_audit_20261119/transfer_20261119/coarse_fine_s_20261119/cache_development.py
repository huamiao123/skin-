import gc,time,json
import torch
from views import get_cache,ROOT
from folds import DATASETS
for ds in DATASETS:
    if not (ROOT/ds/'fold2.json').is_file():raise RuntimeError('out-of-fold models incomplete')
    for split in ('train','val'):
        sets=get_cache(ds,split)
        print(ds,split,[len(v) for v in sets],[sum(len(r['patches']) for r in v) for v in sets],flush=True)
        del sets;gc.collect();torch.cuda.empty_cache()
