"""Learn a regional decoder and optional pixelwise scale weighting above the shared S."""
import gc,fcntl,json,math,time
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from views import get_cache,scaled
from folds import ROOT,TARGET,tr,DATASETS

ARMS=('fixed','gated')
EPOCHS=32
def conv(a,b,k=3,d=1):
    return nn.Sequential(nn.Conv2d(a,b,k,padding=(k//2)*d,dilation=d,bias=False),nn.GroupNorm(8,b),nn.GELU())
class RegionalDecoder(nn.Module):
    def __init__(self,learn_gate):
        super().__init__()
        self.shallow=conv(96,48,1)
        self.mid=conv(192,48,1)
        self.context=conv(192,48,1)
        self.stem=conv(48*3+2,128,3)
        self.blocks=nn.ModuleList(conv(128,128,3,d) for d in (1,2,4))
        self.correction=nn.Conv2d(128,1,1)
        self.gate=nn.Conv2d(128,1,1) if learn_gate else None
        nn.init.zeros_(self.correction.weight);nn.init.zeros_(self.correction.bias)
        if self.gate is not None:nn.init.zeros_(self.gate.weight);nn.init.zeros_(self.gate.bias)
    def forward(self,patches):
        def stack(k):return torch.stack([p[k] for p in patches])
        ev=stack('evidence')
        with torch.autocast('cuda',dtype=torch.bfloat16):
            local=self.shallow(stack('shallow'))
            mid=scaled(self.mid(stack('mid')),64);global_mid=scaled(self.context(stack('context')),64)
            h=self.stem(torch.cat([local,mid,global_mid,ev.to(local.dtype)],1))
            for block in self.blocks:h=h+block(h)
            correction=self.correction(h).float()
            gate=self.gate(h).float().sigmoid() if self.gate is not None else torch.full_like(correction,.5)
        return correction,gate

def device_data(data):
    def move(v):
        if torch.is_tensor(v):return v.to('cuda')
        if isinstance(v,list):return [move(r) for r in v]
        if isinstance(v,dict):return {k:move(t) for k,t in v.items()}
        return v
    return move(data)
def predict(records,module=None,auxiliary=False):
    patches=[p for r in records for p in r['patches']]
    if module is not None and patches:cor,gate=module(patches)
    outputs=[];pos=0;aux_z=[];aux_y=[]
    for r in records:
        base=r['base'];updates=[];weights=[]
        for p in r['patches']:
            x,y,end,bottom=p['bb'];side=end-x;pad=(x,256-end,y,256-bottom)
            z=p['local']
            if module is None:alpha=.5
            else:
                z=z+scaled(cor[pos:pos+1],side)[0,0]
                alpha=scaled(gate[pos:pos+1],side)[0,0]
                if auxiliary:
                    aux_z.append(p['evidence'][1]+cor[pos,0])
                    target=r['g'][None,None,y:bottom,x:end].float()
                    aux_y.append(F.interpolate(target,size=(64,64),mode='nearest')[0,0])
            updates.append(F.pad(p['weight']*alpha*(z-base[y:bottom,x:end]),pad))
            weights.append(F.pad(p['weight'],pad))
            pos+=1
        if updates:
            outputs.append(base+torch.stack(updates).sum(0)/torch.stack(weights).sum(0).clamp_min(1.))
        else:outputs.append(base)
    loss_aux=tr.segmentation_loss(torch.stack(aux_z)[:,None],torch.stack(aux_y)[:,None]) if aux_z else None
    return torch.stack(outputs)[:,None],loss_aux
@torch.inference_mode()
def evaluate(data,module=None):
    if module is not None:module.eval()
    ret=[]
    for first in range(0,len(data),6):
        chunk=data[first:first+6]
        out,_=predict(chunk,module)
        assert torch.isfinite(out).all()
        for r,logits in zip(chunk,out[:,0]):
            gt=r['g'];coarse=r['base'].sigmoid()>=.5;pred=logits.sigmoid()>=.5
            tp=int((gt&pred).sum());fp=int((~gt&pred).sum());fn=int((gt&~pred).sum())
            den=2*tp+fp+fn
            area=torch.zeros_like(gt)
            for p in r['patches']:
                x,y,right,b=p['bb'];area[y:b,x:right]=True
            assert torch.equal(logits[~area],r['base'][~area])
            ret.append(dict(id=r['id'],group=r['group'],n_patches=len(r['patches']),tp=tp,fp=fp,fn=fn,dice=2*tp/den if den else 1.,
                            fixed_pixels=int(((coarse!=gt)&(pred==gt)).sum()),broken_pixels=int(((coarse==gt)&(pred!=gt)).sum()),
                            lesion_outside_windows=int((gt&~area).sum()),gt_area=int(gt.sum())))
    return float(np.mean([r['dice'] for r in ret])),ret
def basic(data,key):
    rows=[]
    for r in data:
        p=r[key].sigmoid()>=.5;g=r['g'];tp=int((p&g).sum());fp=int((p&~g).sum());fn=int((~p&g).sum());den=2*tp+fp+fn
        rows.append(dict(id=r['id'],group=r['group'],dice=2*tp/den if den else 1.,tp=tp,fp=fp,fn=fn))
    return rows
def make_module(arm):
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(42)
        return RegionalDecoder(arm=='gated').cuda()
def lock_cfg(ds,arm):
    source=ROOT/'refine.py'
    return dict(ds=ds,arm=arm,epochs=EPOCHS,seed=42,batch=6,BASE='MambaVision-S + UPer64',threshold=.5,grid=256,
        coarse_weight_sha=tr.file_hash(TARGET/ds/'uper64/best.pth'),split_sha=tr.file_hash(TARGET/ds/'split.csv'),
        source_sha=tr.file_hash(source),views_sha=tr.file_hash(ROOT/'views.py'),folds_sha=tr.file_hash(ROOT/'folds.py'),
        train_folds_sha=tr.file_hash(ROOT/ds/'train_folds.csv'),fold_checkpoint_hashes=[json.loads((ROOT/ds/f'fold{k}.json').read_text())['weight_sha'] for k in range(3)])
def train(ds,arm,data,dev):
    dest=ROOT/ds/arm;dest.mkdir(exist_ok=True)
    cfg=lock_cfg(ds,arm)
    if (dest/'complete.json').exists():
        assert json.loads((dest/'config.json').read_text())==cfg
        return
    tr.reference.setup();module=make_module(arm);tr.atomic_json(dest/'config.json',cfg)
    opt=torch.optim.AdamW(module.parameters(),lr=.0003,weight_decay=.01)
    fixed_score,fixed_rows=evaluate(dev,None);best,rows=evaluate(dev,module)
    assert all((r['tp'],r['fp'],r['fn'])==(s['tp'],s['fp'],s['fn']) for r,s in zip(rows,fixed_rows))
    history=[dict(epoch=0,validation=best)]
    tr.atomic_save(dest/'best.pth',dict(module=module.state_dict(),config=cfg,epoch=0,score=best))
    for epoch in range(1,EPOCHS+1):
        module.train()
        opt.param_groups[0]['lr']=.0003*(.05+.95*(1+math.cos(math.pi*(epoch-1)/EPOCHS))/2)
        rng=np.random.default_rng(42+epoch);order=rng.permutation(len(data[0]));aug=rng.integers(2,size=len(order))
        total=0.;n=0
        for first in range(0,len(order),6):
            chunk=[data[aug[i]][i] for i in order[first:first+6]]
            if not any(r['patches'] for r in chunk):continue
            z,extra=predict(chunk,module,auxiliary=True)
            y=torch.stack([r['g'] for r in chunk])[:,None].float()
            loss=tr.segmentation_loss(z,y)+.25*extra
            opt.zero_grad(set_to_none=True);loss.backward()
            grad=float(nn.utils.clip_grad_norm_(module.parameters(),1.,error_if_nonfinite=True))
            if epoch==1 and n==0:assert math.isfinite(grad) and grad>0
            opt.step();n+=len(chunk);total+=float(loss.detach())*len(chunk)
        score,vr=evaluate(dev,module)
        history.append(dict(epoch=epoch,validation=score,loss=total/n))
        if score>best:
            best=score;tr.atomic_save(dest/'best.pth',dict(module=module.state_dict(),config=cfg,epoch=epoch,score=best))
        tr.atomic_json(dest/'history.json',history)
        if epoch==1 or epoch%8==0:print(ds,arm,epoch,'val',score,'best',best,flush=True)
    ck=torch.load(dest/'best.pth',map_location='cpu');module.load_state_dict(ck['module'])
    score,vr=evaluate(dev,module);assert abs(score-ck['score'])<1e-10
    tr.write_rows(dest/'val.csv',vr)
    tr.atomic_json(dest/'complete.json',dict(best_epoch=ck['epoch'],score=score,epochs=EPOCHS,extra_parameters=sum(p.numel() for p in module.parameters()),best_sha=tr.file_hash(dest/'best.pth')))
def compare(a,b):
    assert [(r['id'],r['group']) for r in a]==[(r['id'],r['group']) for r in b]
    delta=np.array([100*(r['dice']-s['dice']) for r,s in zip(a,b)])
    groups=sorted({r['group'] for r in a});labs=np.array([r['group'] for r in a]);sums=np.array([delta[labs==g].sum() for g in groups]);sizes=np.array([(labs==g).sum() for g in groups])
    draw=np.random.default_rng(42).integers(len(groups),size=(10000,len(groups)))
    return dict(delta_pp=float(delta.mean()),group_ci95_pp=np.quantile(sums[draw].sum(1)/sizes[draw].sum(1),[.025,.975]).tolist(),improved=int((delta>0).sum()),worsened=int((delta<0).sum()))
def final(ds,split,data):
    result=dict(single=basic(data,'base'),one_box=basic(data,'legacy'),matched_average=evaluate(data,None)[1])
    for arm in ARMS:
        ck=torch.load(ROOT/ds/arm/'best.pth',map_location='cpu');assert ck['config']==lock_cfg(ds,arm)
        module=make_module(arm);module.load_state_dict(ck['module']);result[arm]=evaluate(data,module)[1]
    for k,v in result.items():tr.write_rows(ROOT/ds/f'{split}_{k}.csv',v)
    stats=dict(n=len(data),views=dict((int(n),sum(len(r['patches'])==n for r in data)) for n in (0,1,4)),dice={k:float(np.mean([r['dice'] for r in v])) for k,v in result.items()},
        differences={k:compare(result['gated'],result[k]) for k in ['single','one_box','matched_average','fixed']},fixed_minus_avg=compare(result['fixed'],result['matched_average']),
        best_epochs={k:json.loads((ROOT/ds/k/'complete.json').read_text())['best_epoch'] for k in ARMS})
    tr.atomic_json(ROOT/ds/f'{split}_metrics.json',stats)
    print(ds,split,stats['dice'],flush=True)
def main():
    for ds in DATASETS:
        data=device_data(get_cache(ds,'train'));dev=device_data(get_cache(ds,'val')[0])
        for arm in ARMS:train(ds,arm,data,dev)
        final(ds,'val',dev);del data,dev;gc.collect();torch.cuda.empty_cache()
    for ds in DATASETS:
        for arm in ARMS:
            dest=ROOT/ds/arm;assert json.loads((dest/'complete.json').read_text())['best_sha']==tr.file_hash(dest/'best.pth')
    for ds in DATASETS:
        test=device_data(get_cache(ds,'test')[0]);final(ds,'test',test);del test;gc.collect();torch.cuda.empty_cache()
if __name__=='__main__':
    with (ROOT/'refine.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);main()
