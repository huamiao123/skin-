"""Validate no-label inference and patch-coordinate invariants on validation images."""
import json,zipfile
import numpy as np,torch
from predict_image import load,run_image
from views import E,raw_image,regions,rows
from folds import ROOT,DATASETS,tr
def checks():
    for mask in (np.zeros((256,256),bool),np.ones((256,256),bool)):assert regions(mask)==[]
    a=np.zeros((256,256),bool);a[112:128,15:48]=True
    rect=regions(a);assert len(rect)==1
    x,y,r,b=rect[0];assert x<=15<48<=r and y<=112<128<=b
    a[0:255,5:251]=True;windows=regions(a);assert len(windows)==4
    cover=np.zeros_like(a)
    for x,y,r,b in windows:cover[y:b,x:r]=True
    assert cover.all()
def run():
    tr.reference.setup();checks()
    manifest={(r['dataset'],r['id']):r for r in rows(E/'manifest.csv')}
    out={}
    with zipfile.ZipFile(E/'data/waterloo.zip') as z:
        for ds in DATASETS:
            coarse,decoder=load(ds);baseline=rows(ROOT/ds/'gated'/'val.csv')
            _,gt,meta=tr.load_split(ds,'val');ids={r['id']:i for i,r in enumerate(meta)}
            checks_rows=[]
            for number in (1,4):
                record=next(r for r in baseline if int(r['n_patches'])==number)
                sid=record['id'];im=raw_image(ds,manifest[(ds,sid)],z)
                pred=run_image(im,coarse,decoder);target=gt[ids[sid],0].bool().cpu().numpy()
                assert pred.shape==target.shape==(256,256)
                tp=int((pred & target).sum());fp=int((pred & ~target).sum());fn=int((~pred & target).sum())
                d=2*tp/(2*tp+fp+fn)
                counts_delta=[tp-int(record['tp']),fp-int(record['fp']),fn-int(record['fn'])]
                checks_rows.append(dict(id=sid,n_windows=number,counts_delta=counts_delta,macro_case_delta_pp=100*(d-float(record['dice']))))
                assert abs(d-float(record['dice']))<.002
            out[ds]=checks_rows;del coarse,decoder
    tr.atomic_json(ROOT/'inference_checks.json',out);print(out)
if __name__=='__main__':run()
