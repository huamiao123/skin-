"""Fixed protocol: learn 16x16 fractional lesion coverage on the existing ISIC control's train features."""
from pathlib import Path
import sys,json,csv
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from scipy.ndimage import distance_transform_edt
from coverage import ROOT,PR,SENS,DIAG,roi,dice

sys.path.insert(0,str(PR/'src'))
from model import SegmentationSystem,load_pretrained_encoder,sha256
from train_mb64 import reference,atomic_json
EPOCHS=24
class Extent(nn.Module):
    def __init__(self):
        super().__init__()
        self.local=nn.Sequential(nn.Conv2d(1344,96,1,bias=False),nn.GroupNorm(8,96),nn.GELU())
        self.mix=nn.Sequential(nn.Conv2d(96,96,3,padding=2,dilation=2,bias=False),nn.GroupNorm(8,96),nn.GELU(),nn.Conv2d(96,1,1))
    def forward(self,x):
        h=self.local(x)
        return self.mix(h+F.adaptive_avg_pool2d(h,1))
def resize(x,size):
    return F.interpolate(x,size=(size,size),mode='bilinear',align_corners=False)
@torch.no_grad()
def features(split,data,model,old):
    feats=[];targets=[]
    for start in range(0,len(data.ids[split]),64):
        ix=torch.arange(start,min(start+64,len(data.ids[split])),device='cuda')
        x,y=data.batch(split,ix)
        with torch.autocast('cuda',dtype=torch.bfloat16):
            f1,f2,mid=model.prefix(x);f3,f4=model.suffix(mid)
            if split=='val':
                b=model.probe([f1,f2,f3,f4],(256,256))['main'][:,0].float().sigmoid().cpu().numpy()
                assert np.array_equal(b>=.5,old[start:start+len(ix)]>=.5)
        v=torch.cat([F.avg_pool2d(f2.float(),2),f3.float(),resize(f4.float(),16)],1)
        feats.append(v.to(torch.bfloat16));targets.append(F.avg_pool2d((y>=.5).float(),16))
    return torch.cat(feats),torch.cat(targets)
def add_quota(p,b,k):
    if k==0:return b.copy()
    idx=np.flatnonzero(~b)
    # Stable index order within equal probability ties.
    score=p.ravel()[idx]
    threshold=np.partition(score,len(score)-k)[len(score)-k]
    chosen=np.concatenate((idx[score>threshold],idx[score==threshold][:k-int((score>threshold).sum())]))
    mask=b.copy();mask.ravel()[chosen]=True;return mask

def main():
    reference.setup()
    ck=PR/'results/stageB_color_20261117/control/best_dice.pth'
    expected=json.load((PR/'reports/STAGEC_SENSITIVITY_PROTOCOL.json').open())['checkpoints']['control']['sha256']
    assert sha256(ck)==expected
    config=dict(seed=42,source_checkpoint_sha=expected,grid=16,epochs=EPOCHS,lr=.0005,weight_decay=.01,
        target='fraction of pixels annotated foreground in each 16x16 cell',
        primary_rule='keep base foreground and add positions with bilinearly expanded predicted occupancy >= 0.80',
        diagnostic_only=True,test_read=False,comparison='same per-image added area by highest scores of original background',select='fixed last epoch')
    atomic_json(ROOT/'region_protocol.json',config)
    data,partition=reference.load_data()
    assert len(data.ids['train'])==1886 and len(data.ids['val'])==762
    record=list(csv.DictReader((SENS/'intact_per_image.csv').open()));assert [r['id'] for r in record]==data.ids['val']
    pval=np.load(SENS/'intact_validation_probabilities_fp32.npy',mmap_mode='r')
    m=SegmentationSystem(load_pretrained_encoder(),'A-64-noaux',42).cuda().eval().requires_grad_(False)
    m.load_state_dict(torch.load(ck,map_location='cpu')['model'],strict=True)
    train,y=features('train',data,m,pval);valid,yval=features('val',data,m,pval)
    gt=(data.masks['val'][:,0]>=128).cpu().numpy()
    del m,data;torch.cuda.empty_cache()
    torch.manual_seed(42);reg=Extent().cuda()
    opt=torch.optim.AdamW(reg.parameters(),lr=.0005,weight_decay=.01)
    for ep in range(1,EPOCHS+1):
        reg.train();order=torch.randperm(len(train),generator=torch.Generator().manual_seed(42+ep)).cuda();summed=0.
        for ix in order.split(64):
            with torch.autocast('cuda',dtype=torch.bfloat16):z=reg(train[ix]).float()
            t=y[ix]
            # Fractional BCE plus area calibration averaged independently per image.
            loss=F.binary_cross_entropy_with_logits(z,t)+.25*(z.sigmoid().mean((1,2,3))-t.mean((1,2,3))).abs().mean()
            opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(reg.parameters(),1.,error_if_nonfinite=True);opt.step()
            summed+=float(loss.detach())*len(ix)
        if ep in (1,8,16,24):print('epoch',ep,'train_loss',summed/len(train),flush=True)
    torch.save(dict(model=reg.cpu().state_dict(),config=config),ROOT/'region_head.pth');reg=reg.cuda().eval()
    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
        occupancy=torch.cat([reg(v).float().sigmoid() for v in valid.split(64)])
    methods=['base','region','equal_area','ideal_region'];cases=[]
    for j,r in enumerate(record):
        base=pval[j]>=.5;g=gt[j];fn=g&~base;hard=fn&(distance_transform_edt(g)>8)&(pval[j]<.1)
        mask=resize(occupancy[j:j+1],256)[0,0].cpu().numpy()>=.8
        oracle=resize(yval[j:j+1],256)[0,0].cpu().numpy()>=.8
        proposed=base|mask;equiv=add_quota(pval[j],base,int((mask&~base).sum()))
        assert proposed.sum()==equiv.sum()
        row=dict(id=r['id'],hard=int(hard.sum()))
        for name,pred in zip(methods,(base,proposed,equiv,base|oracle)):
            row[name+'_dice']=dice(pred,g)
            row[name+'_hard_saved']=int((pred&hard).sum())
            row[name+'_fn_saved']=int((pred&fn).sum())
            row[name+'_fp_added']=int((pred&~g&~base).sum())
        cases.append(row)
    assert sum(r['hard'] for r in cases)==523856
    with (ROOT/'region_cases.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cases[0]);w.writeheader();w.writerows(cases)
    report={}
    for method in methods:
        dice_arr=np.array([r[method+'_dice'] for r in cases])
        d=100*(dice_arr-np.array([r['base_dice'] for r in cases]))
        ii=np.random.default_rng(42).integers(len(cases),size=(5000,len(cases)))
        report[method]=dict(dice=float(dice_arr.mean()),delta_pp=float(d.mean()),image_bootstrap95=np.quantile(d[ii].mean(1),[.025,.975]).tolist(),
              counts={k:sum(r[method+'_'+k] for r in cases) for k in ('hard_saved','fn_saved','fp_added')})
    z={**report,'case126':next(r for r in cases if r['id']=='126'),'coarse_mae':float((occupancy-yval).abs().mean()),'n':len(cases)}
    atomic_json(ROOT/'region_result.json',z);print(json.dumps(z),flush=True)
if __name__=='__main__': main()
