from pathlib import Path
import sys,json,csv,math
from collections import Counter
import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt
ROOT=Path(__file__).resolve().parent
PR=ROOT.parents[2]
PROJECT=Path('/home/waas/mambavision_stage22/source/referring_image_segmentation')
DIAG=PR/'diagnostics/stageC_20261117'
SENS=DIAG/'sensitivity/control'
def roi(mask):
 y,x=np.where(mask)
 if not len(x) or mask.all():return np.ones_like(mask),False
 side=min(256,max(96,math.ceil(1.8*max(int(np.ptp(y))+1,int(np.ptp(x))+1))))
 l=int(np.clip(round((x.min()+x.max()+1-side)/2),0,256-side));t=int(np.clip(round((y.min()+y.max()+1-side)/2),0,256-side))
 inside=np.zeros_like(mask);inside[t:t+side,l:l+side]=True
 return inside,side<256
def dice(p,g):
 return 2*np.count_nonzero(p&g)/(p.sum()+g.sum())
def run():
 known=json.load((DIAG/'CONFIDENCE_GEOMETRY.json').open())['models']['control']['counts']
 cached=np.load(SENS/'intact_validation_probabilities_fp32.npy',mmap_mode='r')
 record=list(csv.DictReader((SENS/'intact_per_image.csv').open()))
 probes=PR/'evaluations/stageC_probes_20261117/f3_nonlinear32'
 pz=np.load(probes/'validation_predictions.npz');pi={str(s):j for j,s in enumerate(pz['ids'])}
 pr={r['id']:r for r in csv.DictReader((probes/'validation_per_image.csv').open())}
 result=[];means={k:[] for k in ('base','lower','union','confirm')}
 for i,r in enumerate(record):
  sid=r['id'];p=cached[i];g=np.array(Image.open(PROJECT/'data/isic2018/val/masks'/(sid+'.png')).convert('L').resize((256,256),Image.Resampling.NEAREST))>=127.5
  b=p>=.5;f=g&~b;d=distance_transform_edt(g)
  hard=f&(p<.1)&(d>8)
  assert int(f.sum())==int(r['fn'])
  inside,active=roi(b)
  bits=pz['packed_bits'][pi[sid]]
  q=np.unpackbits(bits).reshape(g.shape).astype(bool)
  if int((q&g).sum())!=int(pr[sid]['tp']):q=np.unpackbits(bits,bitorder='little').reshape(g.shape).astype(bool)
  assert int((q&g).sum())==int(pr[sid]['tp']) and int((q&~g).sum())==int(pr[sid]['fp'])
  exterior=distance_transform_edt(~b) if b.any() else np.full(b.shape,np.inf)
  rec=dict(id=sid,gt=int(g.sum()),fn=int(f.sum()),hard=int(hard.sum()),hard_outside=int((hard&~inside).sum()),hard_p01=int((hard&(p<.01)).sum()),hard_in_empty=int(hard.sum()) if not b.any() else 0,
    hard_without_global_pred_near8=int((hard&(exterior>8)).sum()),proposal=int(active),empty=int(not b.any()),area=int(inside.sum()))
  for name,alt in [('base',b),('lower',p>=.1),('union',b|q),('confirm',b|(q&(p>=.1)))]:
   means[name].append(dice(alt,g))
   rec[name+'_hard_saved']=int((alt&hard).sum());rec[name+'_fn_saved']=int((alt&f).sum());rec[name+'_fp_added']=int((alt&~b&~g).sum())
  result.append(rec)
 nums={k:sum(r[k] for r in result) for k in result[0] if k!='id'}
 assert nums['hard']==known['deep_FN_probability_lt01'] and nums['fn']==known['FN']
 with (ROOT/'extent_coverage.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=result[0]);w.writeheader();w.writerows(result)
 info={'n':len(result),'counts':nums,'crop_active':{k:sum(r[k] for r in result if r['proposal']) for k in ('hard','hard_outside','fn')},'case126':next(r for r in result if r['id']=='126'),'scores':{k:float(np.mean(v)) for k,v in means.items()},'affected':sum(r['hard_outside']>0 for r in result)}
 (ROOT/'coverage.json').write_text(json.dumps(info,indent=2));print(json.dumps(info))
if __name__=='__main__':run()
