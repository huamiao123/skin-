from pathlib import Path
import json
import sys
from dysample_decoder import HERE,ARMS,build
from paired_diagnostics import compare
from oracle_geometry import main as geometry
from compare_cases import main as case_comparison
from train_feature import atomic_json

if __name__=="__main__":
    folder=HERE/ARMS[0]
    compare(ARMS[0],HERE.parent/"runs/add/best.pth",False,folder/"best.pth",candidate_builder=build)
    geometry(candidate_dir=folder,candidate_factory=lambda:build(ARMS[0]))
    case_comparison(False)
    base=json.loads((HERE/"oracle_geometry.json").read_text())["means"]
    new=json.loads((folder/"geometry.json").read_text())["means"]
    result={band:dict(reference_deficit_pp=sum(base["base_"+s+"_"+band] for s in ("fp","fn")),
                      candidate_deficit_pp=sum(new["base_"+s+"_"+band] for s in ("fp","fn")))
            for band in ("near","mid","far")}
    atomic_json(folder/"boundary_comparison.json",result)

    entry=json.loads((HERE/"transfer_cases.json").read_text())[ARMS[0]]
    case=entry["by_area"]["all"]
    report=HERE/"literature/deep_research_report.md"
    marker="## DySample 最终验证"
    earlier=report.read_text().split("\n"+marker)[0].rstrip()
    message=(f"100 轮验证最佳 Dice 为 {100*case['macro_dice']:.4f}%，相对原生 UPer64 "
             f"{entry['difference_pp']:+.4f} 个百分点。"
             f"3 像素窄带缺口由 {result['near']['reference_deficit_pp']:.4f} 变为 "
             f"{result['near']['candidate_deficit_pp']:.4f} 个百分点。完整明细在 "
             "dysample_f2_to_f1/boundary_comparison.json 和 transfer_cases.json。")
    tmp=report.with_suffix(".tmp")
    tmp.write_text(earlier+"\n\n"+marker+"\n\n"+message+"\n")
    tmp.replace(report)
