"""Per-image paired validation analysis. Decomposition is algebraic, without fitting cutoffs."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent


def read(run):
    if not (run/"complete.json").is_file():
        raise RuntimeError(f"run is incomplete: {run}")
    with (run/"best_validation.csv").open() as f:
        rows = list(csv.DictReader(f))
    data = {r["id"]:[int(r[k]) for k in ("tp","fp","fn")] for r in rows}
    assert len(rows) == len(data) == 762
    keys = sorted(data)
    return keys, np.asarray([data[k] for k in keys], dtype=np.float64)


def describe(x, sel):
    tp,fp,fn = x[sel].T
    den = 2*tp+fp+fn
    # A jointly empty prediction/target has Dice 1 and both deficits zero.
    den = np.maximum(den,1)
    area = np.abs(fp-fn)/den
    displacement = 2*np.minimum(fp,fn)/den
    dice = 1 - (fp+fn)/den
    assert np.allclose(1-dice, area+displacement)
    return dict(n=len(tp),macro_dice=float(dice.mean()),fp=int(fp.sum()),fn=int(fn.sum()),
                absolute_area_fraction_mae=float(np.mean(np.abs(fp-fn)/65536)),
                over_area_cases=int((fp>fn).sum()),under_area_cases=int((fp<fn).sum()),
                area_deficit_pp=float(100*area.mean()),balanced_error_deficit_pp=float(100*displacement.mean()))


def main(original_only):
    runs={name:ROOT.parent/"runs"/name for name in ("add","gated_concat","f3_difference")}
    if not original_only: runs["proportion_l1"]=ROOT/"proportion_l1"
    if not original_only and (ROOT/"dysample_f2_to_f1/complete.json").exists():
        runs["dysample_f2_to_f1"]=ROOT/"dysample_f2_to_f1"
    ids,ref=read(runs["add"])
    gt=(ref[:,0]+ref[:,2])/65536
    masks=dict(all=np.ones(len(gt),dtype=bool),under5=gt<.05,from5to20=(gt>=.05)&(gt<.2),
               from20to50=(gt>=.2)&(gt<.5),atleast50=gt>=.5)
    baseline=1-(ref[:,1]+ref[:,2])/np.maximum(2*ref[:,0]+ref[:,1]+ref[:,2],1)
    rng=np.random.default_rng(42)
    indices=rng.integers(len(gt),size=(5000,len(gt)))
    result={}
    for name,run in runs.items():
        keys,x=read(run)
        assert ids==keys and np.array_equal(x[:,0]+x[:,2],ref[:,0]+ref[:,2])
        desc={label:describe(x,sel) for label,sel in masks.items()}
        diff=100*(1-(x[:,1]+x[:,2])/np.maximum(2*x[:,0]+x[:,1]+x[:,2],1)-baseline)
        result[name]=dict(by_area=desc,difference_pp=float(diff.mean()),
                paired_image_ci95_pp=np.quantile(diff[indices].mean(1),[.025,.975]).tolist(),
                images_better=int((diff>0).sum()),images_worse=int((diff<0).sum()))
    path=ROOT/("prior_cases.json" if original_only else "transfer_cases.json")
    tmp=path.with_suffix(".tmp")
    tmp.write_text(json.dumps(result,indent=2))
    tmp.replace(path)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--original-only",action="store_true")
    main(parser.parse_args().original_only)
