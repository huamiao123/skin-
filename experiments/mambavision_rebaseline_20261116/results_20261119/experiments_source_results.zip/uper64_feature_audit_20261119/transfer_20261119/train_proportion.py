"""Binary region proportion transfer, using the author's verified source and the original UPer64."""
import ast
import fcntl
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Optional

import torch
from torch import nn
from torch.nn import functional as F

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from train_feature import atomic_json, atomic_save, base, build, optimizer, reference, restore_rng, rng_state, validate, write_rows
from model import PROJECT, segmentation_loss


def load_l1():
    root = HERE / "upstream"
    manifest = json.loads((root / "manifest.json").read_text())
    assert manifest["commit"] == "81fb0a47748f3151f656b40b92f93cf27801f289"
    for entry in manifest["files"]:
        assert hashlib.sha256((root / entry["path"]).read_bytes()).hexdigest() == entry["sha256"]
    constants = root / "seglossbias/utils/constants.py"
    scope = dict(torch=torch, nn=nn, F=F, Optional=Optional)
    exec(compile(constants.read_text(), str(constants), "exec"), scope)
    path = root / "seglossbias/modeling/compound_losses.py"
    tree = ast.parse(path.read_text())
    selected = {"get_region_proportion", "CompoundLoss", "CrossEntropyWithL1"}
    tree.body = [node for node in tree.body if getattr(node, "name", None) in selected]
    assert len(tree.body) == 3
    exec(compile(tree, str(path), "exec"), scope)
    return scope["CrossEntropyWithL1"](mode="binary", alpha=1., temp=10.)


def proportion_loss(layer, logits, target):
    gt, valid = layer.get_gt_proportion(layer.mode, target, logits.shape)
    pred = layer.get_pred_proportion(layer.mode, logits, layer.temp, valid)
    return (pred - gt).abs().mean()


def verify_loss(layer):
    logits = torch.tensor([[[[.05,-.2],[.1,.4]]], [[[-.04,.15],[-.4,.02]]]], requires_grad=True)
    gt = torch.tensor([[[[1.,.2],[1.,1.]]], [[[0.,0.],[.4,0.]]]])
    term = proportion_loss(layer, logits, gt)
    _, _, original = layer(logits, gt)
    check = ((10*logits).sigmoid().mean((2,3)) - gt.mean((2,3))).abs().mean()
    torch.testing.assert_close(original,term)
    torch.testing.assert_close(check,term)
    grad = torch.autograd.grad(term,logits)[0]
    assert (grad[0]<0).all() and (grad[1]>0).all()
    return float(term.detach())


def train(run):
    reference.setup()
    layer = load_l1()
    toy = verify_loss(layer)
    model = build("add")
    data, _ = reference.load_data()
    ids_val = data.ids["val"]
    assert (len(data.ids["train"]),len(ids_val))==(1886,762)
    opt=optimizer(model)
    ctrl=HERE.parent/"runs/add"
    ref=json.loads((ctrl/"config.json").read_text())
    for path,digest in ref["source_hashes"].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
    assert ref["head_parameters"]==sum(p.numel() for p in model.probe.parameters())
    source=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    config=dict(reference_config=ref, change="BCE + original per-image soft Dice + author proportion L1",
                coefficient=1., logit_multiplier=10., label="same soft training target",
                source_sha256=source, upstream_commit="81fb0a47748f3151f656b40b92f93cf27801f289")
    cfg=run/"config.json"
    if cfg.exists() and json.loads(cfg.read_text())!=config: raise RuntimeError("Resume configuration changed")
    atomic_json(cfg,config)
    val=reference.cache_new(len(ids_val))
    reference.fill_cache(model,data,"val",val)
    cache=reference.cache_new(len(data.ids["train"]))
    history=[]
    latest=run/"latest.pth"
    if latest.exists():
        state=torch.load(latest,map_location="cpu")
        assert state["config"]==config
        model.load_state_dict(state["model"])
        opt.load_state_dict(state["optimizer"])
        restore_rng(state["rng"])
        history=state["history"]
        del state
    best=max((v["val_macro_dice"] for v in history),default=-1.)
    for epoch in range(len(history)+1,101):
        order,geo=data.geometry(epoch)
        reference.fill_cache(model,data,"train",cache,geo)
        factor=.01+.99*(1+math.cos(math.pi*(epoch-1)/100))/2
        for group in opt.param_groups: group["lr"]=group["initial_lr"]*factor
        model.train()
        sum_main=sum_extra=0.
        for first in range(0,len(order),64):
            ids=order[first:first+64]
            target=cache["target"][ids]
            opt.zero_grad(set_to_none=True)
            with torch.autocast("cuda",dtype=torch.bfloat16):
                out=model.from_cache(cache["features"][0][ids],cache["features"][1][ids],cache["mid"][ids],target.shape[-2:])
            assert set(out)=={"main"}
            z=out["main"].float()
            main=segmentation_loss(z,target)
            reg=proportion_loss(layer,z,target)
            loss=main+reg
            if not torch.isfinite(loss): raise FloatingPointError("Nonfinite loss")
            if epoch==1 and first==0:
                old=json.loads((ctrl/"first_update.json").read_text())["loss"]
                assert abs(float(main.detach())-old)<1e-5,(main,old)
                reg_grad=torch.autograd.grad(reg,z,retain_graph=True)[0].abs().sum().item()
                assert math.isfinite(reg_grad) and reg_grad>0
            loss.backward()
            norms={g["name"]:float(nn.utils.clip_grad_norm_(g["params"],1.,error_if_nonfinite=True)) for g in opt.param_groups}
            opt.step()
            if epoch==1 and first==0:
                assert all(v>0 for v in norms.values())
                atomic_json(run/"first_update.json",dict(batch=len(ids), main=float(main.detach()),reference_main=old,
                            proportion=float(reg.detach()),regularizer_logit_gradient_l1=reg_grad,group_norm=norms,toy=toy))
            sum_main+=float(main.detach())*len(ids)
            sum_extra+=float(reg.detach())*len(ids)
        scores,rows=validate(model,val,ids_val,None)
        record=dict(epoch=epoch,main_loss=sum_main/len(order),size_loss=sum_extra/len(order),**scores)
        history.append(record)
        if scores["val_macro_dice"]>best:
            best=scores["val_macro_dice"]
            atomic_save(run/"best.pth",dict(epoch=epoch,model=base.cpu_tree(model.state_dict()),scores=scores,config=config))
            write_rows(run/"best_validation.csv",rows)
        if epoch in (1,100) or epoch%5==0:
            atomic_save(latest,dict(config=config,model=base.cpu_tree(model.state_dict()),optimizer=base.cpu_tree(opt.state_dict()),
                                    rng=rng_state(),history=history))
        atomic_json(run/"history.json",history)
        print(json.dumps(record),flush=True)
    atomic_json(run/"complete.json",dict(best=max(history,key=lambda x:x["val_macro_dice"]),epochs=len(history),test_used=False))


if __name__=="__main__":
    run=HERE/"proportion_l1"
    run.mkdir(exist_ok=True)
    with (run/"run.lock").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if not (run/"complete.json").exists(): train(run)
