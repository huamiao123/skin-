"""Paired intervention on a trained DySample head; no parameter updates."""
import csv
import json
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F
from scipy.ndimage import distance_transform_edt
from dysample_decoder import ARMS,HERE,build
from train_feature import reference,atomic_json,write_rows


@torch.inference_mode()
def main():
    reference.setup()
    folder=HERE/ARMS[0]
    model=build(ARMS[0]).eval()
    state=torch.load(folder/"best.pth",map_location="cpu")
    model.load_state_dict(state["model"])
    del state
    sampler=model.probe.decode_head.sampler
    with (folder/"best_validation.csv").open() as f:
        known={r["id"]:r for r in csv.DictReader(f)}
    data,_=reference.load_data()
    rows=[];offset_hist=np.zeros(8193,np.int64);total_norm=0.;positions=0
    weights=sampler.offset.weight.detach().clone()
    bias=sampler.offset.bias.detach().clone()
    def observe(_module,_inputs,raw):
        nonlocal offset_hist,total_norm,positions
        # The author's LP variant applies 0.25 to dx,dy in source f2 pixels.
        xy=raw.float().reshape(raw.shape[0],2,-1,*raw.shape[-2:])*.25
        norm=xy.square().sum(1).sqrt()
        counts=torch.bincount((norm*1024).long().clamp_max(8192).flatten(),minlength=8193)
        offset_hist+=counts.cpu().numpy()
        total_norm+=float(norm.double().sum())
        positions+=norm.numel()
    for start in range(0,len(data.ids["val"]),64):
        ix=torch.arange(start,min(start+64,len(data.ids["val"])),device="cuda")
        images,y=data.batch("val",ix)
        with torch.autocast("cuda",dtype=torch.bfloat16):
            f1,f2,mid=model.prefix(images);f3,f4=model.suffix(mid);features=[f1,f2,f3,f4]
            sampler.offset.weight.copy_(weights);sampler.offset.bias.copy_(bias)
            hook=sampler.offset.register_forward_hook(observe)
            try: active=model.probe(features,(256,256))["main"][:,0].float()
            finally: hook.remove()
            sampler.offset.weight.zero_();sampler.offset.bias.zero_()
            regular=model.probe(features,(256,256))["main"][:,0].float()
        mask=y[:,0]>=.5
        # Label-only construction: use per-cell true occupancy as a hypothetical stride-4 map.
        # This is an illustrative feasible grid, not a performance bound.
        coarse=F.interpolate(F.avg_pool2d(mask[:,None].float(),4),size=(256,256),
                             mode="bilinear",align_corners=False)[:,0]>=.5
        assert torch.isfinite(active).all() and torch.isfinite(regular).all()
        for j,(a,b,g,q) in enumerate(zip((active.sigmoid()>=.5).cpu().numpy(),(regular.sigmoid()>=.5).cpu().numpy(),mask.cpu().numpy(),coarse.cpu().numpy())):
            sid=data.ids["val"][start+j];row={"id":sid}
            inside=distance_transform_edt(np.pad(g,1))[1:-1,1:-1]
            outside=distance_transform_edt(~g)
            for label,pred in (("active",a),("disabled",b),("gt_stride4",q)):
                tp=int((g&pred).sum());fp=int((~g&pred).sum());fn=int((g&~pred).sum())
                den=2*tp+fp+fn
                row[label+"_dice"]=2*tp/den if den else 1.
                row[label+"_near_deficit_pp"]=100*(int((~pred&g&(inside<=3)).sum())+int((pred&~g&(outside<=3)).sum()))/max(1,den)
                if label=="active": assert [tp,fp,fn]==[int(known[sid][k]) for k in ("tp","fp","fn")]
            row.update(flips=int((a!=b).sum()),corrected=int(((a!=b)&(a==g)).sum()),worsened=int(((a!=b)&(b==g)).sum()))
            rows.append(row)
    assert len(rows)==len(known)==762
    write_rows(folder/"offset_intervention.csv",rows)
    def mean(k):return float(np.mean([r[k] for r in rows]))
    def total(k):return sum(r[k] for r in rows)
    delta=np.array([r["active_dice"]-r["disabled_dice"] for r in rows])*100
    ix=np.random.default_rng(42).integers(len(rows),size=(5000,len(rows)))
    p95=np.searchsorted(np.cumsum(offset_hist),positions*.95)/1024
    result=dict(n=762,active_dice=mean("active_dice"),disabled_dice=mean("disabled_dice"),
             delta_pp=float(delta.mean()),image_ci95_pp=np.quantile(delta[ix].mean(1),[.025,.975]).tolist(),
             active_near_pp=mean("active_near_deficit_pp"),disabled_near_pp=mean("disabled_near_deficit_pp"),
             pixels_flipped=total("flips"),pixels_corrected=total("corrected"),pixels_worsened=total("worsened"),
             sampled_offsets=positions,mean_offset_l2_f2_pixels=total_norm/positions,
             p95_offset_l2_f2_pixels_lower_bin=float(p95),label_only_stride4_dice=mean("gt_stride4_dice"),
             label_only_stride4_near_pp=mean("gt_stride4_near_deficit_pp"),test_used=False)
    atomic_json(folder/"offset_intervention.json",result)
    print(json.dumps(result),flush=True)


if __name__=="__main__":main()
