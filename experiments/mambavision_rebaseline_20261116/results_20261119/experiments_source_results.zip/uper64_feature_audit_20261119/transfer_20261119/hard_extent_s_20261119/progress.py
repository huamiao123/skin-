import json
import sys
import time
from pathlib import Path
root=Path(__file__).resolve().parent
delay=min(45,max(0,int(sys.argv[1]) if len(sys.argv)>1 else 0))
def status():
    out=[]
    for key in ('mining','fit','evaluation','queue'):
        path=root/(key+'.log')
        if path.exists():
            data=path.read_text(errors='replace').splitlines()
            for line in reversed(data):
                if line.startswith(('mine ','saved fold','fit ','DONE','Traceback','AssertionError','RuntimeError','FloatingPointError','ValueError','KeyError','Mining exited','IndexError','FileNotFoundError','torch.OutOfMemoryError')):
                    out.append(key+' '+line[:210]);break
    for arm in ('uniform','targeted'):
        f=root/arm/'history.json'
        if f.exists():
            rows=json.loads(f.read_text())
            best=max(rows,key=lambda r:r['validation_dice'])
            out.append(f"{arm} {len(rows)} best {best['validation_dice']:.6f} @ {best['epoch']}, recent seconds {sum(r['seconds'] for r in rows[-5:])/min(5,len(rows)):.1f}")
    return out
end=time.monotonic()+delay
while time.monotonic()<end:
    if (root/'RESULTS.json').exists() or any('Error' in x or 'Traceback' in x for x in status()):break
    time.sleep(min(5,max(0,end-time.monotonic())))
print(*status(),sep='\n',flush=True)
