"""Three-fold mining of confident extent errors on the ISIC training partition."""
import csv
import hashlib
import json
import math
import time
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt as edt
import torch
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'target_training_20261119'))
import train_target as tr
from model import PROJECT
from stage3_confirmation.data import ImageData
from stage1_visual.data import DATA

SCRATCH = Path('/tmp/mambavision_s_hard_extent_20261119')
SCRATCH.mkdir(exist_ok=True)
BATCH = 64
MINE_EPOCHS = 24
EPOCHS = 100
GROUPS = Path('/home/featurize/work/RSI_Implementation_20261003/data_manifests')
PARTITION = PROJECT/'stage45_upernet_decoder/identity_partition.json'
PR = ROOT.parents[2]

def read_json(path):
    return json.loads(path.read_text())

def fixed_json(path, value):
    if path.exists():
        assert read_json(path) == value, path
    else:
        tr.atomic_json(path,value)

class TrainData(ImageData):
    """Original augmentation and preprocessing, loading only training images."""
    def __init__(self):
        self.seed = 42
        ids = read_json(PARTITION)['splits']['train']
        masks = {p.stem.removesuffix('_segmentation').removesuffix('_mask'):p for p in (DATA/'train/masks').iterdir() if p.is_file()}
        images = {p.stem:p for p in (DATA/'train/images').iterdir() if p.is_file()}
        assert set(ids) == set(images) == set(masks) and len(ids)==1886
        def read(sid):
            with Image.open(images[sid]) as x, Image.open(masks[sid]) as y:
                a=np.array(x.convert('RGB').resize((256,256),Image.Resampling.BILINEAR))
                b=np.array(y.convert('L').resize((256,256),Image.Resampling.NEAREST))
            return a,b,hashlib.sha256(a.tobytes()).hexdigest()
        with ThreadPoolExecutor(8) as pool:
            rows=list(pool.map(read,ids))
        expected={r['id']:r['decoded_image_sha256'] for r in read_json(PROJECT/'stage1_visual/data_manifest.json')['members'] if r['split']=='train'}
        self.hashes=[r[2] for r in rows]
        assert self.hashes==[expected[sid] for sid in ids]
        self.ids={'train':ids}
        self.images={'train':torch.from_numpy(np.stack([r[0] for r in rows])).permute(0,3,1,2).contiguous().cuda()}
        self.masks={'train':torch.from_numpy(np.stack([r[1] for r in rows])).unsqueeze(1).cuda()}
        self.mean=torch.tensor([.485,.456,.406],device='cuda').view(1,3,1,1)
        self.std=torch.tensor([.229,.224,.225],device='cuda').view(1,3,1,1)

def folds_for(data):
    ids=data.ids['train']
    mapping={r['id']:r['official_matches'] for r in read_json(PR/'diagnostics/stageC_20261117/data_provenance/BICUBIC_MASK_ID_MAPPING.json') if r['split']=='train'}
    parents={}
    def root(a):
        parents.setdefault(a,a)
        while a != parents[a]:
            parents[a]=parents[parents[a]]
            a=parents[a]
        return a
    def join(a,b):
        parents[root(a)]=root(b)
    for row in read_json(GROUPS/'confirmed_duplicate_groups.json')['groups']:
        for item in row[1:]:join(row[0],item)
    for r in csv.DictReader((GROUPS/'split_groups.csv').open()):
        for k in ('group_id','patient_id','lesion_id'):
            if r.get(k):join(r['image_id'],k+'='+r[k])
    for i,sid in enumerate(ids):
        key='sha='+data.hashes[i]
        for r in mapping[sid]:join(key,r['official_id'])
    groups=defaultdict(list)
    for i,h in enumerate(data.hashes):groups[root('sha='+h)].append(i)
    rng=np.random.default_rng(42)
    gs=list(groups.values());rng.shuffle(gs);gs.sort(key=len,reverse=True)
    assigned=np.full(len(ids),-1);counts=np.zeros(3,dtype=int)
    for members in gs:
        fold=int(rng.choice(np.flatnonzero(counts==counts.min())))
        assigned[members]=fold;counts[fold]+=len(members)
    assert all(len(set(assigned[v]))==1 for v in gs) and np.all(assigned>=0)
    meta=[dict(id=sid,official_ids=[r['official_id'] for r in mapping[sid]],group=root('sha='+data.hashes[i]),fold=int(assigned[i])) for i,sid in enumerate(ids)]
    fixed_json(ROOT/'folds.json',meta)
    print('folds',counts,'groups',len(groups),'multi-image groups',sum(len(g)>1 for g in gs),flush=True)
    return assigned

def lr_schedule(opt,epoch,n):
    scale=.01+.99*(1+math.cos(math.pi*(epoch-1)/n))/2
    for group in opt.param_groups:group['lr']=group['initial_lr']*scale

def update(model,opt,x,gt,extra=None):
    opt.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):
        out=model(x)['main'] if isinstance(x,torch.Tensor) else model.from_cache(*x,gt.shape[-2:])['main']
    z=out.float()
    main=tr.segmentation_loss(z,gt)
    loss=main if extra is None else main+extra(z)
    if not torch.isfinite(loss):raise FloatingPointError('nonfinite loss')
    loss.backward()
    norms=[torch.nn.utils.clip_grad_norm_(g['params'],1.,error_if_nonfinite=True) for g in opt.param_groups]
    opt.step()
    return float(loss.detach()),[float(n) for n in norms]

def spatial(row):
    prob,gt=row
    pred=prob>=.5
    pos=(prob<.1)&gt&(edt(gt)>8)
    neg=(prob>.9)&~gt&(edt(~gt)>8)
    den=max(1,int(gt.sum()+pred.sum()))
    return np.packbits(pos), np.packbits(neg), [pos.sum()/den,neg.sum()/den], [pos.sum(),neg.sum()]

def mine():
    tr.reference.setup()
    data=TrainData()
    folds=folds_for(data)
    for k in range(3):
        dest=ROOT/f'fold_{k}.npz'
        if dest.exists():continue
        tr.reference.setup();model=tr.build('add');opt=tr.optimizer(model)
        fixed_json(ROOT/'initial.json',dict(state_sha256=tr.initial_digest(model),encoder_sha256=tr.WEIGHT_SHA256))
        valid=np.flatnonzero(folds==k)
        eligible=torch.tensor(folds!=k,device='cuda')
        for epoch in range(1,MINE_EPOCHS+1):
            tic=time.monotonic();model.train();lr_schedule(opt,epoch,MINE_EPOCHS)
            order,mat=data.geometry(epoch);order=order[eligible[order]]
            assert len(order)==len(folds)-len(valid)
            for ids in order.split(BATCH):
                x,gt=data.batch('train',ids,mat)
                loss,norms=update(model,opt,x,gt)
            print('mine',k,epoch,'loss_last',round(loss,4),'sec',round(time.monotonic()-tic,1),flush=True)
        model.eval()
        rows=[]
        with torch.inference_mode(),ThreadPoolExecutor(6) as pool:
            for ids in torch.tensor(valid,device='cuda').split(BATCH):
                x,gt=data.batch('train',ids)
                with torch.autocast('cuda',dtype=torch.bfloat16):z=model(x)['main'].float()
                assert torch.isfinite(z).all()
                rows.extend(pool.map(spatial,zip(z.sigmoid()[:,0].cpu().numpy(),(gt[:,0]>=.5).cpu().numpy())))
        tmp=dest.with_suffix('.part.npz')
        np.savez_compressed(tmp,indices=valid,pos=np.stack([r[0] for r in rows]),neg=np.stack([r[1] for r in rows]),scores=np.asarray([r[2] for r in rows]),counts=np.asarray([r[3] for r in rows]))
        tmp.replace(dest)
        print('saved fold',k,'severe FN/FP',np.sum([r[3] for r in rows],axis=0),flush=True)
        del model,opt
        torch.cuda.empty_cache()
    fixed_json(ROOT/'mined.json',dict(folds=3,n=1886,epochs=MINE_EPOCHS,source='excluded training groups only',complete=True))
if __name__=='__main__':mine()
