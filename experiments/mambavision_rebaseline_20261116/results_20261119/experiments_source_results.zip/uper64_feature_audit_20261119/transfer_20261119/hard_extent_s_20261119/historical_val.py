"""Both arms evaluated on exactly the historical 523,856 severe validation FN pixels."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import csv,json,sys
import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt as edt
here=Path(__file__).resolve().parent
pr=Path('/home/featurize/work/mambavision_seg_rebaseline_20261116')
scratch=Path('/tmp/mambavision_s_hard_extent_20261119')
data=Path('/home/waas/mambavision_stage22/source/referring_image_segmentation')
old=pr/'diagnostics/stageC_20261117/sensitivity/control'
ids=[r['id'] for r in csv.DictReader((old/'intact_per_image.csv').open())]
assert ids==json.loads((data/'stage45_upernet_decoder/identity_partition.json').read_text())['splits']['val']
prob=np.load(old/'intact_validation_probabilities_fp32.npy',mmap_mode='r')
arms=('uniform','targeted')
arrays=[np.load(scratch/(a+'_val.npy'),mmap_mode='r') for a in arms]
def count(i):
    with Image.open(data/'data/isic2018/val/masks'/(ids[i]+'.png')) as im:
        gt=np.array(im.convert('L').resize((256,256),Image.Resampling.NEAREST))>=128
    hard=(prob[i]<.1)&gt&(edt(gt)>8)
    pa=arrays[0][i]>=.5;pb=arrays[1][i]>=.5
    return [hard.sum(),(hard&pa).sum(),(hard&pb).sum(),(hard&pa&~pb).sum(),(hard&~pa&pb).sum(),(hard&pa&pb).sum()]
with ThreadPoolExecutor(8) as pool:
    t=np.asarray(list(pool.map(count,range(len(ids))))).sum(0)
assert t[0]==523856 and t[2]-t[1]==t[4]-t[3]
out=dict(zip(['historical_pixels','uniform_recovered','targeted_recovered','only_uniform','only_targeted','both_recovered'],map(int,t)))
dest=here/'historical_severe_validation.json'
dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
