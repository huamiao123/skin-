"""Matched uniform-replay and error-targeted replay, with validation-only selection."""
import time
import numpy as np
import torch
from torch.nn import functional as F
from mine import ROOT, SCRATCH, EPOCHS, BATCH, PARTITION, tr, fixed_json, read_json, lr_schedule, update

ARMS=('uniform','targeted')
REPLAYS=472
COEFFICIENT=.25

def load_maps(data):
    n=len(data.ids['train'])
    seen=np.zeros(n,dtype=int)
    masks=np.zeros((n,2,8192),dtype=np.uint8)
    scores=np.zeros((n,2))
    counts=np.zeros((n,2),dtype=int)
    meta=read_json(ROOT/'folds.json')
    assert [r['id'] for r in meta]==data.ids['train']
    for k in range(3):
        with np.load(ROOT/f'fold_{k}.npz') as z:
            idx=z['indices']
            assert sorted(idx.tolist())==[i for i,r in enumerate(meta) if r['fold']==k]
            seen[idx]+=1
            masks[idx,0]=z['pos'];masks[idx,1]=z['neg']
            scores[idx]=z['scores'];counts[idx]=z['counts']
    assert np.all(seen==1)
    planes=torch.from_numpy(np.unpackbits(masks,axis=-1).reshape(n,2,256,256)).cuda()
    true=data.masks['train']>=128
    assert not (planes[:,0:1].bool() & ~true).any() and not (planes[:,1:2].bool() & true).any()
    pools=[]
    for j in range(2):
        pos=np.flatnonzero(scores[:,j]>0)
        rank=pos[np.argsort(-scores[pos,j],kind='stable')]
        pools.append(rank[:min(int(np.ceil(n/4)),len(rank))])
        assert len(pools[j])>=REPLAYS//2
    fixed_json(ROOT/'mining_summary.json',dict(images=n,confident_interior_fn=int(counts[:,0].sum()),confident_exterior_fp=int(counts[:,1].sum()),images_with_fn=int((counts[:,0]>0).sum()),images_with_fp=int((counts[:,1]>0).sum()),FN_pool=len(pools[0]),FP_pool=len(pools[1]),overlap=int(len(set(pools[0])&set(pools[1])))))
    return planes,pools

def schedule(order, pools, epoch, arm):
    n=len(order)
    rng=np.random.default_rng(74291+epoch)
    # Matched positions and base-image order. Controls get uniformly random replays.
    slots=np.sort(rng.choice(n+REPLAYS,REPLAYS,replace=False))
    extra_rng=np.random.default_rng(93452+epoch)
    if arm=='uniform':
        repeats=extra_rng.choice(n,REPLAYS,replace=False)
    else:
        repeats=np.concatenate([extra_rng.choice(p,REPLAYS//2,replace=False) for p in pools])
        extra_rng.shuffle(repeats)
    replay=np.zeros(n+REPLAYS,dtype=bool);replay[slots]=True
    which=np.empty(n+REPLAYS,dtype=int)
    which[~replay]=order.cpu().numpy();which[replay]=repeats
    return torch.from_numpy(which).cuda(),torch.from_numpy(replay).cuda()

def weighted_loss(planes,gt,ids,mat,flag):
    x=planes[ids].float()
    grid=F.affine_grid(mat[ids],x.size(),align_corners=False)
    aligned=F.grid_sample(x,grid,mode='nearest',padding_mode='zeros',align_corners=False)
    positive=aligned[:,0:1]*flag[:,None,None,None]
    negative=aligned[:,1:2]*flag[:,None,None,None]
    assert not ((positive>0)&(gt<.5)).any() and not ((negative>0)&(gt>=.5)).any()
    def extra(logits):
        # Per-image and per-sign means, including a zero contribution for empty regions.
        def per_image(loss,mask):
            return ((loss*mask).flatten(1).sum(1)/mask.flatten(1).sum(1).clamp_min(1)).sum()
        total=per_image(F.softplus(-logits),positive)+per_image(F.softplus(logits),negative)
        return (COEFFICIENT/2)*total/len(ids)
    return extra

def forward_cached(model,cache,ids):
    return model.from_cache(cache['features'][0][ids],cache['features'][1][ids],cache['mid'][ids],cache['target'].shape[-2:])['main'].float()

@torch.inference_mode()
def validation(model,cache,return_probs=False):
    model.eval();dices=[];probs=[]
    for ids in torch.arange(len(cache['target']),device='cuda').split(BATCH):
        with torch.autocast('cuda',dtype=torch.bfloat16):z=forward_cached(model,cache,ids)
        assert torch.isfinite(z).all()
        p=z.sigmoid();a=p>=.5;b=cache['target'][ids]>=.5
        num=2*(a&b).sum((1,2,3));den=a.sum((1,2,3))+b.sum((1,2,3))
        dices.extend(torch.where(den>0,num.double()/den,1.).cpu().tolist())
        if return_probs:probs.append(p[:,0].cpu().numpy())
    return float(np.mean(dices)),np.concatenate(probs) if return_probs else None

def train():
    assert read_json(ROOT/'mined.json')['complete']
    tr.reference.setup()
    data,_=tr.reference.load_data()
    planes,pools=load_maps(data)
    fixed_json(ROOT/'protocol.json',dict(arms=list(ARMS),epochs=EPOCHS,mine_epochs=24,folds=3,batch=BATCH,replay_slots_per_epoch=REPLAYS,images_per_epoch=1886+REPLAYS,updates_per_epoch=37,
      coefficient=COEFFICIENT,seed=42,threshold=.5,encoder='official MambaVision-S ImageNet-1K',encoder_sha256=tr.WEIGHT_SHA256,
      decoder='MMSeg UPer64, no auxiliary head',trainable='encoder stages 3/4 and full decoder',init_digest=read_json(ROOT/'initial.json')['state_sha256'],
      selection='max validation macro per-image Dice, earliest tie',test='both locked before opening test; historical test set previously exposed',
      positive_error='OOF p<.1, GT foreground distance >8 px',negative_error='OOF p>.9, background distance >8 px',
      pools='rank each sign by pixel count / (predicted area + annotated area); at most one quarter of all training images per sign',
      intervention='half replays per sign; supplemental BCE averaged by sign and by full batch only on replay masks',
      geometry='single seeded augmentation per original image per epoch, repeats reuse that view in both arms',source_sha={name:tr.file_hash(ROOT/name) for name in ['mine.py','fit.py']}))
    full=tr.reference.cache_new(1886);val=tr.reference.cache_new(762)
    for arm in ARMS:
        run=ROOT/arm;run.mkdir(exist_ok=True)
        if (run/'complete.json').exists():continue
        tr.reference.setup();model=tr.build('add')
        assert tr.initial_digest(model)==read_json(ROOT/'initial.json')['state_sha256']
        opt=tr.optimizer(model);model.eval()
        tr.reference.fill_cache(model,data,'val',val)
        rows=[];best=-1.;start=1
        last=SCRATCH/(arm+'_last.pth')
        if last.exists():
            ck=torch.load(last,map_location='cpu',weights_only=False)
            model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);tr.restore_rng(ck['rng'])
            rows=ck['history'];start=rows[-1]['epoch']+1;best=max(v['validation_dice'] for v in rows)
            del ck
        for epoch in range(start,EPOCHS+1):
            tic=time.monotonic();order,mat=data.geometry(epoch)
            tr.reference.fill_cache(model,data,'train',full,mat)
            order,replay=schedule(order,pools,epoch,arm)
            lr_schedule(opt,epoch,EPOCHS);model.train();total=0.
            for ids,flag in zip(order.split(BATCH),replay.split(BATCH)):
                gt=full['target'][ids]
                x=(full['features'][0][ids],full['features'][1][ids],full['mid'][ids])
                extra=weighted_loss(planes,gt,ids,mat,flag) if arm=='targeted' else None
                loss,norms=update(model,opt,x,gt,extra)
                if epoch==1:assert min(norms)>0
                total+=loss*len(ids)
            score,_=validation(model,val)
            rows.append(dict(epoch=epoch,validation_dice=score,train_loss=total/len(order),seconds=round(time.monotonic()-tic,2)))
            if score>best:
                best=score
                tr.atomic_save(run/'best.pth',dict(model=tr.base.cpu_tree(model.state_dict()),epoch=epoch,val=score))
            tr.atomic_json(run/'history.json',rows)
            if epoch%10==0:
                tr.atomic_save(last,dict(model=tr.base.cpu_tree(model.state_dict()),optimizer=tr.base.cpu_tree(opt.state_dict()),rng=tr.rng_state(),history=rows))
            print('fit',arm,epoch,'validation',round(score,6),'sec',rows[-1]['seconds'],flush=True)
        record=max(rows,key=lambda r:r['validation_dice'])
        ck=torch.load(run/'best.pth',map_location='cpu',weights_only=False)
        assert ck['epoch']==record['epoch'] and ck['val']==best
        model.load_state_dict(ck['model']);replay_score,prob=validation(model,val,True)
        assert abs(replay_score-best)<1e-7
        np.save(SCRATCH/(arm+'_val.npy'),prob)
        fixed_json(run/'complete.json',dict(best_epoch=record['epoch'],best_val=best,replay=replay_score,best_sha256=tr.file_hash(run/'best.pth'),training_epochs=EPOCHS))
        del ck,model,opt,prob
        torch.cuda.empty_cache()
if __name__=='__main__':train()
