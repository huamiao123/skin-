"""Audit available duplicate/lesion/patient metadata for the pre-existing partition."""
import csv,json,itertools
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parent
pr=ROOT.parents[2]
reg=Path('/home/featurize/work/RSI_Implementation_20261003/data_manifests')
part=json.loads(Path('/home/waas/mambavision_stage22/source/referring_image_segmentation/stage45_upernet_decoder/identity_partition.json').read_text())['splits']
ids=json.loads((pr/'diagnostics/stageC_20261117/data_provenance/BICUBIC_MASK_ID_MAPPING.json').read_text())
mp={(r['split'],r['id']):[v['official_id'] for v in r['official_matches']] for r in ids}
par={}
def root(x):
    par.setdefault(x,x)
    while par[x]!=x:
        par[x]=par[par[x]];x=par[x]
    return x
def union(a,b):
    par[root(a)]=root(b)
for members in json.loads((reg/'confirmed_duplicate_groups.json').read_text())['groups']:
    for sid in members[1:]:union(members[0],sid)
registered=list(csv.DictReader((reg/'split_groups.csv').open()))
for r in registered:
    for field in ('group_id','lesion_id','patient_id'):
        if r[field]:union(r['image_id'],field+'='+r[field])
sets={}
for split,localids in part.items():
    groups=defaultdict(list)
    for sid in localids:
        official=[sid] if split=='test' else mp[split,sid]
        assert len(official)==1,(split,sid,official)
        groups[root(official[0])].append(official[0])
    sets[split]=groups
pairs={}
for a,b in itertools.combinations(sets,2):
    keys=set(sets[a])&set(sets[b])
    pairs[a+'_'+b]=dict(known_shared_groups=len(keys),examples=[{a:sets[a][k],b:sets[b][k]} for k in sorted(keys)[:10]])
print(json.dumps(pairs))
result=dict(pairs=pairs,metadata_source=str(reg),patient_disjointness_verified=False,metadata_only=True)
(ROOT/'split_group_audit.json').write_text(json.dumps(result,indent=2)+'\n')
