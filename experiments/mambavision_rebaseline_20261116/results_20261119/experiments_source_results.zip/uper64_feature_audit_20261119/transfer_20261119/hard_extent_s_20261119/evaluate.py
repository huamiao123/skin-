"""Paired foreground Dice and error transitions on the two locked checkpoints."""
import csv
import hashlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from scipy.ndimage import distance_transform_edt as edt
from mine import ROOT,SCRATCH,PARTITION,PROJECT,read_json,fixed_json,tr
from fit import ARMS

def sha(p):
    return tr.file_hash(p)

def analyze(row):
    sid,y,p0,p1=row
    a=p0>=.5;b=p1>=.5
    dp=edt(y)>8;dn=edt(~y)>8
    s0=dp&y&(p0<.1);s1=dp&y&(p1<.1)
    n0=dn&~y&(p0>.9);n1=dn&~y&(p1>.9)
    def dice(pred):
        den=int(y.sum()+pred.sum())
        return float(2*(pred&y).sum()/den) if den else 1.
    stats=dict(FN0=(~a&y),FN1=(~b&y),FP0=(a&~y),FP1=(b&~y),
        recovered_FN=(~a&b&y),introduced_FN=(a&~b&y),removed_FP=(a&~b&~y),introduced_FP=(~a&b&~y),
        severe_FN0=s0,severe_FN1=s1,severe_FN_fully_recovered=(s0&b),severe_FN_new_miss=(s1&a),
        severe_FN_left_class=(s0&~s1),severe_FN_entered_class=(s1&~s0),severe_FP0=n0,severe_FP1=n1,
        severe_FP_fully_corrected=n0&~b,severe_FP_new_false_positive=n1&~a)
    out={k:int(v.sum()) for k,v in stats.items()}
    return dict(id=sid,dice_uniform=dice(a),dice_targeted=dice(b),**out)

def compare(name,ids,target,arrays):
    with ThreadPoolExecutor(8) as pool:
        rows=list(pool.map(analyze,zip(ids,target,*arrays)))
    tr.write_rows(ROOT/(name+'_per_image.csv'),rows)
    a=np.asarray([r['dice_uniform'] for r in rows]);b=np.asarray([r['dice_targeted'] for r in rows])
    d=b-a;rng=np.random.default_rng(42)
    boot=np.asarray([d[rng.integers(len(d),size=len(d))].mean() for _ in range(5000)])
    totals={k:sum(r[k] for r in rows) for k in rows[0] if k not in ('id','dice_uniform','dice_targeted')}
    assert totals['FN1']-totals['FN0']==totals['introduced_FN']-totals['recovered_FN']
    assert totals['FP1']-totals['FP0']==totals['introduced_FP']-totals['removed_FP']
    return dict(n=len(a),macro_uniform=float(a.mean()),macro_targeted=float(b.mean()),delta=float(d.mean()),paired_image_bootstrap_95=np.quantile(boot,[.025,.975]).tolist(),improved=int((d>0).sum()),worsened=int((d<0).sum()),equal=int((d==0).sum()),**totals)

def main():
    completed={k:read_json(ROOT/k/'complete.json') for k in ARMS}
    for k,v in completed.items():assert v['best_sha256']==sha(ROOT/k/'best.pth')
    fixed_json(ROOT/'locked_before_test.json',dict(records=completed,threshold=.5,test_n=867,partition_sha=sha(PARTITION)))
    tr.reference.setup();data,part=tr.reference.load_data()
    val=compare('validation',data.ids['val'],data.masks['val'][:,0].cpu().numpy()>=128,[np.load(SCRATCH/(k+'_val.npy'),mmap_mode='r') for k in ARMS])
    for k in ARMS:assert abs(val['macro_'+k]-completed[k]['best_val'])<1e-7
    base=PROJECT.parent.parent;test=base/'heldout_data/test'
    manifest_path=base/'local_audit_records/test_assets/test_manifest.json'
    assert sha(manifest_path)==part['audit_sha256']['test_manifest.json']
    manifest={r['id']:r for r in read_json(manifest_path)}
    ids=part['splits']['test'];assert len(ids)==len(set(ids))==867
    def sample(sid):
        rgb=test/'images'/(sid+'.png');mask=test/'masks'/(sid+'.png')
        assert sha(rgb)==manifest[sid]['image_256_sha256'] and sha(mask)==manifest[sid]['mask_256_sha256']
        with Image.open(rgb) as x,Image.open(mask) as y:
            return np.array(x.convert('RGB')),np.array(y.convert('L'))>=128
    with ThreadPoolExecutor(8) as pool:rows=list(pool.map(sample,ids))
    images=torch.from_numpy(np.stack([r[0] for r in rows])).permute(0,3,1,2).contiguous()
    masks=np.stack([r[1] for r in rows]);del rows
    for k in ARMS:
        model=tr.build('add');ck=torch.load(ROOT/k/'best.pth',map_location='cpu',weights_only=False)
        model.load_state_dict(ck['model']);model.eval();del ck
        probs=[]
        with torch.inference_mode():
            for x in images.split(64):
                im=x.cuda().float()/255.
                with torch.autocast('cuda',dtype=torch.bfloat16):z=model((im-data.mean)/data.std)['main'].float()
                assert torch.isfinite(z).all()
                probs.append(z[:,0].sigmoid().cpu().numpy())
        np.save(SCRATCH/(k+'_test.npy'),np.concatenate(probs))
        del model,probs
        torch.cuda.empty_cache()
    test_result=compare('test',ids,masks,[np.load(SCRATCH/(k+'_test.npy'),mmap_mode='r') for k in ARMS])
    result=dict(checkpoints=completed,validation=val,test=test_result,threshold=.5,bootstrap='paired by image, single seed, without independent patient or seed uncertainty',test_previously_used_by_project=True,complete=True)
    tr.atomic_json(ROOT/'RESULTS.json',result)
    print('DONE',result,flush=True)
if __name__=='__main__':main()
