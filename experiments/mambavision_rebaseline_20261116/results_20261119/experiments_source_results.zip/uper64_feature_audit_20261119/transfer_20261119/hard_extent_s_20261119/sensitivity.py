"""Sensitivity restricted to test groups absent from both training and validation."""
import csv
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
import audit_split as audit

root=Path(__file__).resolve().parent
lock=root/'group_sensitivity_protocol.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def make():
    manifest={}
    for split in ['val','test']:
        seen=set(audit.sets['train'])
        if split=='test':seen.update(audit.sets['val'])
        cases=[]
        for sid in audit.part[split]:
            off=sid if split=='test' else audit.mp[split,sid][0]
            group=audit.root(off)
            cases.append(dict(id=sid,group=group,retain=group not in seen))
        manifest[split]=cases
    cfg=dict(cases=manifest,registry_hashes={name:sha(audit.reg/name) for name in ('confirmed_duplicate_groups.json','split_groups.csv')},seed=42,bootstrap_replicates=5000,script_sha256=sha(Path(__file__)),selection='unchanged full validation 762; fixed checkpoints')
    if lock.exists():assert json.loads(lock.read_text())==cfg
    else:
        assert not (root/'locked_before_test.json').exists()
        lock.write_text(json.dumps(cfg,indent=2)+'\n')
    return cfg
def score(config):
    result={}
    for split,label in [('val','validation'),('test','test')]:
        rows=list(csv.DictReader((root/(label+'_per_image.csv')).open()))
        cases=config['cases'][split]
        assert [r['id'] for r in rows]==[r['id'] for r in cases]
        kept=[(r,c) for r,c in zip(rows,cases) if c['retain']]
        v=np.array([[float(r['dice_uniform']),float(r['dice_targeted'])] for r,c in kept])
        delta=v[:,1]-v[:,0]
        groups,ix=np.unique([c['group'] for r,c in kept],return_inverse=True)
        n=len(groups);ns=np.bincount(ix);ss=np.bincount(ix,weights=delta)
        rng=np.random.default_rng(42)
        boot=[]
        for _ in range(config['bootstrap_replicates']):
            draw=rng.integers(n,size=n);boot.append(ss[draw].sum()/ns[draw].sum())
        totals={k:sum(int(r[k]) for r,c in kept) for k in rows[0] if k not in ('id','dice_uniform','dice_targeted')}
        result[split]=dict(n=len(kept),known_groups=n,excluded=len(rows)-len(kept),uniform=float(v[:,0].mean()),targeted=float(v[:,1].mean()),difference=float(delta.mean()),group_paired_bootstrap_95=np.quantile(boot,[.025,.975]).tolist(),**totals)
    dest=root/'group_sensitivity_results.json'
    dest.write_text(json.dumps(result,indent=2)+'\n')
    print('SENSITIVITY',json.dumps(result))
if __name__=='__main__':
    cfg=make()
    if '--score' in sys.argv:score(cfg)
    else: print('locked',[(k,sum(r['retain'] for r in v)) for k,v in cfg['cases'].items()])
