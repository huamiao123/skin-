import json
import sys
from pathlib import Path
origin=Path('/home/featurize/work/mambavision_seg_rebaseline_20261116/uper64_feature_audit_20261119/transfer_20261119/hard_extent_s_20261119')
sys.path.insert(0,str(origin))
import mine
import fit
scratch=mine.SCRATCH/'run'
fit.ROOT=scratch
fit.train()
import evaluate
evaluate.ROOT=scratch
evaluate.main()
