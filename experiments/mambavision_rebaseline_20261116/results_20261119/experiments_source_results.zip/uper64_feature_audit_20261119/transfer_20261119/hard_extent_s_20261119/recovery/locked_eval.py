from pathlib import Path
import sys,importlib.util
origin=Path('/home/featurize/work/mambavision_seg_rebaseline_20261116/uper64_feature_audit_20261119/transfer_20261119/hard_extent_s_20261119')
sys.path.insert(0,str(origin))
import mine
import fit
spec=importlib.util.spec_from_file_location('extent_evaluate_locked',origin/'evaluate.py')
ev=importlib.util.module_from_spec(spec)
spec.loader.exec_module(ev)
ev.ROOT=mine.SCRATCH/'run'
ev.main()
