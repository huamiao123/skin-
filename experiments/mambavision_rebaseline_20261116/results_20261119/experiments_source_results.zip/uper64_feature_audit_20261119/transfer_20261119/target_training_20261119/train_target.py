"""Target-domain training, with an untouched target test split until all four runs finish."""
import csv,fcntl,gc,hashlib,json,math,os,sys,time
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
from train_abl import BoundaryCriterion,COEFFICIENT,atomic_json,atomic_save,base,build,optimizer,reference,restore_rng,rng_state,segmentation_loss
from model import WEIGHT_SHA256
EPOCHS=100
BATCH=16
RUNS=[(name,method) for name in ('PH2','Waterloo') for method in ('uper64','abl')]

def file_hash(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def initial_digest(model):
    dig=hashlib.sha256()
    for name,val in model.state_dict().items():
        dig.update(name.encode());dig.update(val.detach().cpu().contiguous().numpy().tobytes())
    return dig.hexdigest()
def write_rows(path,rows):
    tmp=path.with_suffix('.tmp')
    with tmp.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    tmp.replace(path)
def load_split(ds,split):
    out=ROOT/ds
    with (out/'split.csv').open() as f:rows=[r for r in csv.DictReader(f) if r['split']==split]
    with np.load(out/(split+'.npz'),allow_pickle=False) as z:
        assert [r['id'] for r in rows]==z['ids'].tolist()
        raw=z['images']
        assert all(hashlib.sha256(im.tobytes()).hexdigest()==r['sha256_rgb'] for im,r in zip(raw,rows))
        imgs=torch.from_numpy(raw).permute(0,3,1,2).contiguous().cuda().float()/255.
        gts=torch.from_numpy(z['masks']).unsqueeze(1).cuda().float()
    return imgs,gts,rows
def geometry(img,gt,epoch):
    g=torch.Generator().manual_seed(42+100003*epoch);n=len(img)
    order=torch.randperm(n,generator=g)
    h=torch.where(torch.rand(n,generator=g)<.5,-1.,1.)
    v=torch.where(torch.rand(n,generator=g)<.5,-1.,1.)
    rot=torch.rand(n,generator=g)<.5
    angle=torch.rand(n,generator=g)*(2*torch.pi)*rot
    mat=torch.zeros(n,2,3)
    mat[:,0,0]=angle.cos()*h;mat[:,0,1]=-angle.sin()*h
    mat[:,1,0]=angle.sin()*v;mat[:,1,1]=angle.cos()*v
    grid=F.affine_grid(mat.cuda(),img.shape,align_corners=False)
    return order.cuda(),F.grid_sample(img,grid,mode='bilinear',align_corners=False),F.grid_sample(gt,grid,mode='nearest',align_corners=False)
def norm(x):
    return (x-x.new_tensor([.485,.456,.406])[None,:,None,None])/x.new_tensor([.229,.224,.225])[None,:,None,None]
@torch.inference_mode()
def evaluate(model,split):
    model.eval();imgs,gts,meta=split;rows=[]
    for first in range(0,len(meta),32):
        with torch.autocast('cuda',dtype=torch.bfloat16):logits=model(norm(imgs[first:first+32]))['main'].float()
        assert torch.isfinite(logits).all()
        p=logits.sigmoid()>=.5;g=gts[first:first+32]>=.5
        values=torch.stack([(p&g).sum((1,2,3)),(p&~g).sum((1,2,3)),(~p&g).sum((1,2,3))],1).cpu().tolist()
        for r,(tp,fp,fn) in zip(meta[first:first+32],values):
            denom=2*tp+fp+fn
            rows.append(dict(id=r['id'],group=r['group'],stratum=r['stratum'],tp=tp,fp=fp,fn=fn,dice=2*tp/denom if denom else 1.))
    return float(np.mean([r['dice'] for r in rows])),rows
def cfg(ds,arm):
    return dict(dataset=ds,arm=arm,epochs=EPOCHS,batch=BATCH,seed=42,image_size=256,threshold=.5,split_sha256=file_hash(ROOT/ds/'split.csv'),
        encoder_init='nvidia/MambaVision-S-1K',encoder_sha256=WEIGHT_SHA256,head_init='native UPer64 seed=42',encoder_trainable=[3,4],decoder_lr=.001,encoder_lr=.0001,
        source_sha256=file_hash(Path(__file__)),train_source='target train split only',selection='highest target validation macro Dice; earliest tie',
        loss='BCE + soft Dice'+(' + 0.2 ABL' if arm=='abl' else ''),augmentation='seeded flips and rotations')
def train(ds,arm):
    dest=ROOT/ds/arm;dest.mkdir(exist_ok=True);config=cfg(ds,arm)
    if (dest/'config.json').exists():assert json.load((dest/'config.json').open())==config
    if (dest/'complete.json').exists():return
    reference.setup()
    model=build('add',seed=42)
    init=initial_digest(model)
    control_path=ROOT/ds/'uper64'/'init.json'
    if arm=='abl':assert json.load(control_path.open())['state_sha256']==init
    atomic_json(dest/'config.json',config);atomic_json(dest/'init.json',dict(state_sha256=init,official_encoder_sha256=WEIGHT_SHA256))
    opt=optimizer(model);layer=BoundaryCriterion().cuda() if arm=='abl' else None
    train_x,train_gt,_=load_split(ds,'train');val=load_split(ds,'val')
    history=[];best=-1.;cp=dest/'resume.pth'
    if cp.exists():
        saved=torch.load(cp,map_location='cpu');assert saved['config']==config
        model.load_state_dict(saved['model']);opt.load_state_dict(saved['optimizer']);restore_rng(saved['rng']);history=saved['history'];del saved
    # A best file may be newer than the last durable resume snapshot.
    if (dest/'best.pth').exists():
        saved=torch.load(dest/'best.pth',map_location='cpu');assert saved['config']==config;best=saved['val_macro_dice'];del saved
    for epoch in range(len(history)+1,EPOCHS+1):
        tick=time.monotonic()
        factor=.01+.99*(1+math.cos(math.pi*(epoch-1)/EPOCHS))/2
        for group in opt.param_groups:group['lr']=group['initial_lr']*factor
        model.train();order,images,target=geometry(train_x,train_gt,epoch);images=norm(images)
        if layer is not None:dist,valid=layer.maps(target)
        # Balance the final minibatches if an otherwise singleton batch occurs.
        batches=list(order.split(BATCH))
        if len(batches)>1 and len(batches[-1])==1:batches[-2:]=[torch.cat(batches[-2:])]
        total=0.
        for idx in batches:
            opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda',dtype=torch.bfloat16):
                z=model(images[idx])['main'].float()
            main=segmentation_loss(z,target[idx]);loss=main if layer is None else main+COEFFICIENT*layer(z,dist[idx],valid[idx])
            if not torch.isfinite(loss):raise FloatingPointError('training loss')
            loss.backward()
            norms={group['name']:float(torch.nn.utils.clip_grad_norm_(group['params'],1.,error_if_nonfinite=True)) for group in opt.param_groups}
            if epoch==1 and idx.data_ptr()==batches[0].data_ptr():
                first=dict(initial_main=float(main.detach()),total=float(loss.detach()),group_gradient_norms=norms)
                assert min(norms.values())>0
                if layer is not None:
                    main0=json.load((ROOT/ds/'uper64'/'first_update.json').open())['initial_main']
                    assert abs(first['initial_main']-main0)<1e-4,(first,main0)
                atomic_json(dest/'first_update.json',first)
            opt.step();total+=float(loss.detach())*len(idx)
        score,rows=evaluate(model,val)
        record=dict(epoch=epoch,loss=total/len(order),val_macro_dice=score,elapsed_sec=time.monotonic()-tick)
        history.append(record)
        if score>best:
            best=score
            atomic_save(dest/'best.pth',dict(config=config,epoch=epoch,val_macro_dice=score,model=base.cpu_tree(model.state_dict())))
        atomic_json(dest/'history.json',history)
        if epoch%20==0 and epoch<EPOCHS:
            atomic_save(cp,dict(config=config,model=base.cpu_tree(model.state_dict()),optimizer=base.cpu_tree(opt.state_dict()),history=history,rng=rng_state()))
        if epoch==1 or epoch%5==0:print(ds,arm,epoch,'validation',round(score,6),'best',round(best,6),'epoch seconds',round(record['elapsed_sec'],2),flush=True)
    saved=torch.load(dest/'best.pth',map_location='cpu');model.load_state_dict(saved['model'],strict=True)
    score,rows=evaluate(model,val);assert abs(score-saved['val_macro_dice'])<1e-9
    write_rows(dest/'best_validation.csv',rows)
    atomic_json(dest/'complete.json',dict(epochs=len(history),best_epoch=saved['epoch'],val_macro_dice=score,checkpoint_sha256=file_hash(dest/'best.pth'),init_sha256=init))
    if cp.exists():cp.unlink()
def test():
    # Fix and verify all four validation-selected checkpoints before opening either test archive.
    for ds,arm in RUNS:
        where=ROOT/ds/arm
        assert json.load((where/'complete.json').open())['checkpoint_sha256']==file_hash(where/'best.pth')
    all_results={}
    for ds in ('PH2','Waterloo'):
        data=load_split(ds,'test');metrics={};results={}
        for arm in ('uper64','abl'):
            where=ROOT/ds/arm
            saved=torch.load(where/'best.pth',map_location='cpu');assert saved['config']==cfg(ds,arm)
            model=build('add');model.load_state_dict(saved.pop('model'),strict=True)
            score,rows=evaluate(model,data);write_rows(where/'test_per_image.csv',rows)
            metrics[arm]=dict(best_epoch=saved['epoch'],val_macro_dice=saved['val_macro_dice'],test_macro_dice=score)
            results[arm]=rows
            del model,saved;gc.collect();torch.cuda.empty_cache()
        a,b=results['uper64'],results['abl'];assert [(x['id'],x['group']) for x in a]==[(x['id'],x['group']) for x in b]
        diff=np.array([100*(y['dice']-x['dice']) for x,y in zip(a,b)])
        groups=sorted({r['group'] for r in a})
        sums=np.array([sum(v for v,r in zip(diff,a) if r['group']==g) for g in groups]);sizes=np.array([sum(r['group']==g for r in a) for g in groups])
        draw=np.random.default_rng(42).integers(len(groups),size=(10000,len(groups)))
        all_results[ds]=dict(n_test=len(a),test_groups=len(groups),metrics=metrics,abl_delta_pp=float(diff.mean()),group_bootstrap95_pp=np.quantile(sums[draw].sum(1)/sizes[draw].sum(1),[.025,.975]).tolist())
    atomic_json(ROOT/'test_results.json',all_results)
if __name__=='__main__':
    with (ROOT/'training.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for ds,arm in RUNS:
            train(ds,arm);gc.collect();torch.cuda.empty_cache()
        test()
