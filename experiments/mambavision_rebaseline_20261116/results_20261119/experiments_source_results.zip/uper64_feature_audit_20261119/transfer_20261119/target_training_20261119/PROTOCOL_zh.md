# PH² 与 Waterloo 数据集内训练

固定日期为 2026-11-19，划分与训练种子均为 42。每个数据集各训练 MambaVision-S + UPer64 基线及其 ABL 对照，共四次，各 100 轮。模型从 NVIDIA 的 MambaVision-S-1K 通用图像分类权重初始化，使用固定随机种子重新构建 UPer64 解码头。两组初始模型的整个 state_dict 哈希必须相同。训练可更新编码器第 3、4 阶段及解码头。两个数据集各自训练和选模。

| 数据 | 训练 | 验证 | 测试 | 划分单位 |
|---|---:|---:|---:|---|
| PH² | 120 | 40 | 40 | 以 IMD 编号为单位，按三种诊断分层 |
| Waterloo | 124 | 41 | 41 | 按来源、诊断分层，按病灶编号归组；分别有 100、33、34 个可识别组 |

使用文件名识别 Waterloo 的原视图及带数字后缀的附加视图，另对两套数据内部进行重复筛查。逐个病灶编号和图像分配见对应目录的 split.csv。不具有完整患者身份，只能验证可识别组之间的隔离。上一轮不同模型的外推实验曾对全部图像做过测试，本轮数据划分仅使用来源、诊断及图像身份信息。评价性质为固定划分下的数据集内训练与测试。

输入为 256×256，图像双线性、掩膜最近邻；沿用原先的翻转、旋转、ImageNet 归一化与 BF16 前向；无测试时增强。批量大小 16，AdamW、编码器/解码器初始学习率 0.0001/0.001，余弦衰减，权重衰减 0.01。对照仅在 BCE + 逐图 soft Dice 基础上加入 0.2 倍 Active Boundary Loss。训练入口仅按目标数据的 train 文件更新参数。各数据集各自按验证集最高逐图前景 Dice 选权重，同分保留较早轮次。固定每个最佳权重并重放验证分数后，再使用四组模型分别评估相应测试集。阈值固定为 0.5。

初始化已由模型加载器逐文件核验源代码、模型 SHA-256 和实际权重各张量。通用权重 SHA-256 为 006af39903f2d88c5b455431d087d0fcbf5d5932114aef52542c0d2f0b1ec180，源自 [NVIDIA MambaVision-S-1K 固定版本](https://huggingface.co/nvidia/MambaVision-S-1K/tree/e4f9ea93877fba6f1e2d231fd0f0a391368ad895)。

每个数据集目录下含 split.json、split.csv；每个方法目录下含 config.json、init.json、first_update.json、history.json、best.pth、best_validation.csv、complete.json 和最终的 test_per_image.csv。最终汇总 test_results.json 的差值定义为 ABL 减基线。配对自举按可识别组重采样，组内保留所有图像，报告固定权重下的抽样差异。
