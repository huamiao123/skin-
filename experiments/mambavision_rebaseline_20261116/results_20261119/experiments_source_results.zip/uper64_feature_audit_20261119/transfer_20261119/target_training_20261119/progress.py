from pathlib import Path
import json,time,datetime
root=Path(__file__).resolve().parent
def snapshot():
 rows=[]
 for ds in ('PH2','Waterloo'):
  for arm in ('uper64','abl'):
   f=root/ds/arm/'history.json'
   if f.exists():
    h=json.loads(f.read_text());b=max(h,key=lambda x:x['val_macro_dice'])
    rows.append(dict(dataset=ds,arm=arm,epoch=len(h),best_epoch=b['epoch'],best_val=round(b['val_macro_dice'],5)))
 return rows
if __name__=='__main__':
 import sys
 timeout=int(sys.argv[1]) if len(sys.argv)>1 else 0
 until=time.monotonic()+min(50,timeout)
 while time.monotonic()<until:
  if (root/'test_results.json').is_file() or 'Traceback' in (root/'training.log').read_text():break
  time.sleep(min(3,max(0,until-time.monotonic())))
 print(snapshot(),flush=True)
 if 'Traceback' in (root/'training.log').read_text():print((root/'training.log').read_text()[-2000:])
