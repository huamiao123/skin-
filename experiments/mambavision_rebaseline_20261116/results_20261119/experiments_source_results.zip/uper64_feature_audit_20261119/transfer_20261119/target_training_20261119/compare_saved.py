"""Compare already exported predictions on identical held-out image IDs, after target model lock."""
import csv,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
assert (ROOT/'test_results.json').exists()
def read_csv(p):
    with p.open() as f:return list(csv.DictReader(f))
old={(r['dataset'],r['id']):r for r in read_csv(ROOT.parent/'external_test_20261119'/'per_image.csv')}
result={}
for ds in ('PH2','Waterloo'):
    split={r['id']:r for r in read_csv(ROOT/ds/'split.csv') if r['split']=='test'}
    result[ds]={}
    for arm in ('uper64','abl'):
        new=read_csv(ROOT/ds/arm/'test_per_image.csv')
        assert set(split)=={r['id'] for r in new} and len(new)==len(split)
        pairs=[]
        for r in new:
            prior=old[(ds,r['id'])]
            assert split[r['id']]['sha256_rgb']==prior['resized_rgb_sha256']
            assert int(r['tp'])+int(r['fn'])==int(prior[arm+'_tp'])+int(prior[arm+'_fn'])
            pairs.append((float(prior[arm+'_dice']),float(r['dice'])))
        a,b=np.array(pairs).T
        result[ds][arm]=dict(n=len(new),historical_zero_shot_macro_dice=float(a.mean()),current_target_macro_dice=float(b.mean()),target_minus_historical_pp=float(100*(b-a).mean()))
f=ROOT/'same_test_ids_historical_scores.json';tmp=f.with_suffix('.tmp');tmp.write_text(json.dumps(result,indent=2)+'\n');tmp.replace(f)
print(json.dumps(result,indent=2))
