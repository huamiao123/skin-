import collections,csv,hashlib,json,re,sys,os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import cv2,numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'external_test_20261119'))
from evaluate_external import arrays,external_cases,phash,save_csv,atomic_json
from review_overlap import geometric
CLINICAL=Path('/home/featurize/work/RSI_Implementation_20261003/data_manifests/external_ph2_historical_clinical_metadata.csv')
WEIGHTS=np.array([.6,.2,.2])
SPLITS=('train','val','test')
def run():
    cv2.setNumThreads(1)
    meta={r['image_id']:r['clinical_diagnosis'] for r in csv.DictReader(CLINICAL.open())}
    sets=collections.defaultdict(list)
    for ds,sid,src,ip,mp,ib,mb in external_cases():
        im,mask,_=arrays(ib,mb)
        if ds=='PH2':group=sid;stratum=meta[sid]
        else:group=re.sub(r'_[0-9]+$','',sid).lower();stratum=sid.rsplit('/',1)[0].lower()
        sets[ds].append((dict(id=sid,named_group=group,stratum=stratum),im,mask))
    for ds,items in sets.items():
        out=ROOT/ds;out.mkdir(exist_ok=True)
        keys=[a['named_group'] for a,_,_ in items]
        rep={k:k for k in keys}
        def find(k):
            while rep[k]!=k:k=rep[k]
            return k
        hashes=[];descriptors=[]
        detector=cv2.SIFT_create(nfeatures=450)
        for _,im,_ in items:
            hashes.append([phash(v) for j in range(4) for v in (np.rot90(im,j),np.fliplr(np.rot90(im,j)))])
            area=np.zeros((256,256),np.uint8);area[24:-24,24:-24]=255
            def features(a):
                return detector.detectAndCompute(cv2.cvtColor(a,cv2.COLOR_RGB2GRAY),area)
            descriptors.append((features(im),features(np.ascontiguousarray(np.fliplr(im)))))
        pairs=[(i,j) for i in range(len(items)) for j in range(i) if keys[i]!=keys[j] and min((h^hashes[j][0]).bit_count() for h in hashes[i])<=18]
        def match(pair):
            i,j=pair
            n,area=max(geometric(view,descriptors[j][0]) for view in descriptors[i])
            return i,j,n,area
        links=[]
        with ThreadPoolExecutor(8) as pool:
            for i,j,n,area in pool.map(match,pairs):
                if n>=10 and area>=.02:
                    a,b=find(keys[i]),find(keys[j]);rep[max(a,b)]=min(a,b)
                    links.append(dict(a=items[i][0]['id'],b=items[j][0]['id'],inliers=n,area=area))
        members=collections.defaultdict(list)
        for i,k in enumerate(keys):members[find(k)].append(i)
        rng=np.random.default_rng(42)
        strata=sorted({r['stratum'] for r,_,_ in items})
        groups=sorted(members)
        counts=np.array([[sum(items[i][0]['stratum']==s for i in members[g]) for s in strata] for g in groups])
        target=WEIGHTS[:,None]*counts.sum(0)[None,:]
        best=np.inf
        # Allocate entire groups by source and diagnosis, using counts alone.
        for trial in range(256):
            tally=np.zeros_like(target);assign={}
            order=sorted(rng.permutation(len(groups)),key=lambda j:-counts[j].sum())
            for j in order:
                before=((tally-target)**2/target).sum(1)
                after=((tally+counts[j]-target)**2/target).sum(1)
                pos=int(np.argmin(after-before+rng.random(3)*.00001))
                tally[pos]+=counts[j];assign[groups[j]]=pos
            score=np.sum((tally-target)**2/target)+np.sum((tally.sum(1)-target.sum(1))**2/target.sum(1))
            if score<best:best=score;chosen=assign
        rows=[];registry={}
        for i,(r,im,mask) in enumerate(items):
            g=find(keys[i]);sp=SPLITS[chosen[g]]
            rows.append(dict(**r,group=g,split=sp,sha256_rgb=hashlib.sha256(im.tobytes()).hexdigest()))
        assert len({r['sha256_rgb'] for r in rows})==len(items)
        for sp in SPLITS:
            idx=[i for i,r in enumerate(rows) if r['split']==sp]
            with (out/(sp+'.npz')).open('wb') as f:
                np.savez(f,ids=[rows[i]['id'] for i in idx],images=np.stack([items[i][1] for i in idx]),masks=np.stack([items[i][2] for i in idx]))
            registry[sp]=dict(n=len(idx),groups=len({rows[i]['group'] for i in idx}),strata=dict(collections.Counter(rows[i]['stratum'] for i in idx)))
        assert len(members)==sum(v['groups'] for v in registry.values())
        assert len(items)==sum(v['n'] for v in registry.values())
        save_csv(out/'split.csv',rows)
        info=dict(data=ds,seed=42,counts=registry,content_pairs_screened=len(pairs),additional_links=links,manifest_sha256=hashlib.sha256((out/'split.csv').read_bytes()).hexdigest())
        atomic_json(out/'split.json',info)
        print(ds,registry,'additional links',len(links),flush=True)
if __name__=='__main__':run()
