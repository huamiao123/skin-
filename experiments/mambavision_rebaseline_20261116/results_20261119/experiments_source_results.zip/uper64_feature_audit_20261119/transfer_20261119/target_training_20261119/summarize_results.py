from pathlib import Path
import csv,json,math
ROOT=Path(__file__).resolve().parent
def read(path):return json.loads(path.read_text())
def csvrows(path):
    with path.open() as stream:return list(csv.DictReader(stream))
def main():
    report=read(ROOT/'test_results.json')
    head=['# PH² 与 Waterloo 数据集内训练结果','','各组使用官方 MambaVision-S-1K 分类预训练骨干和随机初始化的 UPer64 解码头，自目标数据训练分区更新参数。使用固定验证集逐图平均 Dice 选出的权重在对应测试集评估。','','| 数据集 | 方法 | 最佳轮次 | 验证集逐图 Dice | 测试集逐图 Dice |','|---|---|---:|---:|---:|']
    for ds,res in report.items():
        ref=None;root=ROOT/ds
        splits=csvrows(root/'split.csv')
        for arm,m in res['metrics'].items():
            out=root/arm;hist=read(out/'history.json')
            assert [r['epoch'] for r in hist]==list(range(1,101))
            assert m['best_epoch']==max(hist,key=lambda r:r['val_macro_dice'])['epoch']
            init=read(out/'init.json')['state_sha256'];ref=ref or init;assert init==ref
            for split,key,filename in [('val','val_macro_dice','best_validation.csv'),('test','test_macro_dice','test_per_image.csv')]:
                rows=csvrows(out/filename)
                assert [r['id'] for r in rows]==[r['id'] for r in splits if r['split']==split]
                values=[]
                for row in rows:
                    tp,fp,fn=[int(row[k]) for k in ('tp','fp','fn')];den=2*tp+fp+fn;dice=2*tp/den if den else 1.
                    assert math.isclose(dice,float(row['dice']),abs_tol=1e-14)
                    values.append(dice)
                assert math.isclose(sum(values)/len(values),m[key],abs_tol=1e-14)
            head.append(f"| {ds} | {'UPer64' if arm=='uper64' else 'UPer64 + ABL'} | {m['best_epoch']} | {100*m['val_macro_dice']:.4f}% | {100*m['test_macro_dice']:.4f}% |")
    head.extend(['','## 测试集差值',''])
    for ds,res in report.items():
        l,h=res['group_bootstrap95_pp']
        head.append(f"- {ds} 共 {res['n_test']} 张图，{res['test_groups']} 个可识别组。ABL 减基线的差值为 {res['abl_delta_pp']:+.4f} 个百分点，以组为单位配对自举的 95% 区间为 [{l:+.4f}, {h:+.4f}]。")
    head.extend(['','两个数据集均为一次固定划分和一个训练种子。此前两套完整数据用于 ISIC 权重的外推评估；此前整套数据的均值与这里的子集分数不宜直接相减归因。','',
        '训练划分与复现信息见 [PROTOCOL_zh.md](PROTOCOL_zh.md)。四组的最佳权重、测试逐图混淆计数和曲线位于各自方法目录。'])
    path=ROOT/'RESULTS_zh.md';tmp=path.with_suffix('.tmp');tmp.write_text('\n'.join(head)+'\n');tmp.replace(path)
    print(path.read_text())
if __name__=='__main__':main()
