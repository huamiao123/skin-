"""Active Boundary Loss transfer on the matched native UPer64."""
import fcntl
import hashlib
import json
import math
from pathlib import Path
import sys

import torch
from torch import nn

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from train_feature import atomic_json, atomic_save, base, build, optimizer, reference, restore_rng, rng_state, validate, write_rows
from model import PROJECT, segmentation_loss


from active_boundary import BoundaryCriterion, COEFFICIENT, verify


def train(run):
    reference.setup()
    layer = BoundaryCriterion().cuda()
    toy = verify(layer)
    model = build("add")
    data, _ = reference.load_data()
    ids_val = data.ids["val"]
    assert (len(data.ids["train"]),len(ids_val))==(1886,762)
    opt=optimizer(model)
    ctrl=HERE.parent/"runs/add"
    ref=json.loads((ctrl/"config.json").read_text())
    for path,digest in ref["source_hashes"].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
    assert ref["head_parameters"]==sum(p.numel() for p in model.probe.parameters())
    source=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    config=dict(reference_config=ref, change="BCE + original per-image soft Dice + 0.2 x ABL",
                coefficient=COEFFICIENT, label="original soft target for primary; >=.5 for ABL",
                source_sha256=source, adapter_sha256=hashlib.sha256((HERE/"active_boundary.py").read_bytes()).hexdigest(), upstream_commit="1511507533ad98f04ea26e3648360a6c1d477d37")
    cfg=run/"config.json"
    if cfg.exists() and json.loads(cfg.read_text())!=config: raise RuntimeError("Resume configuration changed")
    atomic_json(cfg,config)
    val=reference.cache_new(len(ids_val))
    reference.fill_cache(model,data,"val",val)
    cache=reference.cache_new(len(data.ids["train"]))
    dist_cache=torch.empty_like(cache["target"][:,0])
    valid_cache=torch.empty(len(dist_cache),dtype=torch.bool,device=dist_cache.device)
    history=[]
    latest=run/"latest.pth"
    if latest.exists():
        state=torch.load(latest,map_location="cpu")
        assert state["config"]==config
        model.load_state_dict(state["model"])
        opt.load_state_dict(state["optimizer"])
        restore_rng(state["rng"])
        history=state["history"]
        del state
    best=max((v["val_macro_dice"] for v in history),default=-1.)
    for epoch in range(len(history)+1,101):
        order,geo=data.geometry(epoch)
        reference.fill_cache(model,data,"train",cache,geo)
        for start in range(0,len(order),64):
            block=slice(start,start+64)
            dist,valid=layer.maps(cache["target"][block])
            dist_cache[block].copy_(dist);valid_cache[block].copy_(valid)
        factor=.01+.99*(1+math.cos(math.pi*(epoch-1)/100))/2
        for group in opt.param_groups: group["lr"]=group["initial_lr"]*factor
        model.train()
        sum_main=sum_extra=0.
        for first in range(0,len(order),64):
            ids=order[first:first+64]
            target=cache["target"][ids]
            opt.zero_grad(set_to_none=True)
            with torch.autocast("cuda",dtype=torch.bfloat16):
                out=model.from_cache(cache["features"][0][ids],cache["features"][1][ids],cache["mid"][ids],target.shape[-2:])
            assert set(out)=={"main"}
            z=out["main"].float()
            main=segmentation_loss(z,target)
            reg=layer(z,dist_cache[ids],valid_cache[ids])
            loss=main+COEFFICIENT*reg
            if not torch.isfinite(loss): raise FloatingPointError("Nonfinite loss")
            if epoch==1 and first==0:
                old=json.loads((ctrl/"first_update.json").read_text())["loss"]
                assert abs(float(main.detach())-old)<1e-5,(main,old)
                reg_grad=torch.autograd.grad(reg,z,retain_graph=True)[0].abs().sum().item()
                assert math.isfinite(reg_grad) and reg_grad>0
            loss.backward()
            norms={g["name"]:float(nn.utils.clip_grad_norm_(g["params"],1.,error_if_nonfinite=True)) for g in opt.param_groups}
            opt.step()
            if epoch==1 and first==0:
                assert all(v>0 for v in norms.values())
                atomic_json(run/"first_update.json",dict(batch=len(ids), main=float(main.detach()),reference_main=old,
                            active_boundary_raw=float(reg.detach()),regularizer_logit_gradient_l1=reg_grad,group_norm=norms,toy=toy))
            sum_main+=float(main.detach())*len(ids)
            sum_extra+=float(reg.detach())*len(ids)
        scores,rows=validate(model,val,ids_val,None)
        record=dict(epoch=epoch,main_loss=sum_main/len(order),active_boundary_raw=sum_extra/len(order),**scores)
        history.append(record)
        if scores["val_macro_dice"]>best:
            best=scores["val_macro_dice"]
            atomic_save(run/"best.pth",dict(epoch=epoch,model=base.cpu_tree(model.state_dict()),scores=scores,config=config))
            write_rows(run/"best_validation.csv",rows)
        if epoch in (1,100) or epoch%5==0:
            atomic_save(latest,dict(config=config,model=base.cpu_tree(model.state_dict()),optimizer=base.cpu_tree(opt.state_dict()),
                                    rng=rng_state(),history=history))
        atomic_json(run/"history.json",history)
        print(json.dumps(record),flush=True)
    atomic_json(run/"complete.json",dict(best=max(history,key=lambda x:x["val_macro_dice"]),epochs=len(history),test_used=False))


if __name__=="__main__":
    run=HERE/"abl_uper64"
    run.mkdir(exist_ok=True)
    with (run/"run.lock").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if not (run/"complete.json").exists(): train(run)
