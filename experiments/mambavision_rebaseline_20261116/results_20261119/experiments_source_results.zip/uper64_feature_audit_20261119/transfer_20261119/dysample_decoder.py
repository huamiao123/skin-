"""Learn only the sampling locations of the final FPN top-down merge (f2 to f1)."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import torch
from torch import nn
from torch.nn import functional as F

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
from feature_decoder import build as baseline
ARMS=("dysample_f2_to_f1",)


def sample_layer():
    root=HERE/"upstream_dysample"
    path=root/"dysample.py"
    meta=json.loads((root/"manifest.json").read_text())
    assert meta["commit"]=="81a1de5caa95d55a0f5488425fa53ec7ef47f8f0"
    assert hashlib.sha256(path.read_bytes()).hexdigest()==meta["sha256"]
    spec=importlib.util.spec_from_file_location("author_dysample",path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    layer=mod.DySample(64,scale=2,style="lp",groups=4,dyscope=False)
    nn.init.zeros_(layer.offset.weight)
    nn.init.zeros_(layer.offset.bias)
    return layer


class SamplingHead(nn.Module):
    def __init__(self,native):
        super().__init__()
        self.native=native
        self.sampler=sample_layer()

    def forward(self,features):
        head=self.native
        inputs=head._transform_inputs(features)
        lateral=[conv(x) for conv,x in zip(head.lateral_convs,inputs)]
        lateral.append(head.psp_forward(inputs))
        for i in (3,2,1):
            top=lateral[i]
            shape=lateral[i-1].shape[-2:]
            if i==1 and tuple(shape)==(2*top.shape[-2],2*top.shape[-1]):
                with torch.autocast(top.device.type,enabled=False):
                    up=self.sampler(top.float()).to(top.dtype)
            else:
                up=F.interpolate(top,size=shape,mode="bilinear",align_corners=head.align_corners)
            lateral[i-1]=lateral[i-1]+up
        maps=[conv(x) for conv,x in zip(head.fpn_convs,lateral)]+[lateral[-1]]
        full=[maps[0]]+[F.interpolate(x,size=maps[0].shape[-2:],mode="bilinear",align_corners=head.align_corners) for x in maps[1:]]
        return head.cls_seg(head.fpn_bottleneck(torch.cat(full,dim=1)))


def build(arm):
    assert arm==ARMS[0]
    model=baseline("add")
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(42)
        model.probe.decode_head=SamplingHead(model.probe.decode_head).cuda()
    return model
