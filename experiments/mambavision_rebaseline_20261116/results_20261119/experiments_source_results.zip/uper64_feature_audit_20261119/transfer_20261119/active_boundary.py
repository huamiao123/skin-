"""Binary transfer of the author's ABL with per-image candidate budgets."""
import ast
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from operator import itemgetter
from pathlib import Path

import numpy as np
import torch
from scipy.ndimage import distance_transform_edt as distance
from torch import nn
from torch.nn import functional as F
from torchvision import transforms

ROOT=Path(__file__).resolve().parent
VENDOR=ROOT/"upstream_abl"
COEFFICIENT=.2


def author_class():
    manifest=json.loads((VENDOR/"manifest.json").read_text())
    assert manifest["commit"]=="1511507533ad98f04ea26e3648360a6c1d477d37"
    for path,digest in manifest["files"].items():
        assert hashlib.sha256((VENDOR/path).read_bytes()).hexdigest()==digest
    scope=dict(torch=torch,nn=nn,F=F,np=np,distance=distance,transforms=transforms,
               partial=partial,itemgetter=itemgetter)
    for name,keep in (("label_smooth.py",{"LabelSmoothSoftmaxCEV1"}),
                      ("abl.py",{"kl_div","one_hot2dist","class2one_hot","ABL"})):
        path=VENDOR/name
        text=path.read_text().replace("astype(np.bool)","astype(np.bool_)")
        tree=ast.parse(text);tree.body=[n for n in tree.body if getattr(n,"name",None) in keep]
        assert len(tree.body)==len(keep)
        exec(compile(tree,str(path),"exec"),scope)
        if name=="label_smooth.py":scope["LSSCE"]=scope["LabelSmoothSoftmaxCEV1"]
    return scope["ABL"],scope["kl_div"]


class BoundaryCriterion(nn.Module):
    def __init__(self):
        super().__init__()
        cls,self.kl=author_class()
        self.author=cls()
        thresholds=[1e-5]
        while thresholds[-1]<1e5: thresholds.append(thresholds[-1]*1.2)
        self.register_buffer("thresholds",torch.tensor(thresholds,dtype=torch.float32),persistent=False)

    @torch.no_grad()
    def candidates(self,z):
        ud=self.kl(z[:,:,1:],z[:,:,:-1]).sum(1)
        lr=self.kl(z[:,:,:,1:],z[:,:,:,:-1]).sum(1)
        score=F.pad(ud,(0,0,0,1))+F.pad(lr,(0,1,0,0))
        flat=score.flatten(1)
        limit=int(flat.shape[1]*self.author.max_N_ratio)
        # Inclusive threshold corresponds to the author's first geometric step
        # with <= floor(1% of pixels) selected, separately for every image.
        critical=flat.kthvalue(flat.shape[1]-limit,dim=1).values.contiguous()
        index=torch.searchsorted(self.thresholds,critical).clamp_max(len(self.thresholds)-1)
        mask=score>self.thresholds[index,None,None]
        return F.max_pool2d(mask[:,None].float(),3,1,1)[:,0].bool()

    def maps(self,target):
        edge=self.author.gt2boundary((target[:,0]>=.5).long(),ignore_label=255)
        arrays=edge.cpu().numpy()
        def from_edge(e):
            if not e.any(): return np.zeros(e.shape,dtype=np.float32)
            # one_hot2dist in the source writes into int32 before casting to float.
            return np.maximum(distance(~e)-1.,0.).astype(np.int32).astype(np.float32)
        with ThreadPoolExecutor(max_workers=6) as pool: result=np.stack(list(pool.map(from_edge,arrays)))
        return torch.from_numpy(result).to(target.device),edge.flatten(1).any(1)

    def forward(self,one_logit,dist,valid):
        z=torch.cat((torch.zeros_like(one_logit),one_logit),1)
        active=self.candidates(z)&valid[:,None,None]
        if not active.any():return one_logit.sum()*0
        direction,local,weight=self.author.get_direction_gt_predkl(dist,active,z)
        if direction.numel()==0:return one_logit.sum()*0
        return (self.author.criterion(local,direction)*self.author.weight_func(weight)).mean()


def verify(layer):
    grid=torch.arange(64,device="cuda",dtype=torch.float32)
    y,x=torch.meshgrid(grid,grid,indexing="ij")
    cases=[]
    for dx,dy in ((4,0),(-2,4)):
        label=(((x-32)/18)**2+((y-32)/13)**2<1).float()[None,None]
        smooth=4*(1-((x-32-dx)/18)**2-((y-32-dy)/13)**2)
        isolated=((x==12+dx)&(y==26+dy))|((x==48+dx)&(y==37))
        score=(smooth+isolated.float()*4)[None,None].requires_grad_()
        logits=torch.cat((torch.zeros_like(score),score),1)
        dist,valid=layer.maps(label)
        original_dist=layer.author.get_dist_maps(layer.author.gt2boundary(label[:,0].long())).to("cuda")
        assert torch.equal(original_dist,dist)
        assert torch.equal(layer.author.logits2boundary(logits),layer.candidates(logits))
        old=layer.author(logits,label[:,0].long())
        new=layer(score,dist,valid)
        assert old is not None
        torch.testing.assert_close(old,new,rtol=1e-6,atol=1e-7)
        go=torch.autograd.grad(old,score,retain_graph=True)[0]
        gn=torch.autograd.grad(new,score)[0]
        torch.testing.assert_close(go,gn,rtol=1e-5,atol=1e-7)
        assert float(gn.abs().sum())>0
        cases.append((logits.detach(),float(new.detach())))
    both=torch.cat([v[0] for v in cases])
    assert torch.equal(layer.candidates(both),torch.cat([layer.author.logits2boundary(v[0]) for v in cases]))
    return [v[1] for v in cases]
