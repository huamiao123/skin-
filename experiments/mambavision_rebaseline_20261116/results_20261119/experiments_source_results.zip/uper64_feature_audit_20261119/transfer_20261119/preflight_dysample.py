import json
import torch
from torch.nn import functional as F
from dysample_decoder import ARMS, HERE, build, sample_layer
from train_feature import reference, atomic_json


def main():
    reference.setup()
    layer=sample_layer()
    x=torch.randn(3,64,7,11)
    difference=(layer(x)-F.interpolate(x,scale_factor=2,mode="bilinear",align_corners=False)).abs().max().item()
    assert difference<5e-6,difference
    model=build(ARMS[0]).eval()
    data,_=reference.load_data()
    ix=torch.arange(8,device="cuda")
    ims,_=data.batch("train",ix)
    head=model.probe.decode_head
    with torch.no_grad(),torch.autocast("cuda",dtype=torch.bfloat16):
        f1,f2,mid=model.prefix(ims)
        f3,f4=model.suffix(mid)
        features=[f1,f2,f3,f4]
        native=head.native(features).float()
        sampled=head(features).float()
    error=(native-sampled).abs()
    disagreement=float(((native>=0)!=(sampled>=0)).float().mean())
    # Native BF16 interpolation can round intermediate operations differently.
    assert float(error.mean())<.002 and disagreement<.002,(float(error.mean()),disagreement)
    atomic_json(HERE/"dysample_preflight.json",dict(cpu_regular_grid_max_error=difference,
            real_train_images=8,feature_logits_mean_abs=float(error.mean()),
            feature_logits_max_abs=float(error.max()),mask_disagreement_fraction=disagreement,
            additional_parameters=sum(p.numel() for p in head.sampler.parameters())))
    print("preflight passed",flush=True)


if __name__=="__main__":main()
