"""How far are remaining errors from the GT contour when score ordering is fixed?"""
from pathlib import Path
import csv
import numpy as np
import torch
from scipy.ndimage import distance_transform_edt
from area_oracle import HERE, reference, build, write_rows, atomic_json


def expected_mask(z, k):
    if k == 0:
        return np.zeros_like(z)
    flat=z.reshape(-1)
    cut=np.partition(flat,flat.size-k)[flat.size-k]
    above=z>cut
    ties=z==cut
    return above.astype(np.float64)+ties*((k-int(above.sum()))/int(ties.sum()))


@torch.inference_mode()
def main(candidate_dir=None,candidate_factory=None):
    torch.cuda.set_per_process_memory_fraction(.22)
    reference.setup()
    model=(candidate_factory() if candidate_factory else build("add")).eval()
    folder=candidate_dir or HERE.parent/"runs/add"
    state=torch.load(folder/"best.pth",map_location="cpu")
    model.load_state_dict(state["model"])
    del state
    reference_csv=(candidate_dir/"best_validation.csv") if candidate_dir else HERE/"baseline_area_oracle.csv"
    with reference_csv.open() as f:
        reference_rows={r["id"]:r for r in csv.DictReader(f)}
    data,_=reference.load_data()
    rows=[]
    for first in range(0,len(data.ids["val"]),64):
        ix=torch.arange(first,min(first+64,len(data.ids["val"])),device="cuda")
        x,y=data.batch("val",ix)
        with torch.autocast("cuda",dtype=torch.bfloat16):
            z=model(x)["main"][:,0].float()
        hard=(z.sigmoid()>=.5).cpu().numpy()
        for j,(logit,g,pred) in enumerate(zip(z.cpu().numpy(),(y[:,0]>=.5).cpu().numpy(),hard)):
            sid=data.ids["val"][first+j]
            assert g.any()
            dist_in=distance_transform_edt(np.pad(g,1))[1:-1,1:-1]
            dist_out=distance_transform_edt(~g)
            row={"id":sid}
            for name,mask in (("base",pred),("oracle",expected_mask(logit,int(g.sum())))):
                den=float(mask.sum()+g.sum())
                for kind,errors,dist in (("fn",(1.-mask)*g,dist_in),("fp",mask*(~g),dist_out)):
                    for label,take in (("near",dist<=3),("mid",(dist>3)&(dist<=8)),("far",dist>8)):
                        row[name+"_"+kind+"_"+label]=100*float(errors[take].sum())/den
                key="dice" if name=="base" else "area_oracle"
                deficit=sum(v for k,v in row.items() if k.startswith(name+"_"))
                if key in reference_rows[sid]:
                    assert abs(deficit-100*(1-float(reference_rows[sid][key])))<1e-8
            rows.append(row)
    assert len(rows)==762
    write_rows((candidate_dir/"geometry.csv" if candidate_dir else HERE/"oracle_geometry.csv"),rows)
    means={k:float(np.mean([r[k] for r in rows])) for k in rows[0] if k!="id"}
    atomic_json((candidate_dir/"geometry.json" if candidate_dir else HERE/"oracle_geometry.json"),dict(n=762,metric="percentage points of mean per-image Dice deficit",means=means))
    print(means,flush=True)


if __name__=="__main__":
    main()
