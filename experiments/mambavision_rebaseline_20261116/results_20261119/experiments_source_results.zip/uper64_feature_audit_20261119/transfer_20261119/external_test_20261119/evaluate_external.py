"""Fixed-checkpoint external evaluation of PH2 and Waterloo on the project 256x256 grid."""
from pathlib import Path
from io import BytesIO
import csv, hashlib, json, sys, zipfile
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import cv2
import numpy as np
import torch
from PIL import Image

ROOT=Path(__file__).resolve().parent
TRANSFER=ROOT.parent
sys.path.insert(0,str(TRANSFER/'abl_uper64/failure_review'))
from review import load_model,reference,saved_rows,atomic_json
ISIC=Path(reference.__file__).resolve().parent.parent
PH2=Path('/home/featurize/rsi_data/ph2_originality_candidates/lakshyak_2017_extracted/PH2Dataset/PH2 Dataset images')
PH_MANIFEST=Path('/home/featurize/work/RSI_Implementation_20261003/data_manifests/external_ph2_mirror_manifest.csv')
MODELS={'uper64':TRANSFER.parent/'runs/add','abl':TRANSFER/'abl_uper64'}
SIZE=(256,256)
def sha(b):return hashlib.sha256(b).hexdigest()
def save_csv(path,rows):
    tmp=path.with_suffix('.tmp')
    with tmp.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    tmp.replace(path)
def arrays(ib,mb):
    with Image.open(BytesIO(ib)) as im,Image.open(BytesIO(mb)) as m:
        assert im.size==m.size
        orig=np.asarray(m.convert('L'));assert np.array_equal(np.unique(orig),[0,255])
        img=np.array(im.convert('RGB').resize(SIZE,Image.Resampling.BILINEAR))
        gt=np.array(m.convert('L').resize(SIZE,Image.Resampling.NEAREST))>=128
        assert gt.any() and not gt.all()
        return img,gt,im.size
def external_cases():
    with PH_MANIFEST.open() as f:
        ph_rows={r['image_id']:r for r in csv.DictReader(f)}
    assert len(ph_rows)==200
    for sid,r in sorted(ph_rows.items()):
        ip=PH2/sid/(sid+'_Dermoscopic_Image')/(sid+'.bmp')
        mp=PH2/sid/(sid+'_lesion')/(sid+'_lesion.bmp')
        ib,mb=ip.read_bytes(),mp.read_bytes()
        assert sha(ib)==r['rgb_sha256'] and sha(mb)==r['mask_sha256'],sid
        yield 'PH2',sid,'Pedro Hispano',str(ip),str(mp),ib,mb
    with zipfile.ZipFile(ROOT/'data/waterloo.zip') as z:
        names=set(z.namelist())
        originals=sorted(n for n in names if n.lower().endswith('_orig.jpg'))
        masks={n for n in names if n.lower().endswith('_contour.png')}
        assert len(originals)==206 and {n[:-9]+'_contour.png' for n in originals}==masks
        for ip in originals:
            mp=ip[:-9]+'_contour.png'
            group=Path(ip).parent.name.lower()
            sid='/'.join(Path(ip).parts[-3:])[:-9]
            yield 'Waterloo',sid,group,ip,mp,z.read(ip),z.read(mp)

def phash(a):
    a=cv2.resize(a,(32,32),interpolation=cv2.INTER_AREA)
    a=cv2.cvtColor(a,cv2.COLOR_RGB2GRAY).astype(np.float32)
    block=cv2.dct(a)[:8,:8].ravel()[1:]
    return int.from_bytes(np.packbits(block>np.median(block)).tobytes(),'big')

def load_reference_image(row):
    f=ISIC/'data/isic2018'/row['split']/'images'/(row['id']+'.png')
    with Image.open(f) as im:a=np.asarray(im.convert('RGB').resize(SIZE,Image.Resampling.BILINEAR))
    digest=sha(a.tobytes())
    assert digest==row['decoded_image_sha256']
    return row['split']+'/'+row['id'],digest,phash(a)

@torch.inference_mode()
def predictions(model,rows):
    mean=torch.tensor([.485,.456,.406],device='cuda')[None,:,None,None]
    std=torch.tensor([.229,.224,.225],device='cuda')[None,:,None,None]
    x=torch.from_numpy(np.stack(rows)).cuda().permute(0,3,1,2).contiguous().float()/255.
    with torch.autocast('cuda',dtype=torch.bfloat16):
        z=model((x-mean)/std)['main'][:,0].float()
    assert torch.isfinite(z).all()
    return (z.sigmoid()>=.5).cpu().numpy()

def counts(pred,gt):
    tp=int(np.count_nonzero(pred & gt));fp=int(pred.sum())-tp;fn=int(gt.sum())-tp
    return tp,fp,fn

def mean_scores(rows):
    u=np.array([r['uper64_dice'] for r in rows]);a=np.array([r['abl_dice'] for r in rows]);diff=a-u
    rng=np.random.default_rng(42);sample=rng.integers(len(diff),size=(10000,len(diff)))
    return dict(n=len(rows),uper64_macro_dice=u.mean(),abl_macro_dice=a.mean(),abl_minus_uper64_pp=100*diff.mean(),
        paired_image_bootstrap95_pp=(100*np.quantile(diff[sample].mean(1),[.025,.975])).tolist())
def main():
    reference.setup();cv2.setNumThreads(1)
    refs=json.loads((ISIC/'stage1_visual/data_manifest.json').read_text())['members']
    part=json.loads((ISIC/'stage45_upernet_decoder/identity_partition.json').read_text())['splits']
    active={(sp,i) for sp in ['train','val'] for i in part[sp]}
    with ThreadPoolExecutor(8) as pool:
        known=list(pool.map(load_reference_image,(r for r in refs if (r['split'],r['id']) in active)))
    assert len(known)==2648
    ref_exact={r[1] for r in known}
    imgs=[];gts=[];manifest=[];raw_seen=Counter(); seen=Counter()
    for ds,sid,source,ip,mp,ib,mb in external_cases():
        a,g,wh=arrays(ib,mb);dig=sha(a.tobytes())
        signs=[phash(v) for j in range(4) for v in (np.rot90(a,j),np.fliplr(np.rot90(a,j)))]
        dist,near=min(((h0^h1).bit_count(),ident) for h0 in signs for ident,_,h1 in known)
        record=dict(dataset=ds,id=sid,source=source,image_path=ip,mask_path=mp,width=wh[0],height=wh[1],image_sha256=sha(ib),mask_sha256=sha(mb),
            resized_rgb_sha256=dig,gt_area_px=int(g.sum()),exact_training_or_validation_match=dig in ref_exact,nearest_reference_phash_distance=dist,nearest_reference=near)
        imgs.append(a);gts.append(g);manifest.append(record);seen[dig]+=1;raw_seen[record['image_sha256']]+=1
    assert len(manifest)==len({(r['dataset'],r['id']) for r in manifest})==406
    save_csv(ROOT/'manifest.csv',manifest)
    models={k:load_model(v) for k,v in MODELS.items()}
    # Reconstruct an existing 64-image validation batch via the external input path.
    ids=part['val'][:64];sample=[];targets=[]
    for sid in ids:
        ip=ISIC/'data/isic2018/val/images'/(sid+'.png')
        mp=next((ISIC/'data/isic2018/val/masks').glob(sid+'_*'),None) or ISIC/'data/isic2018/val/masks'/(sid+'.png')
        assert mp.exists()
        with Image.open(ip) as f:sample.append(np.array(f.convert('RGB').resize(SIZE,Image.Resampling.BILINEAR)))
        with Image.open(mp) as f:targets.append(np.array(f.convert('L').resize(SIZE,Image.Resampling.NEAREST))>=128)
    for k,m in models.items():
        old=saved_rows(MODELS[k]);actual=predictions(m,sample)
        for sid,p,g in zip(ids,actual,targets):
            assert counts(p,g)==tuple(int(old[sid][i]) for i in ('tp','fp','fn')),(k,sid)
    rows=[]
    for ds in ('PH2','Waterloo'):
        indices=[i for i,r in enumerate(manifest) if r['dataset']==ds]
        for start in range(0,len(indices),64):
            group=indices[start:start+64];batch=[imgs[i] for i in group];pred={k:predictions(m,batch) for k,m in models.items()}
            for j,i in enumerate(group):
                r=manifest[i];row={k:r[k] for k in ('dataset','id','source','resized_rgb_sha256','exact_training_or_validation_match')}
                for key,values in pred.items():
                    tp,fp,fn=counts(values[j],gts[i]);d=2*tp/(2*tp+fp+fn)
                    row.update({key+'_tp':tp,key+'_fp':fp,key+'_fn':fn,key+'_dice':d})
                rows.append(row)
    save_csv(ROOT/'per_image.csv',rows)
    metrics={}
    for ds in ('PH2','Waterloo'):
        subset=[r for r in rows if r['dataset']==ds and not r['exact_training_or_validation_match']]
        metrics[ds]=mean_scores(subset)
    summary=dict(metrics=metrics,epoch=39,threshold=.5,grid=SIZE,precision='BF16 autocast, FP32 sigmoid',tta=False,retraining=False,
        fixed_validation_replay_exact=len(ids),reference_screened=len(known),exact_external_versus_development=sum(r['exact_training_or_validation_match'] for r in manifest),
        external_repeat_resized_images=sum(n-1 for n in seen.values()),near_hash_screen_at_most_6=[{k:r[k] for k in ('dataset','id','nearest_reference','nearest_reference_phash_distance')} for r in manifest if r['nearest_reference_phash_distance']<=6],
        checkpoints={k:dict(path=str(v/'best.pth'),sha256=sha((v/'best.pth').read_bytes())) for k,v in MODELS.items()})
    atomic_json(ROOT/'results.json',summary)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
