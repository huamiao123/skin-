"""Inspect all low-distance cross-dataset image hashes and record a sensitivity analysis."""
from evaluate_external import *
from PIL import ImageDraw,ImageFont
cv2.setNumThreads(1)
def prep(a):
    gray=cv2.cvtColor(a,cv2.COLOR_RGB2GRAY)
    return cv2.SIFT_create(nfeatures=650).detectAndCompute(gray,None)
def geometric(kd1,kd2):
    k1,d1=kd1;k2,d2=kd2
    if d1 is None or d2 is None or min(len(d1),len(d2))<4:return (0,0)
    matcher=cv2.BFMatcher()
    forward=matcher.knnMatch(d1,d2,k=2)
    reverse=matcher.knnMatch(d2,d1,k=2)
    mutual={(m.trainIdx,m.queryIdx) for m,n in reverse if m.distance<.72*n.distance}
    good=[m for m,n in forward if m.distance<.72*n.distance and (m.queryIdx,m.trainIdx) in mutual]
    if len(good)<4:return (0,0)
    a=np.float32([k1[m.queryIdx].pt for m in good])
    b=np.float32([k2[m.trainIdx].pt for m in good])
    _,inliers=cv2.estimateAffinePartial2D(a,b,method=cv2.RANSAC,ransacReprojThreshold=3)
    inc=0 if inliers is None else int(inliers.sum())
    if inc<3:return inc,0
    support=inliers.ravel().astype(bool)
    coverage=min(cv2.contourArea(cv2.convexHull(points[support])) for points in (a,b))/(256*256)
    return inc,float(coverage)

def main():
    manifest=list(csv.DictReader((ROOT/'manifest.csv').open()))
    scores=list(csv.DictReader((ROOT/'per_image.csv').open()))
    for r in scores:
        for key in ['uper64_dice','abl_dice']:r[key]=float(r[key])
    flagged=[r for r in manifest if int(r['nearest_reference_phash_distance'])<=6]
    keys={(r['dataset'],r['id']) for r in flagged}
    part=json.loads((ISIC/'stage45_upernet_decoder/identity_partition.json').read_text())['splits']
    refs=json.loads((ISIC/'stage1_visual/data_manifest.json').read_text())['members']
    active={(sp,i) for sp in ['train','val'] for i in part[sp]}
    with ThreadPoolExecutor(8) as pool:
        known=list(pool.map(load_reference_image,(r for r in refs if (r['split'],r['id']) in active)))
    canvas=Image.new('RGB',(4*206,((len(flagged)+3)//4)*119),'white');draw=ImageDraw.Draw(canvas)
    checks=[];seen=0
    for ds,sid,src,ip,mp,ib,mb in external_cases():
        if (ds,sid) not in keys:continue
        a,_,_=arrays(ib,mb)
        ext=[phash(v) for j in range(4) for v in (np.rot90(a,j),np.fliplr(np.rot90(a,j)))]
        matches=sorted((min((h^h1).bit_count() for h in ext),ident) for ident,_,h1 in known)
        cand=[(delta,ident) for delta,ident in matches if delta<=6]
        rp=prep(a);fp=prep(np.ascontiguousarray(np.fliplr(a)))
        ranked=[]
        for dist,ident in cand:
            split,ref_id=ident.split('/')
            path=ISIC/'data/isic2018'/split/'images'/(ref_id+'.png')
            with Image.open(path) as im:b=np.array(im.convert('RGB').resize(SIZE,Image.Resampling.BILINEAR))
            kp=prep(b)
            n,area=max(geometric(rp,kp),geometric(fp,kp))
            checks.append(dict(dataset=ds,id=sid,reference=ident,hash_distance=dist,sift_inliers=n,sift_area_fraction=area))
            ranked.append((n,area,-dist,ident,b))
        n,area,_,ident,b=max(ranked,key=lambda r:r[:4])
        x=(seen%4)*206;y=(seen//4)*119
        for col,im in enumerate((a,b)):
            canvas.paste(Image.fromarray(im).resize((98,94)),(x+col*100,y))
        draw.text((x,y+95),sid.rsplit('/',1)[-1]+' | '+ident+' #'+str(n),fill='black')
        seen+=1
    canvas.save(ROOT/'near_pair_review.jpg',quality=80)
    save_csv(ROOT/'near_pairs.csv',checks)
    remaining=[r for r in scores if r['dataset']=='Waterloo' and (r['dataset'],r['id']) not in keys]
    summary=dict(external_flagged=len(keys),pairs_reviewed=len(checks),maximum_sift_inliers=max(t['sift_inliers'] for t in checks),
        candidates_with_8_or_more_inliers=[r for r in checks if r['sift_inliers']>=8],waterloo_excluding_all_flags=mean_scores(remaining))
    atomic_json(ROOT/'overlap_review.json',summary)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
