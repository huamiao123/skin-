# MambaVision-S + UPer64 外部测试（2026-11-19）

使用 ISIC2018 来源内部验证集选出的两个第 39 轮检查点。两套外部数据全部用于测试。未在外部图像上训练、选模型、调阈值或使用测试时增强。主指标为逐图前景 Dice 的算术平均。

| 外部数据 | 图像数 | UPer64 | UPer64 + Active Boundary Loss | 配对差值，百分点 | 差值的逐图自举 95% 区间，百分点 |
|---|---:|---:|---:|---:|---:|
| PH²，皮肤镜 | 200 | 93.1913% | 92.9146% | −0.2767 | [−0.4213, −0.1425] |
| Waterloo，临床摄影 | 206 | 87.9627% | 87.8610% | −0.1017 | [−0.4366, +0.2944] |

两组均使用固定 256×256 评估网格，RGB 双线性缩放，二值掩膜最近邻缩放，沿用原模型的 ImageNet 归一化、BF16 前向、FP32 sigmoid 和 0.5 阈值。在 64 张已有内部验证图上，经新入口复算的两个检查点逐图 TP、FP、FN 全部与原始记录一致。自举以图像为单位，重复 10,000 次，反映固定权重下的病例抽样差异。患者身份和跨种子的波动未纳入区间。

PH² 使用服务器已有的 2017 年镜像解包数据。200 张原图与 200 张病灶标注的文件字节哈希分别与已有的独立镜像清单逐一一致。Waterloo 原站所链接的两个 ZIP 重定向至实验室主页，本次从公共镜像新下载 32,011,839 字节的压缩包，通过全包 CRC 校验。提取 206 对原始 JPEG 和同尺寸的二值病灶标注。已记录每个文件、病例及权重的哈希。

[PH² 项目](https://www.fc.up.pt/addi/ph2%20database.html) · [PH² 归档镜像](https://www.kaggle.com/datasets/lakshyak/p2hdata) · [Waterloo 项目](https://vip.uwaterloo.ca/skin-cancer-detection/) · [Waterloo 下载镜像](https://www.kaggle.com/datasets/fatemehmehrparvar/skin-cancer-detection)

## 重复筛查

406 张外部测试图像与 1,886 张训练图、762 张内部验证图在 256×256 RGB 像素 SHA-256 上均无匹配；406 张外部图彼此也无完全相同的输入。对旋转和水平翻转进行低频感知哈希筛查，距离不超过 6 的外部样本有 34 张，均来自 Waterloo，涉及 200 对可疑图像配对。查看每张可疑图的配对缩略图，并对所有候选配对进行双向比率筛选的 SIFT 和几何检验，未发现足以确认同图的配对。此检查无法证明患者层面独立。作为敏感性分析，即使把这 34 张全部剔除，余下 172 张的逐图 Dice 仍为 UPer64 87.4513%、ABL 87.3610%，差值 −0.0903 个百分点。

## 可复核的记录

- [指标及权重身份](results.json)、[406 张的逐图混淆计数与 Dice](per_image.csv)
- [图像及标注路径、文件哈希、配对清单](manifest.csv)、[Waterloo 下载来源](data/waterloo_source.json)
- [外部测试入口](evaluate_external.py)、[下载脚本](fetch_waterloo.py)
- [重复筛查结果](overlap_review.json)、[所有低距离配对](near_pairs.csv)、[样例对照图](near_pair_review.jpg)
