from pathlib import Path
import hashlib,json,time,zipfile,requests
dst=Path(__file__).resolve().parent/'data'
for repo in ('fatemehmehrparvar/skin-cancer-detection','abtahimajeed/university-of-waterloo-skin-cancer-database'):
    url='https://api.kaggle.com/v1/datasets/download/'+repo
    try:
        tmp=dst/'waterloo.part'
        with requests.get(url,stream=True,timeout=(15,60)) as response:
            response.raise_for_status()
            with tmp.open('wb') as f:
                for chunk in response.iter_content(512*1024):
                    f.write(chunk)
        with zipfile.ZipFile(tmp) as archive:
            assert archive.testzip() is None
            members=[i for i in archive.namelist() if not i.endswith('/')]
            assert len(members)>=206
        target=dst/'waterloo.zip'
        tmp.replace(target)
        (dst/'waterloo_source.json').write_text(json.dumps(dict(mirror=repo,url=url,official='https://vip.uwaterloo.ca/skin-cancer-detection/',size=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=len(members)),indent=2))
        print(len(members),members[:16]);break
    except Exception as error:print(type(error).__name__,str(error)[:170],flush=True)
else:raise SystemExit(1)
