"""Compare best checkpoints against a fixed UPer64 reference on the same validation images."""
import argparse
import json
from pathlib import Path

import torch

from train_feature import ARMS, ROOT, atomic_json, build, reference, write_rows
from train import dice, interior_masks


def load_weights(model, path):
    state = torch.load(path, map_location="cpu")
    model.load_state_dict(state["model"], strict=True)
    return state["epoch"]


@torch.inference_mode()
def compare(arm, control_path, verify_native, candidate_path=None, candidate_builder=None):
    reference.setup()
    baseline = build("add").eval()
    control_epoch = load_weights(baseline, control_path)
    candidate = (candidate_builder or build)(arm).eval()
    candidate_path = candidate_path or ROOT / "runs" / arm / "best.pth"
    if verify_native:
        candidate.encoder.load_state_dict(baseline.encoder.state_dict(), strict=True)
        candidate.probe.decode_head.native.load_state_dict(baseline.probe.decode_head.state_dict(), strict=True)
        candidate_epoch = control_epoch
    else:
        candidate_epoch = load_weights(candidate, candidate_path)
    # A shared prefix cache is valid only if the two frozen prefixes are identical.
    def prefix_modules(model):
        backbone = model.encoder.model
        return (backbone.patch_embed, *backbone.levels[:2])
    for a, b in zip(prefix_modules(baseline), prefix_modules(candidate)):
        state_a, state_b = a.state_dict(), b.state_dict()
        assert state_a.keys() == state_b.keys()
        assert all(torch.equal(value, state_b[k]) for k, value in state_a.items())
    data, _ = reference.load_data()
    ids = data.ids["val"]
    cache = reference.cache_new(len(ids))
    reference.fill_cache(baseline, data, "val", cache)
    interior = interior_masks(cache["target"])
    rows = []
    max_diff = 0.
    for first in range(0, len(ids), 64):
        sl = slice(first, first + 64)
        features = [cache["features"][0][sl], cache["features"][1][sl], cache["mid"][sl]]
        with torch.autocast("cuda", dtype=torch.bfloat16):
            base_logits = baseline.from_cache(*features, (256, 256))["main"][:, 0].float()
            new_logits = candidate.from_cache(*features, (256, 256))["main"][:, 0].float()
        assert torch.isfinite(base_logits).all() and torch.isfinite(new_logits).all()
        max_diff = max(max_diff, float((base_logits - new_logits).abs().max()))
        prob = base_logits.sigmoid()
        base_mask = prob >= .5
        new_mask = new_logits.sigmoid() >= .5
        gt = cache["target"][sl, 0] >= .5
        hard = (prob < .1) & gt & interior[sl]
        bits = {"tp_ref": base_mask & gt, "fp_ref": base_mask & ~gt, "fn_ref": ~base_mask & gt,
                "tp_new": new_mask & gt, "fp_new": new_mask & ~gt, "fn_new": ~new_mask & gt,
                "high_conf_interior_fn_ref": hard, "high_conf_interior_fn_rescued": hard & new_mask,
                "correct_interior_fg_lost": interior[sl] & base_mask & ~new_mask,
                "previously_correct_bg_now_fp": ~gt & ~base_mask & new_mask}
        counts = torch.stack([mask.sum((1, 2)) for mask in bits.values()], dim=1).tolist()
        for i, values in enumerate(counts):
            r = dict(zip(bits, values))
            r.update(id=ids[first+i], dice_ref=dice(*values[:3]), dice_new=dice(*values[3:6]))
            rows.append(r)
    assert len(rows) == len({r["id"] for r in rows}) == 762
    folder = ROOT if verify_native else candidate_path.parent
    label = "identity_validation" if verify_native else "paired_diagnostic"
    result = dict(arm=arm, reference=str(control_path), candidate=None if verify_native else str(candidate_path),
                  reference_epoch=control_epoch, candidate_epoch=candidate_epoch, n_val=len(rows),
                  reference_dice=sum(r["dice_ref"] for r in rows)/len(rows),
                  candidate_dice=sum(r["dice_new"] for r in rows)/len(rows), max_abs_logit_diff=max_diff,
                  sums={k:sum(r[k] for r in rows) for k in list(bits)[6:]}, test_used=False)
    if verify_native:
        assert max_diff == 0.
    else:
        write_rows(folder/(label+".csv"), rows)
    atomic_json(folder/(label+".json"), result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("arm", choices=ARMS)
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--verify-native", action="store_true", help="use identical trained native weights and zero correction")
    parser.add_argument("--candidate-path", type=Path, help="checkpoint of a model built by the specified arm")
    args = parser.parse_args()
    if args.verify_native and (args.arm == "add" or args.candidate_path):
        parser.error("--verify-native needs a wrapped feature arm and no alternate checkpoint")
    compare(args.arm, args.reference.resolve(), args.verify_native, args.candidate_path)
