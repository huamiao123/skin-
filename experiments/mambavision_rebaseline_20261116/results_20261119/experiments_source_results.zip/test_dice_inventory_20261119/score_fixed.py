"""Fixed-weight test-only inventory for completed ISIC decoder runs."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import csv
import hashlib
import json
import sys
import numpy as np
from PIL import Image
import torch
HERE=Path(__file__).resolve().parent
PR=HERE.parent
NEW=PR/'uper64_feature_audit_20261119'
TRANSFER=NEW/'transfer_20261119'
OLD=PR/'method1_f3_20261118'
sys.path.insert(0,str(NEW))
from train_feature import reference,atomic_json,write_rows
from model import PROJECT
import feature_decoder as features
from decoder import build as anchor
sys.path.insert(0,str(TRANSFER))
import dysample_decoder as sampling
def read(p):return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    reference.setup()
    specs=[
        ('old_uper64',OLD/'uper64',anchor,'uper64','old_uper64'),
        ('logit_f3',OLD/'f3',anchor,'f3','old_uper64'),
        ('logit_f4',OLD/'f4',anchor,'f4','old_uper64'),
        ('uper64',NEW/'runs/add',features.build,'add','uper64'),
        ('gated_concat',NEW/'runs/gated_concat',features.build,'gated_concat','uper64'),
        ('f3_difference',NEW/'runs/f3_difference',features.build,'f3_difference','uper64'),
        ('dysample',TRANSFER/'dysample_f2_to_f1',sampling.build,sampling.ARMS[0],'uper64'),
        ('proportion_l1',TRANSFER/'proportion_l1',features.build,'add','uper64'),
        ('abl',TRANSFER/'abl_uper64',features.build,'add','uper64')]
    lock={}
    for name,run,_,__,control in specs:
        record=read(run/'complete.json')['best']
        history=read(run/'history.json');best=max(history,key=lambda r:r['val_macro_dice'])
        assert len(history)==100 and best['epoch']==record['epoch']
        lock[name]=dict(checkpoint=str(run/'best.pth'),sha256=sha(run/'best.pth'),epoch=record['epoch'],control=control)
    if (HERE/'locked.json').exists():assert lock==read(HERE/'locked.json')
    else:atomic_json(HERE/'locked.json',lock)
    part=read(PROJECT/'stage45_upernet_decoder/identity_partition.json')
    p=PROJECT.parent.parent;mfile=p/'local_audit_records/test_assets/test_manifest.json'
    assert sha(mfile)==part['audit_sha256']['test_manifest.json']
    manifest={r['id']:r for r in read(mfile)};ids=part['splits']['test']
    data=p/'heldout_data/test'
    def load(sid):
        paths=[data/k/(sid+'.png') for k in ('images','masks')]
        assert all(sha(q)==manifest[sid][key] for q,key in zip(paths,('image_256_sha256','mask_256_sha256')))
        with Image.open(paths[0]) as x,Image.open(paths[1]) as y:return np.array(x.convert('RGB')),np.array(y.convert('L'))>=128
    with ThreadPoolExecutor(8) as pool:rows=list(pool.map(load,ids))
    x=torch.from_numpy(np.stack([r[0] for r in rows])).permute(0,3,1,2).contiguous()
    gt=torch.from_numpy(np.stack([r[1] for r in rows]));del rows
    mean=torch.tensor([.485,.456,.406],device='cuda')[None,:,None,None]
    std=torch.tensor([.229,.224,.225],device='cuda')[None,:,None,None]
    scores={}
    for name,run,make,arm,_ in specs:
        net=make(arm).cuda().eval();ck=torch.load(run/'best.pth',map_location='cpu',weights_only=False)
        assert ck['epoch']==lock[name]['epoch'];net.load_state_dict(ck['model'],strict=True);del ck
        values=[]
        with torch.inference_mode():
            for rgb,true in zip(x.split(64),gt.split(64)):
                inp=(rgb.cuda().float()/255.-mean)/std;g=true.cuda()
                with torch.autocast('cuda',dtype=torch.bfloat16):z=net(inp)['main'].float()[:,0]
                assert torch.isfinite(z).all();pred=z.sigmoid()>=.5
                den=pred.sum((1,2))+g.sum((1,2));tp=(pred&g).sum((1,2))
                values.extend(torch.where(den>0,2*tp.double()/den,1.).cpu().tolist())
        scores[name]=np.asarray(values);del net;torch.cuda.empty_cache()
        print(name,float(scores[name].mean()),flush=True)
    prev=list(csv.DictReader(Path('/home/featurize/work/mambavision_seg_rebaseline_20261116/decoder_literature_20261119/sdi_formal_20261119/runs/test_per_image.csv').open()))
    assert len(ids)==867 and ids==[r['id'] for r in prev]
    assert np.max(abs(scores['uper64']-[float(r['add_42']) for r in prev]))<1e-12
    write_rows(HERE/'test_per_image.csv',[dict(id=sid,**{k:float(v[i]) for k,v in scores.items()}) for i,sid in enumerate(ids)])
    out={k:dict(test=float(v.mean()),control=lock[k]['control'],delta_pp=float((v-scores[lock[k]['control']]).mean()*100)) for k,v in scores.items()}
    atomic_json(HERE/'test_results.json',dict(n=867,threshold=.5,existing_control_per_image_replay=True,methods=out))
if __name__=='__main__':main()
