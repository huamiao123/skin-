"""Serialize registered frozen-feature readouts after C-noPPM fully completes."""
from pathlib import Path
import os,sys,json,time,subprocess,fcntl,datetime,traceback,hashlib
ROOT=Path(__file__).resolve().parents[1];REPORT=ROOT/'reports'
def status(phase,**kw):
 p=REPORT/'STAGEC_PROBES_STATUS.json';q=p.with_suffix('.json.tmp')
 q.write_text(json.dumps(dict(phase=phase,pipeline_pid=os.getpid(),at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),indent=2)+'\n');q.replace(p)
def child(name,args,log):
 cmd=[sys.executable,'-u',str(ROOT/'src'/name)]+args
 with (REPORT/log).open('w') as f:
  p=subprocess.Popen(cmd,cwd=ROOT,env=dict(os.environ,CUDA_VISIBLE_DEVICES='0'),stdout=f,stderr=subprocess.STDOUT)
  status('training' if name.startswith('train') else 'fixed_best_evaluation',child_pid=p.pid,command=cmd)
  rc=p.wait()
  if rc:raise RuntimeError(f'{name} exited {rc}; see {log}')
def main():
 with (REPORT/'STAGEC_PROBES.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  status('waiting_for_previous_train_and_test',previous_pipeline_pid=83745)
  while True:
   p=Path('/proc/83745/cmdline')
   if not p.exists() or b'run_stageC_noPPM.py' not in p.read_bytes():break
   time.sleep(5)
  previous=json.loads((ROOT/'evaluations/stageC_noPPM_20261117/SUMMARY.json').read_text())
  assert previous['complete'] and previous['test_n_per_model']==867,'predecessor did not complete all tests'
  proto=json.loads((REPORT/'STAGEC_PROBES_PROTOCOL.json').read_text())
  for name,expected in proto['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
  tests=json.loads((REPORT/'STAGEC_PROBES_CPU_TESTS.json').read_text());assert tests['passed'] and tests['six_views_image_mask_alignment_exact']
  assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip(),'GPU occupied'
  (REPORT/'CURRENT_EXPERIMENT.json').write_text(json.dumps(dict(stage='stageC_probes_20261117',heads=12,epochs=100,status=str(REPORT/'STAGEC_PROBES_STATUS.json'),user_reporting='Validation/test per-image macroDice and progress only',automatic_test_n_per_head=867),indent=2)+'\n')
  child('train_stageC_probes.py',['--stop-after-epoch','1'],'stageC_probes_first.log')
  out=ROOT/'results/stageC_probes_20261117';first=json.loads((out/'history.json').read_text());assert len(first)==1
  assert json.loads((out/'REAL_DATA_PREFLIGHT.json').read_text())['passed']
  child('train_stageC_probes.py',['--resume'],'stageC_probes_resume.log')
  history=json.loads((out/'history.json').read_text());assert len(history)==100 and history[0]==first[0]
  assert json.loads((out/'RESUME_LOAD_AUDIT.json').read_text())['passed']
  child('evaluate_stageC_probes.py',[],'stageC_probes_evaluate.log')
  summary=json.loads((ROOT/'evaluations/stageC_probes_20261117/SUMMARY.json').read_text())
  assert summary['complete'] and summary['test_n_per_model']==867 and len(summary['models'])==12
  status('complete',epochs=100,heads=12,test_n_per_head=867,diagnostic_only=True)
if __name__=='__main__':
 try:main()
 except Exception:
  status('failed',traceback=traceback.format_exc());(REPORT/'STAGEC_PROBES_PIPELINE_FAILURE.json').write_text(json.dumps(dict(traceback=traceback.format_exc()),indent=2)+'\n');raise
