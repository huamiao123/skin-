"""Fixed-best evaluation of matched remaining Stage-B controls."""
from pathlib import Path
import argparse,json,csv,hashlib,gc,concurrent.futures
import numpy as np
import torch
from PIL import Image
from model import PROJECT,load_pretrained_encoder
from remaining_stageB import build_system,VARIANTS
from train_mb64 import reference,base,atomic_json
from evaluate_stageA import profile,stratify,bootstrap,csvout
from evaluation import summarize_rows
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evaluations/stageB_remaining_20261117'
R=PROJECT.parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 global OUT
 ap=argparse.ArgumentParser();ap.add_argument('--arm',choices=tuple(VARIANTS),required=True);args=ap.parse_args()
 OUT=OUT/args.arm
 folder=ROOT/'results/stageB_remaining_20261117'/args.arm
 h=json.loads((folder/'history.json').read_text());assert len(h)==100
 assert json.loads((folder/'status.json').read_text())['state']=='complete'
 best=max(h,key=lambda row:row['validation']['macro']['dice'])
 cp=folder/'best_dice.pth'
 rec=dict(arm=args.arm,checkpoint=str(cp),sha256=sha(cp),selected_epoch=best['epoch'],validation_original=best['validation'],training_gpu=json.loads((folder/'config.json').read_text())['device'])
 partition=PROJECT/'stage45_upernet_decoder/identity_partition.json';part=json.loads(partition.read_text())
 manifest_path=R/'local_audit_records/test_assets/test_manifest.json'
 assert sha(manifest_path)==part['audit_sha256']['test_manifest.json']
 manifest={r['id']:r for r in json.loads(manifest_path.read_text())}
 OUT.mkdir(parents=True,exist_ok=True)
 prereg=dict(records=[rec],selection='max validation macroDice earliest tie; fixed before test inference',threshold=.5,input_size=256,physical_eval_batch=64,partition_sha256=sha(partition),test_manifest_sha256=sha(manifest_path),test_n=867,test_previously_exposed=True,patient_disjointness_verified=False,test_used_for_selection=False)
 atomic_json(OUT/'FIXED_EVALUATION_PROTOCOL.json',prereg)
 for sid in part['splits']['test']:
  for sub,key in [('images','image_256_sha256'),('masks','mask_256_sha256')]:
   assert sha(R/'heldout_data/test'/sub/(sid+'.png'))==manifest[sid][key],sid
 atomic_json(OUT/'TEST_INPUT_VERIFIED.json',dict(passed=True,n=867))
 reference.setup();torch.set_num_threads(8)
 data,_=reference.load_data();vc=reference.cache_new(762)
 y=data.masks['val'][:,0].cpu().numpy()>=127.5;cuts=np.quantile(y.sum((1,2)),[.25,.5,.75])
 atomic_json(OUT/'AREA_CUTS.json',dict(validation_area_quartiles_px=cuts.tolist()))
 state=torch.load(cp,map_location='cpu',weights_only=False);assert state['epoch']==best['epoch']
 model=build_system(load_pretrained_encoder(),args.arm,42).cuda();model.load_state_dict(state['model'],strict=True);del state
 model.requires_grad_(False).eval();reference.fill_cache(model,data,'val',vc)
 probs=[]
 with torch.no_grad():
  for start in range(0,762,64):
   end=min(start+64,762)
   with torch.autocast('cuda',dtype=torch.bfloat16):out=model.from_cache(vc['features'][0][start:end],vc['features'][1][start:end],vc['mid'][start:end],(256,256))['main']
   probs.append(out.float().sigmoid()[:,0].cpu().numpy())
 prob=np.concatenate(probs);dest=OUT/args.arm;dest.mkdir(exist_ok=True)
 np.save(dest/'validation_probabilities_fp32.npy',prob)
 with concurrent.futures.ThreadPoolExecutor(8) as pool:valrows=list(pool.map(profile,zip(part['splits']['val'],prob,y)))
 val=summarize_rows(valrows);csvout(dest/'validation_per_image.csv',valrows)
 assert abs(val['macro']['dice']-best['validation']['macro']['dice'])<1e-5
 sweep=[]
 for t in np.arange(.2,.801,.05):
  pred=prob>=t;tp=(pred&y).sum((1,2));fp=(pred&~y).sum((1,2));fn=(~pred&y).sum((1,2));den=2*tp+fp+fn
  score=np.divide(2*tp,den,out=np.ones(762),where=den>0)
  sweep.append(dict(threshold=float(round(t,2)),macro_dice=float(score.mean()),FP=int(fp.sum()),FN=int(fn.sum())))
 atomic_json(dest/'VALIDATION_THRESHOLD_SWEEP.json',dict(validation_only=True,candidates=sweep,best=max(sweep,key=lambda v:v['macro_dice']),test_calibrated=False))
 testrows=[]
 with torch.no_grad(),concurrent.futures.ThreadPoolExecutor(8) as pool:
  for start in range(0,867,64):
   ids=part['splits']['test'][start:start+64]
   x=np.stack([np.asarray(Image.open(R/'heldout_data/test/images'/(sid+'.png')).convert('RGB')) for sid in ids])
   yy=np.stack([np.asarray(Image.open(R/'heldout_data/test/masks'/(sid+'.png')).convert('L'))>=127.5 for sid in ids])
   im=torch.from_numpy(x).permute(0,3,1,2).contiguous().cuda().float()/255.
   with torch.autocast('cuda',dtype=torch.bfloat16):out=model((im-data.mean)/data.std)['main']
   pp=out.float().sigmoid()[:,0].cpu().numpy();testrows.extend(pool.map(profile,zip(ids,pp,yy)))
 test=summarize_rows(testrows);csvout(dest/'test_per_image.csv',testrows)
 summary=dict(arm=args.arm,checkpoint=rec,validation=val,test=test,validation_area_groups=stratify(valrows,cuts),test_area_groups_using_validation_cuts=stratify(testrows,cuts),complete=True,threshold=.5,test_used_for_selection=False,patient_disjointness_verified=False)
 atomic_json(dest/'METRICS.json',summary)
 reference_path=ROOT/'evaluations/stageB_color_20261117/control/METRICS.json'
 parent=json.loads(reference_path.read_text())
 with (reference_path.parent/'validation_per_image.csv').open() as f:parent_rows=list(csv.DictReader(f))
 assert [r['id'] for r in parent_rows]==[r['id'] for r in valrows]
 paired=bootstrap([float(r['dice']) for r in parent_rows],[r['dice'] for r in valrows])
 decision=dict(validation_only=True,test_used=False,reference_arm='control',macro_dice_gain_pp=100*(val['macro']['dice']-parent['validation']['macro']['dice']),boundary_F1_delta=val['macro']['boundary_f1']-parent['validation']['macro']['boundary_f1'],passed=bool(val['macro']['dice']-parent['validation']['macro']['dice']>=.001 and val['macro']['boundary_f1']>=parent['validation']['macro']['boundary_f1']),seed=42,limitation='Single-seed matched one-factor training control; not statistical proof or a new module.')
 atomic_json(OUT/'SUMMARY.json',dict(complete=True,models={'control':parent,args.arm:summary},validation_paired_comparisons={args.arm+'_vs_control':paired},test_n_per_model=867,validation_n=762,seed=42,test_exposed=True,reused_reference_metrics_sha256=sha(reference_path)))
 atomic_json(ROOT/'reports'/('STAGEB_REMAINING_'+args.arm+'_DECISION.json'),decision)
 assert sha(cp)==rec['sha256']
 print(json.dumps(dict(complete=True,validation_macro_dice=val['macro']['dice'],test_macro_dice=test['macro']['dice'],decision=decision)),flush=True)
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback;OUT.mkdir(parents=True,exist_ok=True);atomic_json(OUT/'FAILURE.json',dict(traceback=traceback.format_exc()));raise
