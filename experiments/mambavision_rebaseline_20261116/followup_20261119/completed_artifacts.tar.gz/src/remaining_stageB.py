"""Remaining matched Stage-B one-factor controls under unchanged UPer64."""
import torch
from model import SegmentationSystem
VARIANTS={
 'stage4_only':dict(tune='stage4',weight_decay=.01,change='Only encoder stage4 trainable instead of stages3+4'),
 'encoder_frozen':dict(tune='frozen',weight_decay=.01,change='Freeze all encoder parameters; train identical UPer64 head'),
 'wd005':dict(tune='late',weight_decay=.05,change='Only weight_decay0.01 to0.05; original stages3+4 trainable')}
def build_system(encoder,arm,seed=42):
 spec=VARIANTS[arm];model=SegmentationSystem(encoder,'A-64-noaux',seed)
 if spec['tune']=='stage4':model.encoder.model.levels[2].requires_grad_(False)
 elif spec['tune']=='frozen':model.encoder.requires_grad_(False)
 model.train()
 return model
def make_optimizer(model,arm):
 spec=VARIANTS[arm]
 groups=[dict(params=list(model.probe.parameters()),lr=1e-3,initial_lr=1e-3,name='decoder')]
 encoder=[p for p in model.encoder.parameters() if p.requires_grad]
 if encoder:groups.append(dict(params=encoder,lr=1e-4,initial_lr=1e-4,name='encoder'))
 return torch.optim.AdamW(groups,weight_decay=spec['weight_decay'],betas=(.9,.999),eps=1e-8)
