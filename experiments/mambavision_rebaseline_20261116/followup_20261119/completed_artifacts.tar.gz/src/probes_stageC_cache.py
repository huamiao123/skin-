"""Frozen C-baseline features, with paired image transforms before encoding."""
from pathlib import Path
import csv,json,hashlib,gc
import torch
from model import SegmentationSystem,load_pretrained_encoder,PROJECT
from train_mb64 import reference,base,atomic_json
from probes_stageC_core import CHANNELS,VIEW_NAMES,apply_view,image_scores
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'results/formal_mb64/C-512-aux/best_dice.pth'
SOURCE_SHA='4b1f7416cc2948516d362eab6f4524f38e979f1259f90a730bbd2c55f2fdc907'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
@torch.no_grad()
def encode(model,images):
 with torch.autocast('cuda',dtype=torch.bfloat16):
  f1,f2,mid=model.prefix(images);f3,f4=model.suffix(mid)
 return f1,f2,f3,f4
@torch.no_grad()
def cache_split(model,data,split,views,dest):
 n=len(data.ids[split]);sizes=(64,32,16,8)
 shape=lambda c,s:(views,n,c,s,s) if views>1 else (n,c,s,s)
 features=[torch.empty(shape(c,s),device='cuda',dtype=torch.float32) for c,s in zip(CHANNELS,sizes)]
 target=torch.empty((views,n,1,256,256) if views>1 else (n,1,256,256),device='cuda')
 audits=[]
 for view in range(views):
  for start in range(0,n,64):
   end=min(start+64,n);ix=torch.arange(start,end,device='cuda')
   images,y=data.batch(split,ix)
   images=apply_view(images,view);y=apply_view(y,view)
   encoded=encode(model,images)
   for level,(x,c,s) in enumerate(zip(encoded,CHANNELS,sizes)):
    assert x.shape==(end-start,c,s,s) and x.dtype==torch.bfloat16
    dest_tensor=features[level][view,start:end] if views>1 else features[level][start:end]
    dest_tensor.copy_(x)
   (target[view,start:end] if views>1 else target[start:end]).copy_(y)
   if start==0:
    repeated=encode(model,images)
    assert all(torch.equal(a,b) for a,b in zip(encoded,repeated)),'frozen feature replay differs'
    audits.append(dict(view=VIEW_NAMES[view],first_batch_repeat_exact=True,labels_in_unit_interval=bool(y.min()>=0 and y.max()<=1)))
  atomic_json(dest/'CACHE_STATUS.json',dict(split=split,completed_views=view+1,total_views=views,n=n))
 return dict(ids=list(data.ids[split]),features=features,target=target,views=views,audit=audits)
@torch.no_grad()
def source_replay(model,cache):
 dice=[];counts=dict(tp=0,fp=0,fn=0,tn=0)
 for start in range(0,len(cache['ids']),64):
  end=min(start+64,len(cache['ids']))
  features=[x[start:end].to(torch.bfloat16) for x in cache['features']]
  with torch.autocast('cuda',dtype=torch.bfloat16):out=model.probe(features,(256,256))['main']
  scores=image_scores(out,cache['target'][start:end]);dice.append(scores['dice'])
  for k in counts:counts[k]+=int(scores[k].sum())
 return dict(macro_dice=float(torch.cat(dice).mean()),counts=counts)
def prepare_cache(dest,training):
 dest.mkdir(parents=True,exist_ok=True)
 reference.setup();torch.use_deterministic_algorithms(True,warn_only=True)
 torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 assert sha(SOURCE)==SOURCE_SHA
 state=torch.load(SOURCE,map_location='cpu',weights_only=False);assert state['epoch']==39
 data,part=reference.load_data()
 model=SegmentationSystem(load_pretrained_encoder(),'C-512-aux',42).cuda()
 model.load_state_dict(state['model'],strict=True);model.requires_grad_(False).eval()
 assert not any(p.requires_grad for p in model.parameters())
 val=cache_split(model,data,'val',1,dest)
 with (ROOT/'evaluations/stageA_20261117/C-512-aux/validation_per_image.csv').open() as f:oldrows=list(csv.DictReader(f))
 assert [r['id'] for r in oldrows]==val['ids']
 assert torch.equal((val['target'][:,0]>=.5).sum((1,2)).cpu(),torch.tensor([int(r['GT_area_px']) for r in oldrows]))
 replay=source_replay(model,val);old=state['validation']
 replay.update(expected_macro_dice=old['macro']['dice'],macro_dice_delta=replay['macro_dice']-old['macro']['dice'],counts_exact=replay['counts']==old['counts'])
 assert abs(replay['macro_dice_delta'])<1e-5,'unexpected C baseline replay drift'
 atomic_json(dest/'SOURCE_BASELINE_REPLAY.json',replay)
 gc.collect();torch.cuda.empty_cache()
 caches={'val':val}
 if training:
  estimated=(6*1886+762)*(sum(c*s*s for c,s in zip(CHANNELS,(64,32,16,8)))+256*256)*4
  assert torch.cuda.get_device_properties(0).total_memory>46*1024**3,'six-view cache protocol requires48GiB GPU'
  free,total=torch.cuda.mem_get_info()
  assert free>estimated-762*(sum(c*s*s for c,s in zip(CHANNELS,(64,32,16,8)))+256*256)*4+3*1024**3,'insufficient free GPU memory for registered cache'
  caches['train']=cache_split(model,data,'train',6,dest)
 base.assert_tree_exact(model.state_dict(),state['model'])
 assert all(p.grad is None for p in model.parameters())
 atomic_json(dest/'FROZEN_FEATURE_AUDIT.json',dict(passed=True,source_checkpoint_sha256=SOURCE_SHA,source_epoch=39,source_model_state_unchanged=True,source_all_parameters_frozen=True,source_all_gradients_none=True,cache_dtype='float32 exact conversion of BF16 encoder outputs',head_precision='FP32;TF32 disabled',training_views=list(VIEW_NAMES) if training else [],validation_views=['identity'],training_random_view_per_image_per_epoch=training,soft_labels_preserved=True,features_reencoded_from_transformed_images=True,caches={k:dict(n=len(v['ids']),views=v['views'],feature_shapes=[list(x.shape) for x in v['features']],audit=v['audit']) for k,v in caches.items()}))
 del state;gc.collect();torch.cuda.empty_cache()
 return model,data,part,caches
