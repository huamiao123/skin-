from pathlib import Path
import json,csv
import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt as edt,label,binary_fill_holes
W=Path(__file__).resolve().parents[1]
P=Path('/home/waas/mambavision_stage22/source/referring_image_segmentation')
D=W/'diagnostics/stageC_20261117'
result={}
for name in ['control','C512aux']:
 d=D/'sensitivity'/name
 with (d/'intact_per_image.csv').open() as f:rows=list(csv.DictReader(f))
 prob=np.load(d/'intact_validation_probabilities_fp32.npy',mmap_mode='r')
 counts=dict(FN=0,FP=0,FN_deep8_original=0,FN_deep8_padded=0,FN_probability_lt01=0,FP_probability_gt09=0,deep_FN_probability_lt01=0,far_FP=0,far_FP_probability_gt09=0,frame_contact_cases=0)
 topology=[];base=[];lcc=[];filled=[]
 for i,r in enumerate(rows):
  gt=np.asarray(Image.open(P/'data/isic2018/val/masks'/(r['id']+'.png')).convert('L').resize((256,256),Image.Resampling.NEAREST))>=127.5
  p=prob[i];pred=p>=.5
  assert int(gt.sum())==int(r['GT_area_px'])
  fn=gt&~pred;fp=pred&~gt
  assert int(fn.sum())==int(r['fn']) and int(fp.sum())==int(r['fp'])
  dist=edt(gt);dp=edt(np.pad(gt,1))[1:-1,1:-1];bd=edt(~gt)
  deep=fn&(dist>8);far=fp&(bd>8)
  counts['FN']+=int(fn.sum());counts['FP']+=int(fp.sum())
  counts['FN_deep8_original']+=int(deep.sum());counts['FN_deep8_padded']+=int((fn&(dp>8)).sum())
  counts['FN_probability_lt01']+=int((fn&(p<.1)).sum());counts['FP_probability_gt09']+=int((fp&(p>.9)).sum())
  counts['deep_FN_probability_lt01']+=int((deep&(p<.1)).sum())
  counts['far_FP']+=int(far.sum());counts['far_FP_probability_gt09']+=int((far&(p>.9)).sum())
  contact=bool(gt[0].any() or gt[-1].any() or gt[:,0].any() or gt[:,-1].any());counts['frame_contact_cases']+=int(contact)
  def dice(a):
   tp=int((a&gt).sum());return 2*tp/max(1,int(a.sum()+gt.sum()))
  base.append(dice(pred));lab,n=label(pred,np.ones((3,3)))
  if n:
   sizes=np.bincount(lab.ravel());sizes[0]=0;lccpred=lab==sizes.argmax()
  else:lccpred=pred
  lcc.append(dice(lccpred));filled.append(dice(binary_fill_holes(pred)))
  holes=int((binary_fill_holes(gt)&~gt).sum())
  topology.append(dict(id=r['id'],hole_area_px=holes,hole_to_GT_area_ratio=holes/max(int(gt.sum()),1),GT_components=int(label(gt,np.ones((3,3)))[1]),GT_frame_contact=contact,dice=float(r['dice'])))
 result[name]=dict(counts=counts,FN_confident_background_fraction=counts['FN_probability_lt01']/max(counts['FN'],1),FP_confident_foreground_fraction=counts['FP_probability_gt09']/max(counts['FP'],1),deep_FN_confident_background_fraction=counts['deep_FN_probability_lt01']/max(counts['FN_deep8_original'],1),far_FP_confident_foreground_fraction=counts['far_FP_probability_gt09']/max(counts['far_FP'],1),baseline_macro_dice=float(np.mean(base)),largest_component_macro_dice=float(np.mean(lcc)),fill_holes_macro_dice=float(np.mean(filled)),top_GT_hole_cases=sorted(topology,key=lambda r:-r['hole_to_GT_area_ratio'])[:20],GT_hole_ratio_gt_quarter=sum(r['hole_to_GT_area_ratio']>.25 for r in topology),postprocessing_adopted=False)
(D/'CONFIDENCE_GEOMETRY.json').write_text(json.dumps(dict(complete=True,validation_only=True,test_read=False,models=result,note='Original and zero-padded GT distance are separate conventions; old scores unchanged. Topology flags do not establish incorrect labels, and no cases are excluded. Postprocessing is exploratory and not adopted.'),indent=2)+'\n')
print(json.dumps(result),flush=True)
