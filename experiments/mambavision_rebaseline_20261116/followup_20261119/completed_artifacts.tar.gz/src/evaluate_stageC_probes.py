"""Validation-selected frozen feature probes, then fixed867-image test."""
from pathlib import Path
import json,csv,gc,concurrent.futures
import numpy as np
import torch
from PIL import Image
from probes_stageC_core import make_heads,SPECS,CHANNELS
from probes_stageC_cache import prepare_cache,encode,ROOT,SOURCE,SOURCE_SHA,sha,PROJECT
from train_mb64 import atomic_json
from evaluate_stageA import profile,stratify,bootstrap,csvout
from evaluation import summarize_rows
RUN=ROOT/'results/stageC_probes_20261117';OUT=ROOT/'evaluations/stageC_probes_20261117'
R=PROJECT.parent.parent
def profile_extra(args):
 sid,prob,gt=args;r=profile(args);pred=prob>=.5
 r['FN_probability_lt01']=int((gt&~pred&(prob<.1)).sum())
 r['FP_probability_gt09']=int((~gt&pred&(prob>.9)).sum())
 return r
def main():
 history=json.loads((RUN/'history.json').read_text());assert len(history)==100
 assert json.loads((RUN/'status.json').read_text())['state']=='complete'
 OUT.mkdir(parents=True,exist_ok=True)
 records={}
 for s in SPECS:
  k=s['key'];best=max(history,key=lambda r:r['validation'][k]['macro_dice']);cp=RUN/'heads'/(k+'_best.pth')
  records[k]=dict(key=k,feature_level=s['level']+1,family=s['family'],checkpoint=str(cp),sha256=sha(cp),selected_epoch=best['epoch'],validation_original=best['validation'][k])
 partition=PROJECT/'stage45_upernet_decoder/identity_partition.json';part=json.loads(partition.read_text())
 manifest_path=R/'local_audit_records/test_assets/test_manifest.json'
 assert sha(manifest_path)==part['audit_sha256']['test_manifest.json']
 manifest={v['id']:v for v in json.loads(manifest_path.read_text())}
 atomic_json(OUT/'FIXED_EVALUATION_PROTOCOL.json',dict(records=records,source_encoder_sha256=SOURCE_SHA,threshold=.5,input_size=256,batch=64,selection='Maximum validation macroDice per readout, earliest tie; no best-head selection using test',diagnostic_only=True,test_previously_exposed=True,patient_disjointness_verified=False,partition_sha256=sha(partition),test_manifest_sha256=sha(manifest_path),test_n_per_head=867))
 for sid in part['splits']['test']:
  for sub,key in [('images','image_256_sha256'),('masks','mask_256_sha256')]:assert sha(R/'heldout_data/test'/sub/(sid+'.png'))==manifest[sid][key]
 atomic_json(OUT/'TEST_INPUT_VERIFIED.json',dict(passed=True,n=867,all_image_mask_sha256_match=True))
 model,data,part,caches=prepare_cache(OUT,False)
 heads=make_heads(42).cuda().eval()
 for s in SPECS:
  k=s['key'];state=torch.load(records[k]['checkpoint'],map_location='cpu',weights_only=False)
  assert state['epoch']==records[k]['selected_epoch']
  heads[k].load_state_dict(state['head'],strict=True)
  records[k]['parameter_count']=state['config']['parameter_counts'][k]
 heads.requires_grad_(False)
 vr={s['key']:[] for s in SPECS};tr={s['key']:[] for s in SPECS}
 vb={s['key']:[] for s in SPECS};tb={s['key']:[] for s in SPECS}
 val=caches['val'];cuts=np.quantile((val['target'][:,0]>=.5).sum((1,2)).cpu().numpy(),[.25,.5,.75])
 atomic_json(OUT/'AREA_CUTS.json',dict(validation_area_quartiles_px=cuts.tolist(),fixed_for_all_heads=True))
 with torch.no_grad(),concurrent.futures.ThreadPoolExecutor(8) as pool:
  for split,n in [('validation',762),('test',867)]:
   ids=part['splits']['val' if split=='validation' else 'test']
   for begin in range(0,n,64):
    end=min(begin+64,n);group=ids[begin:end]
    if split=='validation':
     features=[v[begin:end] for v in val['features']]
     y=(val['target'][begin:end,0]>=.5).cpu().numpy()
    else:
     x=np.stack([np.asarray(Image.open(R/'heldout_data/test/images'/(sid+'.png')).convert('RGB')) for sid in group])
     y=np.stack([np.asarray(Image.open(R/'heldout_data/test/masks'/(sid+'.png')).convert('L'))>=127.5 for sid in group])
     images=torch.from_numpy(x).permute(0,3,1,2).contiguous().cuda().float()/255.
     features=[v.float() for v in encode(model,(images-data.mean)/data.std)]
    for s in SPECS:
     k=s['key'];prob=heads[k](features[s['level']],(256,256)).sigmoid()[:,0].cpu().numpy()
     (vr if split=='validation' else tr)[k].extend(pool.map(profile_extra,zip(group,prob,y)))
     (vb if split=='validation' else tb)[k].append(np.packbits((prob>=.5).reshape(len(group),-1),axis=1))
    print(json.dumps(dict(split=split,processed=end,total=n,heads=12)),flush=True)
 models={};comparisons={}
 parent_path=ROOT/'evaluations/stageA_20261117/C-512-aux'
 with (parent_path/'validation_per_image.csv').open() as f:parentrows=list(csv.DictReader(f))
 for s in SPECS:
  k=s['key'];dest=OUT/k;dest.mkdir(exist_ok=True)
  v=summarize_rows(vr[k]);t=summarize_rows(tr[k])
  assert [r['id'] for r in vr[k]]==[r['id'] for r in parentrows]
  delta=v['macro']['dice']-records[k]['validation_original']['macro_dice']
  assert abs(delta)<1e-5,(k,delta)
  summary=dict(key=k,checkpoint=records[k],validation=v,test=t,validation_area_groups=stratify(vr[k],cuts),test_area_groups_using_validation_cuts=stratify(tr[k],cuts),threshold=.5,diagnostic_only=True,complete=True,source_encoder_sha256=SOURCE_SHA,validation_replay_dice_delta=delta,validation_counts_exact=(v['counts']==records[k]['validation_original']['counts']),test_used_for_selection=False,patient_disjointness_verified=False)
  csvout(dest/'validation_per_image.csv',vr[k]);csvout(dest/'test_per_image.csv',tr[k]);atomic_json(dest/'METRICS.json',summary)
  for split,rows,bits in [('validation',vr[k],vb[k]),('test',tr[k],tb[k])]:
   np.savez_compressed(dest/(split+'_predictions.npz'),ids=np.array([r['id'] for r in rows]),packed_bits=np.concatenate(bits),height=256,width=256,threshold=.5)
  comparisons[k]=bootstrap([float(r['dice']) for r in parentrows],[r['dice'] for r in vr[k]])
  models[k]=summary
  assert sha(Path(records[k]['checkpoint']))==records[k]['sha256']
  print(json.dumps(dict(key=k,best_epoch=records[k]['selected_epoch'],validation_macro_dice=v['macro']['dice'],test_macro_dice=t['macro']['dice'])),flush=True)
 assert sha(SOURCE)==SOURCE_SHA
 atomic_json(OUT/'SUMMARY.json',dict(complete=True,diagnostic_only=True,models=models,validation_paired_comparisons_vs_C=comparisons,source_encoder_sha256=SOURCE_SHA,validation_n=762,test_n_per_model=867,seed=42,test_exposed=True,interpretation='Readout performance measures what these restricted heads can access. Low scores do not establish absent encoder information. The heads use a distinct frozen-encoder training protocol and are not new segmentation methods.'))
 lines=['Frozen-feature diagnostic readouts; all scores are per-image macroDice.','Key / best epoch / validationDice% / testDice% / trained parameters']
 for k,m in models.items():lines.append(f"{k} / {m['checkpoint']['selected_epoch']} / {100*m['validation']['macro']['dice']:.4f} / {100*m['test']['macro']['dice']:.4f} / {m['checkpoint']['parameter_count']}")
 lines+=['','Encoder fixed to originalC best39. Each head selected on validation only. Single seed42; six finite paired training views. Linear32 and nonlinear32 share initialization and parameter budget within each layer. Direct1x1 heads are smaller. No claim that low readout accuracy proves missing information. Labels, splits and original results unchanged.']
 (OUT/'REPORT.txt').write_text('\n'.join(lines)+'\n')
 print('ALL_PROBES_EVALUATED_867_TEST_IMAGES',flush=True)
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback;OUT.mkdir(parents=True,exist_ok=True);atomic_json(OUT/'FAILURE.json',dict(traceback=traceback.format_exc()));raise
