"""100-epoch frozen-feature diagnostic readouts; each head optimized independently."""
from pathlib import Path
import argparse,json,math,hashlib,time,gc
import torch
from probes_stageC_core import make_heads,make_optimizer,step_heads,validate,SPECS,CHANNELS
from probes_stageC_cache import prepare_cache,SOURCE,SOURCE_SHA,ROOT,sha
from train_mb64 import base,atomic_json,atomic_save,rng_state,restore_rng
OUT=ROOT/'results/stageC_probes_20261117'
def prereg_check():
 protocol=json.loads((ROOT/'reports/STAGEC_PROBES_PROTOCOL.json').read_text())
 for p,expected in protocol['source_sha256'].items():assert sha(ROOT/p)==expected,p
 tests=json.loads((ROOT/'reports/STAGEC_PROBES_CPU_TESTS.json').read_text())
 assert tests['passed'] and tests['six_views_image_mask_alignment_exact']
 return protocol
def preflight(heads,opt,cache):
 ix=torch.arange(64,device='cuda')
 features=[t[0,ix] for t in cache['features']];target=cache['target'][0,ix]
 assert not any(t.requires_grad for t in features)
 snap=dict(heads=base.cpu_tree(heads.state_dict()),optimizer=base.cpu_tree(opt.state_dict()),rng=rng_state())
 first,norms=step_heads(heads,opt,features,target);expected=base.cpu_tree(heads.state_dict())
 assert all(v>0 and math.isfinite(v) for v in norms.values())
 heads.load_state_dict(snap['heads']);opt.load_state_dict(snap['optimizer']);restore_rng(snap['rng'])
 second,_=step_heads(heads,opt,features,target)
 d2=u2=max_abs=0.
 for k,v in heads.state_dict().items():
  a=v.detach().cpu();e=expected[k];delta=(a-e).double();update=(e-snap['heads'][k]).double()
  d2+=float(delta.square().sum());u2+=float(update.square().sum());max_abs=max(max_abs,float(delta.abs().max()))
 rel=(d2/max(u2,1e-30))**.5;lossdelta=float((first-second).abs().max())
 heads.load_state_dict(snap['heads']);opt.load_state_dict(snap['optimizer']);restore_rng(snap['rng'])
 base.assert_tree_exact(heads.state_dict(),snap['heads']);base.assert_tree_exact(opt.state_dict(),snap['optimizer']);base.assert_tree_exact(rng_state(),snap['rng'])
 assert lossdelta<1e-5 and rel<.01 and max_abs<.0021,(lossdelta,rel,max_abs)
 atomic_json(OUT/'REAL_DATA_PREFLIGHT.json',dict(passed=True,n=64,physical_batch=64,heads=12,source_encoder_frozen=True,cache_features_require_grad=False,all_heads_gradient_norm_positive_finite=True,loss_replay_max_abs=lossdelta,replay_relative_update_l2=rel,replay_max_parameter_abs=max_abs,registered_relative_limit=.01,registered_absolute_limit=.0021,updates_rolled_back=2,state_restored_exactly=True,peak_allocated_bytes=torch.cuda.max_memory_allocated(),joint_optimizer_groups_are_disjoint=True))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--resume',action='store_true');ap.add_argument('--stop-after-epoch',type=int,choices=range(1,101));args=ap.parse_args()
 protocol=prereg_check()
 if OUT.exists() and (OUT/'latest.pth').exists() and not args.resume:raise FileExistsError('probe bundle already exists')
 OUT.mkdir(parents=True,exist_ok=True);(OUT/'heads').mkdir(exist_ok=True)
 model,data,part,caches=prepare_cache(OUT,True)
 assert not any(p.requires_grad for p in model.parameters())
 model.cpu();del model,data;gc.collect();torch.cuda.empty_cache()
 heads=make_heads(42).cuda();opt=make_optimizer(heads)
 config=dict(seed=42,epochs=100,physical_batch=64,input_size=256,source_checkpoint_sha256=SOURCE_SHA,source_checkpoint_epoch=39,protocol_sha256=sha(ROOT/'reports/STAGEC_PROBES_PROTOCOL.json'),head_specs=SPECS,parameter_counts={k:sum(p.numel() for p in h.parameters()) for k,h in heads.items()},optimizer='AdamW',lr=1e-3,weight_decay=.01,clip_each_head=1.,scheduler='cosine100_floor0.01',cache_dtype='FP32_exact_conversion_from_BF16_encoder',head_precision='FP32_TF32_disabled',augmentation='one_of_six_registered_views_per_image_per_epoch;features_reencoded_before_caching',selection='validation_macro_dice_earliest_tie_per_head',threshold=.5,diagnostic_only=True,no_training_encoder_updates=True,device=torch.cuda.get_device_name(0))
 if args.resume:assert json.loads((OUT/'config.json').read_text())==config
 else:atomic_json(OUT/'config.json',config)
 history=[];start=1;best={s['key']:-1. for s in SPECS}
 if args.resume:
  state=torch.load(OUT/'latest.pth',map_location='cpu',weights_only=False);assert state['config']==config
  heads.load_state_dict(state['heads'],strict=True);opt.load_state_dict(state['optimizer']);restore_rng(state['rng'])
  base.assert_tree_exact(heads.state_dict(),state['heads']);base.assert_tree_exact(opt.state_dict(),state['optimizer']);base.assert_tree_exact(rng_state(),state['rng'])
  history=state['history'];best=state['best'];start=state['epoch']+1
  assert start<=100
  atomic_json(OUT/'RESUME_LOAD_AUDIT.json',dict(passed=True,checkpoint_epoch=state['epoch'],heads_optimizer_rng_exact=True,encoder_rebuilt_from_fixed_reference=True))
  del state
 started=time.perf_counter();torch.cuda.reset_peak_memory_stats()
 if not args.resume:preflight(heads,opt,caches['train'])
 n=len(caches['train']['ids']);heads.train()
 for epoch in range(start,101):
  tick=time.perf_counter();g=torch.Generator().manual_seed(42+epoch*100003)
  order=torch.randperm(n,generator=g).cuda();views=torch.randint(6,(n,),generator=g).cuda()
  totals=torch.zeros(len(SPECS),device='cuda');seen=0
  factor=.01+.99*(1+math.cos(math.pi*(epoch-1)/100))/2
  for group in opt.param_groups:group['lr']=group['initial_lr']*factor
  for begin in range(0,n,64):
   ix=order[begin:begin+64];v=views[ix]
   features=[x[v,ix] for x in caches['train']['features']];target=caches['train']['target'][v,ix]
   values,_=step_heads(heads,opt,features,target);totals+=values*len(ix);seen+=len(ix)
  train_loss=(totals/seen).cpu().tolist();validation=validate(heads,caches['val'])
  record=dict(epoch=epoch,train_loss=dict(zip([s['key'] for s in SPECS],train_loss)),validation=validation,seconds=time.perf_counter()-tick,peak_allocated_bytes=torch.cuda.max_memory_allocated(),updates=math.ceil(n/64),lr=opt.param_groups[0]['lr']);history.append(record)
  for spec in SPECS:
   k=spec['key'];score=validation[k]['macro_dice']
   if score>best[k]:
    best[k]=score;atomic_save(OUT/'heads'/(k+'_best.pth'),dict(key=k,head=base.cpu_tree(heads[k].state_dict()),epoch=epoch,validation=validation[k],config=config))
  atomic_save(OUT/'latest.pth',dict(epoch=epoch,heads=base.cpu_tree(heads.state_dict()),optimizer=base.cpu_tree(opt.state_dict()),rng=rng_state(),history=history,best=best,config=config))
  atomic_json(OUT/'history.json',history)
  print(json.dumps(dict(epoch=epoch,validation_macro_dice={k:v['macro_dice'] for k,v in validation.items()},seconds=record['seconds'],peak_bytes=record['peak_allocated_bytes'])),flush=True)
  if args.stop_after_epoch and epoch>=args.stop_after_epoch:break
 assert sha(SOURCE)==SOURCE_SHA
 atomic_json(OUT/'status.json',dict(state='complete' if history[-1]['epoch']==100 else 'stopped_at_epoch_boundary',epochs=len(history),heads=12,encoder_updates=0,total_seconds=time.perf_counter()-started,test_evaluated=False))
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback;atomic_json(ROOT/'reports/STAGEC_PROBES_TRAIN_FAILURE.json',dict(traceback=traceback.format_exc()));raise
