from pathlib import Path
import os,sys,json,subprocess,fcntl,datetime,traceback
ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'reports'
def status(phase,**kw):
 (REPORT/'STAGEC_STATUS.json').write_text(json.dumps(dict(phase=phase,pipeline_pid=os.getpid(),at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),indent=2)+'\n')
def child(script,args,log):
 cmd=[sys.executable,'-u',str(ROOT/'src'/script)]+args
 with (REPORT/log).open('w') as f:
  p=subprocess.Popen(cmd,cwd=ROOT,env=dict(os.environ,CUDA_VISIBLE_DEVICES='0'),stdout=f,stderr=subprocess.STDOUT)
  status('training' if 'train' in script else 'fixed_best_evaluation',child_pid=p.pid,command=cmd)
  rc=p.wait()
  if rc:raise RuntimeError(f'{script} exited {rc}; see {log}')
def main():
 with (REPORT/'STAGEC_NOPPM.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert json.loads((REPORT/'STAGEC_NOPPM_CPU_TESTS.json').read_text())['passed']
  assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
  child('train_stageC_noPPM.py',['--stop-after-epoch','1'],'stageC_noPPM_first.log')
  out=ROOT/'results/stageC_noPPM_20261117/C512-noPPM'
  first=json.loads((out/'history.json').read_text());assert len(first)==1
  assert json.loads((out/'capacity_actual_batch64.json').read_text())['passed']
  assert json.loads((out/'real_data_preflight.json').read_text())['passed']
  child('train_stageC_noPPM.py',['--resume'],'stageC_noPPM_resume.log')
  after=json.loads((out/'history.json').read_text());assert len(after)==100 and after[0]==first[0]
  assert json.loads((out/'resume_load_audit.json').read_text())['passed']
  child('evaluate_stageC_noPPM.py',[],'stageC_noPPM_evaluate.log')
  assert json.loads((ROOT/'evaluations/stageC_noPPM_20261117/SUMMARY.json').read_text())['complete']
  decision=json.loads((REPORT/'STAGEC_NOPPM_DECISION.json').read_text())
  status('complete',epochs=100,test_n=867,decision=decision)
if __name__=='__main__':
 try:main()
 except Exception:
  status('failed',error=traceback.format_exc());(REPORT/'STAGEC_PIPELINE_FAILURE.json').write_text(json.dumps(dict(traceback=traceback.format_exc()),indent=2)+'\n');raise
