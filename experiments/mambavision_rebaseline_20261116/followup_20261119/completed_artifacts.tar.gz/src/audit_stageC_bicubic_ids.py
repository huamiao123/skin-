"""Recover original mask IDs using the now-verified PIL Bicubic preprocessing."""
from pathlib import Path
import io,json,hashlib,zipfile,collections
import numpy as np
from PIL import Image
W=Path(__file__).resolve().parents[1];D=W/'diagnostics/stageC_20261117/data_provenance'
P=Path('/home/waas/mambavision_stage22/source/referring_image_segmentation')
pairs=json.loads((D/'PAIR_VERIFICATION.json').read_text())
assert all(r['best_mask_fit']['method']=='PIL_bicubic' and r['best_mask_fit']['mask_raw_exact'] for r in pairs['cases'])
index={}
for split in ['Training','Validation']:
 with zipfile.ZipFile(D/('ISIC2018_Task1_'+split+'_GroundTruth.zip')) as z:
  files=[n for n in z.namelist() if n.endswith('_segmentation.png')]
  for j,name in enumerate(files):
   im=Image.open(io.BytesIO(z.read(name))).convert('L').resize((256,256),Image.Resampling.BICUBIC)
   key=hashlib.sha256(np.asarray(im).tobytes()).hexdigest()
   index.setdefault(key,[]).append(dict(official_id=Path(name).stem.removesuffix('_segmentation'),official_split=split))
   if (j+1)%400==0:print(json.dumps(dict(split=split,processed=j+1)),flush=True)
mapping=[]
for split in ['train','val']:
 for p in sorted((P/'data/isic2018'/split/'masks').glob('*.png')):
  key=hashlib.sha256(np.asarray(Image.open(p).convert('L')).tobytes()).hexdigest()
  mapping.append(dict(split=split,id=p.stem,official_matches=index.get(key,[]),raw_pixel_sha256=key))
part=json.loads((P/'stage45_upernet_decoder/identity_partition.json').read_text())
descriptive={}
for split in ['train','val']:
 rows=[r for r in mapping if r['split']==split and r['id'] in part['splits'][split]]
 unique=[r for r in rows if len(r['official_matches'])==1]
 vals=[r['official_matches'][0]['official_id'] for r in unique]
 descriptive[split]=dict(selected_n=len(rows),uniquely_mapped_n=len(unique),official_id_min=min(vals) if vals else None,official_id_max=max(vals) if vals else None,official_split_counts=dict(collections.Counter(r['official_matches'][0]['official_split'] for r in unique)),examples=[dict(id=r['id'],official_id=r['official_matches'][0]['official_id']) for r in unique[:4]])
summary=dict(complete=True,legacy_n=len(mapping),matched_n=sum(bool(r['official_matches']) for r in mapping),uniquely_matched_n=sum(len(r['official_matches'])==1 for r in mapping),method='Exact raw pixel hash after PIL Bicubic256 official mask resize',selected_split_description=descriptive,image_pairing_verified_n=4,all_image_pairing_verified=False,no_labels_or_partitions_modified=True,note='A matching mask identifies its official source; it does not independently verify the corresponding image for every case. The earlier six-method scan did not include PIL Bicubic and must not be read as evidence of corrupt masks.')
(D/'BICUBIC_MASK_ID_MAPPING.json').write_text(json.dumps(mapping,indent=2)+'\n')
(D/'BICUBIC_MASK_ID_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
