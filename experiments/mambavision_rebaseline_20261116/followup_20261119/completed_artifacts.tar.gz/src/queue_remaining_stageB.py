"""Complete registered Stage-B controls after the C5 readouts and tests."""
from pathlib import Path
import os,sys,json,time,subprocess,fcntl,datetime,traceback,hashlib
ROOT=Path(__file__).resolve().parents[1];REPORT=ROOT/'reports'
ARMS=['stage4_only','encoder_frozen','wd005']
def status(phase,**kw):
 p=REPORT/'STAGEB_REMAINING_STATUS.json';q=p.with_suffix('.json.tmp')
 q.write_text(json.dumps(dict(phase=phase,pipeline_pid=os.getpid(),at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),indent=2)+'\n');q.replace(p)
def child(name,args,arm,phase):
 cmd=[sys.executable,'-u',str(ROOT/'src'/name),'--arm',arm]+args
 log=REPORT/('stageB_remaining_'+arm+'_'+phase+'.log')
 with log.open('w') as f:
  p=subprocess.Popen(cmd,cwd=ROOT,env=dict(os.environ,CUDA_VISIBLE_DEVICES='0'),stdout=f,stderr=subprocess.STDOUT)
  status(phase,arm=arm,child_pid=p.pid,command=cmd,log=str(log))
  rc=p.wait()
  if rc:raise RuntimeError(f'{arm} {name} exited{rc}; see {log}')
def main():
 with (REPORT/'STAGEB_REMAINING.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  status('waiting_for_probes_training_and_all_tests',predecessor_pid=96505,remaining_arms=ARMS)
  while True:
   p=Path('/proc/96505/cmdline')
   if not p.exists() or b'queue_stageC_probes.py' not in p.read_bytes():break
   time.sleep(5)
  previous=json.loads((ROOT/'evaluations/stageC_probes_20261117/SUMMARY.json').read_text())
  assert previous['complete'] and previous['test_n_per_model']==867 and len(previous['models'])==12
  proto=json.loads((REPORT/'STAGEB_REMAINING_PROTOCOL.json').read_text())
  for name,expected in proto['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
  assert json.loads((REPORT/'STAGEB_REMAINING_CPU_TESTS.json').read_text())['passed']
  for arm in ARMS:
   assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip(),'GPU occupied'
   (REPORT/'CURRENT_EXPERIMENT.json').write_text(json.dumps(dict(stage='stageB_remaining_20261117',arm=arm,epochs=100,status=str(REPORT/'STAGEB_REMAINING_STATUS.json'),automatic_test_n=867,user_reporting='Validation/test per-image macroDice and progress only'),indent=2)+'\n')
   child('train_remaining_stageB.py',['--stop-after-epoch','1'],arm,'first_epoch')
   out=ROOT/'results/stageB_remaining_20261117'/arm
   first=json.loads((out/'history.json').read_text());assert len(first)==1
   assert json.loads((out/'capacity_actual_batch64.json').read_text())['passed']
   assert json.loads((out/'real_data_preflight.json').read_text())['passed']
   child('train_remaining_stageB.py',['--resume'],arm,'training_after_restart')
   h=json.loads((out/'history.json').read_text());assert len(h)==100 and h[0]==first[0]
   assert json.loads((out/'resume_load_audit.json').read_text())['passed']
   child('evaluate_remaining_stageB.py',[],arm,'fixed_best_test')
   summary=json.loads((ROOT/'evaluations/stageB_remaining_20261117'/arm/'SUMMARY.json').read_text())
   assert summary['complete'] and summary['test_n_per_model']==867
   decision=json.loads((REPORT/('STAGEB_REMAINING_'+arm+'_DECISION.json')).read_text())
   status('arm_complete',arm=arm,decision=decision,test_n=867)
  status('complete',arms=ARMS,epochs_per_arm=100,test_n_per_arm=867)
if __name__=='__main__':
 try:main()
 except Exception:
  status('failed',traceback=traceback.format_exc());(REPORT/'STAGEB_REMAINING_PIPELINE_FAILURE.json').write_text(json.dumps(dict(traceback=traceback.format_exc()),indent=2)+'\n');raise
