from pathlib import Path
import os,sys,json,subprocess,datetime,time,traceback,fcntl,hashlib
ROOT=Path(__file__).resolve().parents[1];REPORT=ROOT/'reports';WAIT_PID=58108
def dump(p,x):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,indent=2));tmp.replace(p)
def current(phase,**kw):
 dump(REPORT/'STAGEB_ENCLR_STATUS.json',dict(phase=phase,pipeline_pid=os.getpid(),
  at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw))
def alive(pid):
 try:os.kill(pid,0);return True
 except ProcessLookupError:return False
def run(args,log,phase):
 with log.open('a') as f:
  p=subprocess.Popen([sys.executable]+args,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
  current(phase,child_pid=p.pid)
  if p.wait()!=0:raise RuntimeError('Child failed: '+str(log))
def main():
 lock=(REPORT/'STAGEB_ENCLR.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert json.loads((REPORT/'STAGEB_ENCLR_CPU_TESTS.json').read_text())['passed']
 current('waiting_for_decoder_lr',waiting_pid=WAIT_PID)
 while True:
  status=json.loads((REPORT/'STAGEB_HEADLR_STATUS.json').read_text())
  if status.get('phase')=='complete':break
  if (REPORT/'STAGEB_HEADLR_FAILURE.json').exists():raise RuntimeError('DecoderLR pipeline failed; stop queued experiment')
  if not alive(WAIT_PID):raise RuntimeError('DecoderLR pipeline stopped without completion; stop queued experiment')
  time.sleep(15)
 if alive(WAIT_PID):
  while alive(WAIT_PID):time.sleep(2)
 decision=json.loads((REPORT/'STAGEB_HEADLR_DECISION.json').read_text())
 assert decision['validation_only'] and not decision['test_used']
 if decision['passed']:arm,folder,head_lr='headlr3e4','stageB_headlr_20261117',.0003
 else:arm,folder,head_lr='control','stageB_color_20261117',.001
 d=ROOT/'results'/folder/arm
 h=json.loads((d/'history.json').read_text());assert len(h)==100
 assert json.loads((d/'status.json').read_text())['state']=='complete'
 best=max(h,key=lambda x:x['validation']['macro']['dice'])
 ref=dict(arm=arm,folder=str(d),checkpoint=str(d/'best_dice.pth'),sha256=hashlib.sha256((d/'best_dice.pth').read_bytes()).hexdigest(),
  selected_epoch=best['epoch'],head_lr=head_lr,encoder_lr=.0001,
  routing='headlr validation-only screen; test not used',parent_decision=decision)
 p=REPORT/'STAGEB_ENCLR_REFERENCE.json';assert not p.exists();dump(p,ref)
 proto=json.loads((REPORT/'STAGEB_ENCLR_PROTOCOL_20261117.json').read_text())
 assert hashlib.sha256((ROOT/'src/train_stageB_enclr.py').read_bytes()).hexdigest()==proto['source_sha256']
 check=subprocess.run(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],capture_output=True,text=True)
 assert check.returncode==0 and not check.stdout.strip(),'GPU busy: '+check.stdout
 out=ROOT/'results/stageB_enclr_20261117/enclr3e5';assert not out.exists()
 command=['src/train_stageB_enclr.py','--arm','enclr3e5','--micro-batch','64','--head-lr',str(head_lr)]
 run(command+['--stop-after-epoch','1'],REPORT/'stageB_enclr_first.log','first_epoch_and_preflight')
 before=json.loads((out/'history.json').read_text());assert len(before)==1
 run(command+['--resume'],REPORT/'stageB_enclr_resume.log','formal_training_after_restart')
 after=json.loads((out/'history.json').read_text());assert len(after)==100 and after[0]==before[0]
 assert json.loads((out/'resume_load_audit.json').read_text())['passed']
 (ROOT/'evaluations/stageB_enclr_20261117').mkdir(exist_ok=True)
 run(['src/evaluate_stageB_enclr.py'],REPORT/'stageB_enclr_evaluate.log','validation_and_fixed_test')
 s=json.loads((ROOT/'evaluations/stageB_enclr_20261117/SUMMARY.json').read_text());assert s['complete']
 base=s['models'][arm]['validation'];candidate=s['models']['enclr3e5']['validation']
 result=dict(validation_only=True,test_used=False,reference_arm=arm,head_lr=head_lr,encoder_lr=.00003,
  macro_dice_gain_pp=100*(candidate['macro']['dice']-base['macro']['dice']),
  boundary_F1_delta=candidate['macro']['boundary_f1']-base['macro']['boundary_f1'])
 result['passed']=result['macro_dice_gain_pp']>=.1 and result['boundary_F1_delta']>=0
 dump(REPORT/'STAGEB_ENCLR_DECISION.json',result);current('complete',test_n=867,decision=result)
if __name__=='__main__':
 try:main()
 except Exception:
  current('failed');dump(REPORT/'STAGEB_ENCLR_FAILURE.json',dict(traceback=traceback.format_exc()));raise
