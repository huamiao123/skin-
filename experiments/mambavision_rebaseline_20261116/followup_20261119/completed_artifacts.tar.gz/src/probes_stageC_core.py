"""Small frozen-feature readouts; these are diagnostic heads, not decoders."""
import torch
from torch import nn
from torch.nn import functional as F
from model import segmentation_loss
CHANNELS=(96,192,384,768)
SPECS=[dict(key=f'f{level+1}_{family}',level=level,family=family,channels=c) for level,c in enumerate(CHANNELS) for family in ['direct','linear32','nonlinear32']]
class Readout(nn.Module):
 def __init__(self,channels,family,seed):
  super().__init__();self.family=family
  with torch.random.fork_rng(devices=[]):
   torch.random.default_generator.manual_seed(seed)
   if family=='direct':self.direct=nn.Conv2d(channels,1,1)
   else:
    self.first=nn.Conv2d(channels,32,1,bias=False)
    self.last=nn.Conv2d(32,1,1)
 def forward(self,x,size):
  if self.family=='direct':y=self.direct(x)
  else:
   y=self.first(x)
   if self.family=='nonlinear32':y=F.gelu(y)
   y=self.last(y)
  return F.interpolate(y,size=size,mode='bilinear',align_corners=False)
def make_heads(seed=42):
 return nn.ModuleDict({s['key']:Readout(s['channels'],s['family'],seed+10103*s['level']+(0 if s['family']=='direct' else 503)) for s in SPECS})
def make_optimizer(heads):
 return torch.optim.AdamW([dict(params=list(heads[s['key']].parameters()),name=s['key'],lr=1e-3,initial_lr=1e-3) for s in SPECS],weight_decay=.01,betas=(.9,.999),eps=1e-8)
def step_heads(heads,opt,features,target):
 opt.zero_grad(set_to_none=True);losses=[]
 for spec in SPECS:
  logit=heads[spec['key']](features[spec['level']],target.shape[-2:])
  losses.append(segmentation_loss(logit,target))
 loss=torch.stack(losses).sum()
 if not torch.isfinite(loss):raise FloatingPointError('nonfinite probe loss')
 loss.backward()
 norms={}
 for group in opt.param_groups:
  norms[group['name']]=float(torch.nn.utils.clip_grad_norm_(group['params'],1.,error_if_nonfinite=True))
 opt.step()
 return torch.stack([v.detach() for v in losses]),norms
def image_scores(logits,target):
 pred=logits.float().sigmoid()>=.5;gt=target>=.5
 dims=(1,2,3);tp=(pred&gt).sum(dims).double();fp=(pred&~gt).sum(dims).double();fn=(~pred&gt).sum(dims).double()
 tn=(~pred&~gt).sum(dims).double();den=2*tp+fp+fn
 dice=torch.where(den>0,2*tp/den,torch.ones_like(den))
 return dict(dice=dice,tp=tp,fp=fp,fn=fn,tn=tn)
@torch.no_grad()
def validate(heads,cache):
 heads.eval();all_scores={s['key']:[] for s in SPECS};all_counts={s['key']:dict(tp=0,fp=0,fn=0,tn=0) for s in SPECS}
 n=len(cache['ids']);loss_sums={s['key']:0. for s in SPECS}
 for begin in range(0,n,64):
  end=min(begin+64,n);target=cache['target'][begin:end]
  features=[x[begin:end].float() for x in cache['features']]
  for s in SPECS:
   logits=heads[s['key']](features[s['level']],target.shape[-2:])
   scores=image_scores(logits,target)
   loss_sums[s['key']]+=float(segmentation_loss(logits,target))*(end-begin)
   all_scores[s['key']].append(scores['dice'])
   for k in all_counts[s['key']]:all_counts[s['key']][k]+=int(scores[k].sum())
 result={k:dict(macro_dice=float(torch.cat(v).mean()),loss=loss_sums[k]/n,counts=all_counts[k]) for k,v in all_scores.items()}
 heads.train();return result

VIEW_NAMES=('identity','horizontal_flip','vertical_flip','rotate90','rotate180','rotate270')
def apply_view(x,view):
 if view==0:return x
 if view==1:return x.flip(-1).contiguous()
 if view==2:return x.flip(-2).contiguous()
 if view in (3,4,5):return torch.rot90(x,view-2,(-2,-1)).contiguous()
 raise ValueError(view)
