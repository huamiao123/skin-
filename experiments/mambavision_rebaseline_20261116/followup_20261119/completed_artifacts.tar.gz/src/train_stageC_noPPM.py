"""Stage C single-factor PPM removal, fresh ImageNet initialization."""
from pathlib import Path
import argparse,json,hashlib,time,math,csv
import torch
from model import PROJECT,load_pretrained_encoder
from ablation_ppm import build_system
from train_mb64 import reference,base,accumulate,evaluate,real_data_replay_preflight,rng_state,restore_rng,atomic_json,atomic_save
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--resume',action='store_true');ap.add_argument('--stop-after-epoch',type=int,choices=range(1,101));args=ap.parse_args()
 proto=ROOT/'reports/STAGEC_NOPPM_PROTOCOL.json';protocol=json.loads(proto.read_text())
 assert sha(Path(__file__))==protocol['source_sha256']
 assert json.loads((ROOT/'reports/STAGEC_NOPPM_CPU_TESTS.json').read_text())['passed']
 assert json.loads((ROOT/'diagnostics/stageC_20261117/SENSITIVITY_SUMMARY.json').read_text())['complete']
 pairs=json.loads((ROOT/'diagnostics/stageC_20261117/data_provenance/PAIR_VERIFICATION.json').read_text())
 assert pairs['complete'] and all(r['pair_verified_image_match'] for r in pairs['cases']),'image pairing audit not passed'
 assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
 out=ROOT/'results/stageC_noPPM_20261117/C512-noPPM';latest=out/'latest.pth'
 if out.exists() and not args.resume:raise FileExistsError('existing run')
 if args.resume and not latest.exists():raise FileNotFoundError('missing checkpoint')
 out.mkdir(parents=True,exist_ok=True)
 reference.setup();torch.use_deterministic_algorithms(True,warn_only=True);torch.set_num_threads(8)
 data,partition=reference.load_data()
 model=build_system(load_pretrained_encoder(),'C512-noPPM',42).cuda()
 opt=torch.optim.AdamW([dict(params=list(model.probe.parameters()),lr=1e-3,initial_lr=1e-3,name='decoder'),dict(params=[p for p in model.encoder.parameters() if p.requires_grad],lr=1e-4,initial_lr=1e-4,name='encoder')],weight_decay=.01,betas=(.9,.999),eps=1e-8)
 config=dict(arm='C512-noPPM',model_arm='C-512-aux',ablation='remove_PPM_pooled_branches_and_corresponding_bottleneck_columns',seed=42,epochs=100,input_size=256,micro_batch=64,effective_batch=64,optimizer='AdamW',encoder_lr=1e-4,decoder_lr=1e-3,weight_decay=.01,scheduler='cosine_100_floor_0.01',augmentation='original_flips_rotation_only',threshold=.5,selection='validation_macro_dice_earliest_tie',test_evaluated=False,protocol_sha256=sha(proto),source_sha256=sha(Path(__file__)),model_sha256=sha(ROOT/'src/model.py'),ablation_sha256=sha(ROOT/'src/ablation_ppm.py'),training_utilities_sha256=sha(ROOT/'src/train_mb64.py'),partition_sha256=sha(PROJECT/'stage45_upernet_decoder/identity_partition.json'),total_parameters=sum(p.numel() for p in model.parameters()),trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),device=torch.cuda.get_device_name(0),limitation='Parameter count decreases; not a capacity-matched causal isolation of pooling.')
 if args.resume:assert json.loads((out/'config.json').read_text())==config
 else:atomic_json(out/'config.json',config)
 vc=reference.cache_new(762);reference.fill_cache(model,data,'val',vc);tc=reference.cache_new(1886)
 history=[];first=1;best=-1.
 if args.resume:
  state=torch.load(latest,map_location='cpu',weights_only=False);assert state['config']==config
  model.load_state_dict(state['model'],strict=True);opt.load_state_dict(state['optimizer']);restore_rng(state['rng'])
  base.assert_tree_exact(model.state_dict(),state['model']);base.assert_tree_exact(opt.state_dict(),state['optimizer']);base.assert_tree_exact(rng_state(),state['rng'])
  history=state['history'];best=state['best'];first=state['epoch']+1
  assert first<=100
  atomic_json(out/'resume_load_audit.json',dict(passed=True,checkpoint_epoch=state['epoch'],model_optimizer_rng_exact=True))
  del state
 started=time.perf_counter();torch.cuda.reset_peak_memory_stats()
 for epoch in range(first,101):
  tick=time.perf_counter();order,geometry=data.geometry(epoch);reference.fill_cache(model,data,'train',tc,geometry);model.train()
  if epoch==1 and not args.resume:
   snap=dict(model=base.cpu_tree(model.state_dict()),optimizer=base.cpu_tree(opt.state_dict()),rng=rng_state())
   _,norms=accumulate(model,opt,tc,order[:64],64)
   assert all(p.grad is None for p in model.encoder.model.patch_embed.parameters())
   assert all(p.grad is None for level in model.encoder.model.levels[:2] for p in level.parameters())
   assert any(p.grad is not None and p.grad.abs().sum()>0 for p in model.encoder.model.levels[2].parameters())
   assert any(p.grad is not None and p.grad.abs().sum()>0 for p in model.encoder.model.levels[3].parameters())
   assert model.probe.auxiliary_head.conv_seg.weight.grad.abs().sum()>0
   peak=torch.cuda.max_memory_allocated()
   model.load_state_dict(snap['model']);opt.load_state_dict(snap['optimizer']);restore_rng(snap['rng'])
   base.assert_tree_exact(model.state_dict(),snap['model']);base.assert_tree_exact(opt.state_dict(),snap['optimizer']);base.assert_tree_exact(rng_state(),snap['rng'])
   atomic_json(out/'capacity_actual_batch64.json',dict(passed=True,physical_batch=64,peak_allocated_bytes=peak,optimizer_update_excluded=True,train_state_restored_exactly=True,finite_gradient_norms=norms,early_encoder_frozen=True,stage3_stage4_auxiliary_gradients_verified=True))
   del snap
   real_data_replay_preflight(model,opt,data,tc,order,geometry,out)
  factor=.01+.99*(1+math.cos(math.pi*(epoch-1)/100))/2
  for group in opt.param_groups:group['lr']=group['initial_lr']*factor
  total=0.;n=0
  for start in range(0,len(order),64):
   ix=order[start:start+64];loss,_=accumulate(model,opt,tc,ix,64);total+=loss*len(ix);n+=len(ix)
  val,rows=evaluate(model,vc,data.ids['val'],64)
  record=dict(epoch=epoch,train_loss=total/n,validation=val,seconds=time.perf_counter()-tick,peak_allocated_bytes=torch.cuda.max_memory_allocated(),updates=math.ceil(n/64),learning_rates={g['name']:g['lr'] for g in opt.param_groups});history.append(record)
  if val['macro']['dice']>best:
   best=val['macro']['dice'];atomic_save(out/'best_dice.pth',dict(epoch=epoch,model=base.cpu_tree(model.state_dict()),validation=val,config=config))
  atomic_save(latest,dict(epoch=epoch,model=base.cpu_tree(model.state_dict()),optimizer=base.cpu_tree(opt.state_dict()),rng=rng_state(),best=best,history=history,config=config))
  atomic_json(out/'history.json',history)
  with (out/f'val_epoch{epoch}_per_sample.csv').open('w',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
  print(json.dumps(dict(arm='C512-noPPM',epoch=epoch,validation_macro_dice=val['macro']['dice'],seconds=record['seconds'],peak_bytes=record['peak_allocated_bytes'])),flush=True)
  if args.stop_after_epoch and epoch>=args.stop_after_epoch:break
 atomic_json(out/'status.json',dict(state='complete' if history[-1]['epoch']==100 else 'stopped_at_epoch_boundary',epochs_recorded=len(history),total_seconds=time.perf_counter()-started,test_evaluated=False))
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback;atomic_json(ROOT/'reports/STAGEC_TRAIN_FAILURE.json',dict(traceback=traceback.format_exc()));raise
