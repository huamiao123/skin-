"""Stage C paired validation diagnostics. Does not read test predictions."""
from pathlib import Path
import csv,json,hashlib,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'diagnostics/stageC_20261117'
ARMS={
 'A64':('stageA_20261117','A-64-noaux','formal_mb64/A-64-noaux'),
 'B512':('stageA_20261117','B-512-noaux','formal_mb64/B-512-noaux'),
 'C512aux':('stageA_20261117','C-512-aux','formal_mb64/C-512-aux'),
 'control':('stageB_color_20261117','control','stageB_color_20261117/control'),
 'color':('stageB_color_20261117','color','stageB_color_20261117/color'),
 'scale':('stageB_scale_20261117','scale','stageB_scale_20261117/scale'),
 'headlr':('stageB_headlr_20261117','headlr3e4','stageB_headlr_20261117/headlr3e4'),
 'enclr':('stageB_enclr_20261117','enclr3e5','stageB_enclr_20261117/enclr3e5')}
def atomic(p,s):
 q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(s,indent=2,allow_nan=False)+'\n');q.replace(p)
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 if (OUT/'PAIRED_DIAGNOSIS.json').exists():raise FileExistsError('diagnosis already exists')
 inputs={};models={};allrows={}
 for name,(tag,arm,run) in ARMS.items():
  p=ROOT/'evaluations'/tag/arm/'validation_per_image.csv'
  with p.open() as f:rows=list(csv.DictReader(f))
  ids=[r['id'] for r in rows]
  assert len(rows)==762 and len(set(ids))==762
  allrows[name]=rows
  inputs[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
 ids=[r['id'] for r in allrows['control']]
 area=np.array([float(r['GT_area_px']) for r in allrows['control']])
 cuts=np.quantile(area,[.25,.5,.75]);group=np.searchsorted(cuts,area,side='right')
 for name,rows in allrows.items():
  assert [r['id'] for r in rows]==ids
  num={k:np.array([float(r[k]) for r in rows]) for k in rows[0] if k not in ['id','source_dataset','patient_id']}
  assert np.array_equal(num['GT_area_px'],area)
  assert np.all(num['tp']+num['fp']+num['fn']+num['tn']==65536)
  assert np.max(np.abs(num['dice']-2*num['tp']/np.maximum(2*num['tp']+num['fp']+num['fn'],1)))<1e-7
  assert np.all(num['FN_interior_gt_distance_gt3']+num['FN_boundary_band']==num['fn'])
  def stats(ix):
   n={k:v[ix] for k,v in num.items()}
   ratio=n['Pred_to_GT_area_ratio'];fn=n['fn'].sum();fp=n['fp'].sum()
   return dict(n=int(ix.sum()),macro_dice=float(n['dice'].mean()),ratio_mean=float(ratio.mean()),ratio_quantiles=dict(zip(['q10','q25','median','q75','q90','q95'],np.quantile(ratio,[.1,.25,.5,.75,.9,.95]).tolist())),fraction_area_expanded=float((ratio>1).mean()),recall_lt_half=int((n['recall']<.5).sum()),dice_lt_half=int((n['dice']<.5).sum()),FP=int(fp),FN=int(fn),FN_deep3_share=float(n['FN_interior_gt_distance_gt3'].sum()/max(fn,1)),FN_deep8_share=float(n['FN_interior_gt_distance_gt8'].sum()/max(fn,1)),FP_far8_share=float(n['FP_far_from_GT_gt8'].sum()/max(fp,1)),mean_foreground_probability=float(n['mean_foreground_probability'].mean()),mean_background_probability=float(n['mean_background_probability'].mean()))
  h=json.loads((ROOT/'results'/ARMS[name][2]/'history.json').read_text())
  best=max(h,key=lambda r:r['validation']['macro']['dice'])
  last=h[-1]
  curve=dict(best_epoch=best['epoch'],best_train_loss=best['train_loss'],last_train_loss=last['train_loss'],best_validation_loss=best['validation']['loss'],last_validation_loss=last['validation']['loss'],best_validation_dice=best['validation']['macro']['dice'],last_validation_dice=last['validation']['macro']['dice'],best_to_last_dice_delta_pp=100*(last['validation']['macro']['dice']-best['validation']['macro']['dice']))
  sweep=json.loads((ROOT/'evaluations'/ARMS[name][0]/ARMS[name][1]/'VALIDATION_THRESHOLD_SWEEP.json').read_text())
  models[name]=dict(overall=stats(np.ones(762,dtype=bool)),area_groups={'Q'+str(g+1):stats(group==g) for g in range(4)},training_curve=curve,threshold_scan_best=sweep['best'],threshold_scan_gain_pp=100*(sweep['best']['macro_dice']-num['dice'].mean()))
 comparisons={}
 ctrl=np.array([float(r['dice']) for r in allrows['control']])
 tail=ctrl<np.quantile(ctrl,.1)
 for name in ['color','scale','headlr','enclr']:
  v=np.array([float(r['dice']) for r in allrows[name]]);d=v-ctrl
  rng=np.random.default_rng(42);boot=np.array([d[rng.integers(0,len(d),len(d))].mean() for _ in range(2000)])
  comparisons[name]=dict(mean_delta_pp=float(100*d.mean()),image_bootstrap95_pp=(100*np.quantile(boot,[.025,.975])).tolist(),improved_gt_1pp=int((d>.01).sum()),worsened_gt_1pp=int((d<-.01).sum()),delta_in_control_worst10pct_pp=float(100*d[tail].mean()),delta_elsewhere_pp=float(100*d[~tail].mean()),by_area_delta_pp={'Q'+str(g+1):float(100*d[group==g].mean()) for g in range(4)})
 mat=np.array([[float(r['dice']) for r in allrows[name]] for name in ARMS])
 worst=sorted(range(len(ids)),key=lambda i:ctrl[i])
 selections={}
 cr=allrows['control']
 for name,key in [('lowest_dice',lambda i:float(cr[i]['dice'])),('deep_FN',lambda i:-float(cr[i]['FN_interior_gt_distance_gt8'])/max(area[i],1)),('far_FP',lambda i:-float(cr[i]['FP_far_from_GT_gt8'])/65536)]:
  selections[name]=[ids[i] for i in sorted(range(len(ids)),key=key)[:24]]
 case_rows=[]
 for i,sid in enumerate(ids):
  r=dict(id=sid,area_group='Q'+str(group[i]+1),GT_area_px=int(area[i]),control_recall=float(cr[i]['recall']),control_FN_deep8=int(cr[i]['FN_interior_gt_distance_gt8']),control_FP_far8=int(cr[i]['FP_far_from_GT_gt8']))
  r.update({name+'_dice':float(mat[j,i]) for j,name in enumerate(ARMS)})
  case_rows.append(r)
 with (OUT/'paired_validation_cases.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(case_rows[0]));w.writeheader();w.writerows(case_rows)
 result=dict(complete=True,validation_only=True,test_read=False,n=762,area_cuts_px=cuts.tolist(),models=models,paired_comparisons=comparisons,cases=selections,all_8_models_dice_lt_half=int((mat<.5).all(0).sum()),any_model_dice_lt_half=int((mat<.5).any(0).sum()),image_selection_oracle_headroom_pp=float(100*(mat.max(0).mean()-mat.mean(1).max())),oracle_caveat='Offline image-level selection among eight fixed outputs; neither deployable score nor fusion upper bound.',uncertainty_caveat='Exploratory image intervals within one seed; patient and training-seed uncertainty not represented.',inputs_sha256=inputs)
 atomic(OUT/'PAIRED_DIAGNOSIS.json',result)
 lines=['Stage C validation-only paired diagnosis','n=762; test not read; one seed42','']
 for name,v in models.items():
  z=v['overall'];lines.append(f"{name}: Dice={100*z['macro_dice']:.4f}%; severe={z['recall_lt_half']}; FNdeep8/FN={z['FN_deep8_share']:.3f}; FPfar8/FP={z['FP_far8_share']:.3f}; threshold gain={v['threshold_scan_gain_pp']:.4f}pp")
  for g,z in v['area_groups'].items():lines.append(f"  {g}: Dice={100*z['macro_dice']:.4f}%; area ratio mean/median={z['ratio_mean']:.3f}/{z['ratio_quantiles']['median']:.3f}; severe={z['recall_lt_half']}")
 lines+=['','Comparisons versus same4090control:',json.dumps(comparisons,indent=2),'','These statistics do not isolate encoder/decoder causality.']
 (OUT/'PAIRED_DIAGNOSIS.txt').write_text('\n'.join(lines)+'\n')
 atomic(OUT/'CPU_STATUS.json',dict(phase='complete',models=8,validation_n=762))
 print(json.dumps(dict(complete=True,control=models['control'],comparisons=comparisons)),flush=True)
if __name__=='__main__':
 try:main()
 except Exception:
  import traceback
  OUT.mkdir(parents=True,exist_ok=True);atomic(OUT/'CPU_FAILURE.json',dict(traceback=traceback.format_exc()));raise
