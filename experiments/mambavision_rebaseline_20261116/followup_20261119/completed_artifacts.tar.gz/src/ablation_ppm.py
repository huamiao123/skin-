"""PPM removal ablation: native UPerHead FPN, same f1..f4 and optional FCN."""
import torch
from torch import nn
from model import SegmentationSystem
class EmptyPPM(nn.Module):
 def forward(self,x):return []
def remove_ppm(head):
 """Retain raw-f4 columns and the existing BN/ReLU; remove pooled branches."""
 old=head.bottleneck.conv
 raw_channels=head.in_channels[-1]
 assert old.groups==1 and old.in_channels>raw_channels
 with torch.random.fork_rng(devices=[]):
  replacement=nn.Conv2d(raw_channels,old.out_channels,old.kernel_size,
    stride=old.stride,padding=old.padding,dilation=old.dilation,
    groups=old.groups,bias=old.bias is not None,padding_mode=old.padding_mode)
 with torch.no_grad():
  replacement.weight.copy_(old.weight[:,:raw_channels])
  if old.bias is not None:replacement.bias.copy_(old.bias)
 head.psp_modules=EmptyPPM()
 head.bottleneck.conv=replacement
 head.bottleneck.in_channels=raw_channels
 return head
def build_system(encoder,arm='C512-noPPM',seed=42):
 assert arm=='C512-noPPM'
 model=SegmentationSystem(encoder,'C-512-aux',seed)
 remove_ppm(model.probe.decode_head)
 return model
