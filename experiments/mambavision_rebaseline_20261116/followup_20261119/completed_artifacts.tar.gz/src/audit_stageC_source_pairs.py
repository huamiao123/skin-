from pathlib import Path
import json,io,zipfile,hashlib
import numpy as np
from PIL import Image,ImageDraw
import cv2
cv2.setNumThreads(1)
W=Path(__file__).resolve().parents[1];D=W/'diagnostics/stageC_20261117/data_provenance'
P=Path('/home/waas/mambavision_stage22/source/referring_image_segmentation')
records=json.loads((D/'official_images/ACQUISITION.json').read_text())
zips=[zipfile.ZipFile(D/('ISIC2018_Task1_'+split+'_GroundTruth.zip')) for split in ['Training','Validation']]
rows=[];grid=Image.new('RGB',(1024,280*len(records)),'white');draw=ImageDraw.Draw(grid)
for j,r in enumerate(sorted(records,key=lambda x:int(x['legacy_id']))):
 sid,orig=r['legacy_id'],r['official_id']
 image=Image.open(D/'official_images'/(orig+'.jpg')).convert('RGB')
 oldimage=np.array(Image.open(P/'data/isic2018/val/images'/(sid+'.png')).convert('RGB'))
 oldmask=np.array(Image.open(P/'data/isic2018/val/masks'/(sid+'.png')).convert('L'))
 found=[(z,n) for z in zips for n in z.namelist() if n.endswith('/'+orig+'_segmentation.png')]
 assert len(found)==1
 z,n=found[0];mask=Image.open(io.BytesIO(z.read(n))).convert('L');assert image.size==mask.size
 (D/'official_images'/(orig+'_segmentation.png')).write_bytes(z.read(n))
 methods=[('PIL_nearest',Image.Resampling.NEAREST),('PIL_bilinear',Image.Resampling.BILINEAR),('PIL_bicubic',Image.Resampling.BICUBIC),('PIL_lanczos',Image.Resampling.LANCZOS)]
 fits=[]
 for method,flag in methods:
  im=np.array(image.resize((256,256),flag));ma=np.array(mask.resize((256,256),flag))
  gt=ma>=127.5;legacy=oldmask>=127.5
  fits.append(dict(method=method,image_mae_255=float(np.abs(im.astype(float)-oldimage).mean()),image_correlation=float(np.corrcoef(im.ravel(),oldimage.ravel())[0,1]),image_exact=bool(np.array_equal(im,oldimage)),mask_mae_255=float(np.abs(ma.astype(float)-oldmask).mean()),mask_raw_exact=bool(np.array_equal(ma,oldmask)),mask_binary_dice=float(2*(gt&legacy).sum()/max(1,int(gt.sum()+legacy.sum())))))
 best_im=min(fits,key=lambda v:v['image_mae_255']);best_mask=min(fits,key=lambda v:v['mask_mae_255'])
 rows.append(dict(legacy_id=sid,official_id=orig,best_image_fit=best_im,best_mask_fit=best_mask,all_resampling_fits=fits,pair_verified_image_match=best_im['image_correlation']>.99 and best_im['image_mae_255']<5,known_literature_noisy_example=orig in ['ISIC_0015251','ISIC_0015353']))
 for col,im in enumerate([Image.fromarray(oldimage),Image.fromarray(oldmask).convert('RGB'),image.resize((256,256),Image.Resampling.BICUBIC),mask.resize((256,256),Image.Resampling.BICUBIC).convert('RGB')]):grid.paste(im,(col*256,j*280+24))
 for col,text in enumerate([f'legacy val/{sid}','legacy mask',orig+' source image','official source mask']):draw.text((col*256+3,j*280+4),text,fill='black')
grid.save(D/'ORIGINAL_PAIR_COMPARISON.png')
(D/'PAIR_VERIFICATION.json').write_text(json.dumps(dict(complete=True,source='ISIC official Image API and fixed ISIC2018 Task1 GT ZIPs',cases=rows,paper_url='https://pmc.ncbi.nlm.nih.gov/articles/PMC10407008/',caveat='Four validation cases only; no labels modified or cases excluded. Image match does not replace expert annotation review.'),indent=2)+'\n')
print(json.dumps(rows),flush=True)
